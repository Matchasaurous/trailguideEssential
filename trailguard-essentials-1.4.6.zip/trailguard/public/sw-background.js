/* Trailguard Essentials — service-worker side of background operation.
   Imported into the generated service worker (vite.config.js → workbox.importScripts).

   1. Background Sync: positions recorded while offline wait in the IndexedDB
      outbox written by src/background-service.js. When connectivity returns the
      browser fires 'sync' — even if the app tab was closed — and the newest
      position is sent to the Realtime Database REST API with the signed-in
      user's ID token (if it hasn't expired; tokens last one hour).
   2. Notification taps focus the app and open the related case.
   3. Web push: background alerts sent by the Apps Script server through Firebase
      Cloud Messaging (src/web-push.js) arrive here as data messages and are shown
      with the same tag the app uses for that alert (sos:<id>, assign:<id>, …), so
      the app's own notification and the push replace each other. */

const TG_DB = 'trailguard-bg';
const TG_STORE = 'outbox';
const TG_SYNC_TAG = 'tg-location-sync';

function tgOpen() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(TG_DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(TG_STORE, { keyPath: 'path' });
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function tgRequest(db, mode, fn) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(TG_STORE, mode);
    const req = fn(tx.objectStore(TG_STORE));
    tx.oncomplete = () => resolve(req ? req.result : undefined);
    tx.onerror = () => reject(tx.error);
  });
}

async function tgFlushOutbox() {
  const db = await tgOpen();
  try {
    const records = await tgRequest(db, 'readonly', (store) => store.getAll());
    for (const record of records) {
      if (!record.idToken || !record.exp || record.exp < Date.now() + 30000) {
        // Token expired while offline: the app sends a fresh position when it next opens.
        await tgRequest(db, 'readwrite', (store) => store.delete(record.path));
        continue;
      }
      const url = `${record.dbUrl}/${record.path}.json?auth=${encodeURIComponent(record.idToken)}`;
      let res;
      try {
        res = await fetch(url, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(record.payload)
        });
      } catch (err) {
        throw err; // still offline: let the browser retry the sync later
      }
      if (res.ok || (res.status >= 400 && res.status < 500)) {
        // Written, or refused for good (rate limit, membership removed): don't retry.
        await tgRequest(db, 'readwrite', (store) => store.delete(record.path));
      } else {
        throw new Error(`HTTP ${res.status}`);
      }
    }
  } finally {
    db.close();
  }
}

self.addEventListener('sync', (event) => {
  if (event.tag === TG_SYNC_TAG) event.waitUntil(tgFlushOutbox());
});

const TG_CRITICAL_VIBRATE = [800, 300, 800, 300, 800, 300, 1200];
const TG_VIBRATE = [400, 200, 400, 200, 400];

function tgPushData(event) {
  if (!event.data) return {};
  let msg;
  try { msg = event.data.json(); } catch { return { body: event.data.text() }; }
  // FCM wraps data messages as {data: {...}, from, priority, fcmMessageId}.
  return (msg && (msg.data || msg.notification)) || msg || {};
}

// Chrome lets a push skip its notification only while the app is focused on screen;
// Safari (iPhone, iPad, Mac) and Firefox revoke push for sites that do that, so they always show it.
function tgMaySkipWhenFocused() {
  const ua = self.navigator.userAgent || '';
  return /(Chrome|Chromium|Edg)\//.test(ua) && !/(iPhone|iPad|iPod)/.test(ua);
}

self.addEventListener('push', (event) => {
  const d = tgPushData(event);
  const critical = d.critical === '1' || d.critical === true;
  event.waitUntil((async () => {
    if (d.kind !== 'test' && tgMaySkipWhenFocused()) {
      const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
      // The open app is already sounding this alert itself.
      if (windows.some((c) => c.focused && c.visibilityState === 'visible')) return;
    }
    await self.registration.showNotification(d.title || 'Trailguard Essentials', {
      body: d.body || 'Open Trailguard for details.',
      tag: d.tag || `push:${Date.now()}`,
      renotify: true,
      requireInteraction: d.kind !== 'test',
      silent: false,
      icon: 'icons/icon-192.png',
      badge: 'icons/icon-192.png',
      vibrate: critical ? TG_CRITICAL_VIBRATE : TG_VIBRATE,
      timestamp: Number(d.sentAt) || Date.now(),
      data: { incidentId: d.incidentId || '', gid: d.gid || '', key: d.tag || '', push: true }
    });
  })());
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const data = event.notification.data || {};
  event.waitUntil((async () => {
    const clientsList = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const client = clientsList.find((c) => 'focus' in c);
    if (client) {
      await client.focus();
      client.postMessage({ type: 'notification-click', data });
    } else if (self.clients.openWindow) {
      await self.clients.openWindow(self.registration.scope);
    }
  })());
});
