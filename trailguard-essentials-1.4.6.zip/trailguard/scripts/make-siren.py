#!/usr/bin/env python3
"""Render the app's urgent siren (src/background-service.js, Alarm.cycle) to a WAV
for the Android app, so critical alarms there sound exactly like the web app.

    python3 scripts/make-siren.py   →  android/app/src/main/res/raw/tg_siren.wav

One 1.6 s cycle, as the web alarm repeats it: a band-limited sawtooth (like the
Web Audio 'sawtooth' oscillator) sweeping 650 → 1350 → 650 Hz over 0.9 s with a
30 ms fade-in and 50 ms fade-out, then silence until 1.6 s. Android loops it.
Needs numpy.
"""
import wave
from pathlib import Path

import numpy as np

RATE = 44100
CYCLE = 1.6
TONE = 0.9
LEVEL = 0.55          # peak of the loudest harmonic sum; Android's alarm volume scales it

t = np.arange(int(RATE * CYCLE)) / RATE
freq = np.where(t < 0.45, 650 + (1350 - 650) * t / 0.45,
                np.where(t < TONE, 1350 - (1350 - 650) * (t - 0.45) / 0.45, 0.0))
phase = 2 * np.pi * np.cumsum(freq) / RATE
saw = np.zeros_like(t)
for k in range(1, 40):                       # harmonics up to Nyquist only (no aliasing hiss)
    saw += np.where(k * freq < RATE / 2, np.sin(k * phase) / k, 0.0)
saw *= 2 / np.pi
env = np.interp(t, [0, 0.03, 0.85, 0.9, CYCLE], [0, 1, 1, 0, 0])
signal = saw * env
signal *= LEVEL / np.max(np.abs(signal))
pcm = (signal * 32767).astype('<i2')

out = Path(__file__).resolve().parent.parent / 'android/app/src/main/res/raw/tg_siren.wav'
out.parent.mkdir(parents=True, exist_ok=True)
with wave.open(str(out), 'wb') as w:
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(RATE)
    w.writeframes(pcm.tobytes())
print(f'Wrote {out} ({out.stat().st_size // 1024} KB, {CYCLE} s)')
