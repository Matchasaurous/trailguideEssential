// Server-aligned clock. Firebase reports the offset between this device's clock
// and the server's, so staleness and PTT time limits agree across devices.
import { ref, onValue } from 'firebase/database';
import { db } from './firebase.js';

let offsetMs = 0;
let started = false;

export function startClock() {
  if (started || !db) return;
  started = true;
  onValue(ref(db, '.info/serverTimeOffset'), (snap) => {
    const value = Number(snap.val());
    offsetMs = Number.isFinite(value) ? value : 0;
  });
}

export function serverNow() {
  return Date.now() + offsetMs;
}
