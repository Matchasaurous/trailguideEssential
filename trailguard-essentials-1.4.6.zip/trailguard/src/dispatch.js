// Dispatch data layer: reports and cases (incidents, including SOS), the review
// queue, unit assignments with the single-task lock, auto-assignment, responder
// status, group dispatch settings, case photos and the per-case log.
//
// Lifecycle of a case:
//   member report ──► pending ──(dispatcher verifies)──► open ──► closed
//                        │                                 ▲  │
//                        └─(dispatcher rejects)──► rejected │  └─► monitoring
//   dispatcher-created case starts open (or monitoring); SOS starts open.
//   Fire & Safety units may open a fire case at once (rapid alert), and medical
//   units a patient-transport request, without waiting for review.
//
// Matching: a responder fits a case when their role responds to its type (group
// settings), they carry every piece of equipment the case requires (e.g. an AED
// for a cardiac arrest), and — for patient transport — they have a vehicle.
// database.rules.json enforces the same test for self-accept and auto-assign.
//
// Every assignment keeps the time of each step in assigned/{uid}/t (assigned,
// accepted, en route, on scene, cleared, declined) for after-action analytics.
//
// Single-task lock: a unit with an active assignment (assigned / accepted /
// en route / on scene) on an open or monitoring case is BUSY. Its status record
// points at that case, and database.rules.json refuses any new assignment until
// the unit resolves (clears) it or the case is closed.
import {
  ref, set, update, push, remove, onValue, serverTimestamp
} from 'firebase/database';
import { db } from './firebase.js';
import { serverNow } from './clock.js';
import {
  CASE_TYPES, REPORTABLE_TYPES, FIELD_UNITS, GEAR, GEAR_IDS, SETTINGS_VERSION, MIN_PROXIMITY_M, MAX_PROXIMITY_M,
  normalizeSettings, defaultSettings, caseTypeLabel, responderFit, profileOf
} from './roles.js';

export { CASE_TYPES as INCIDENT_TYPES };

export const PRIORITIES = {
  1: { label: 'P1 — Critical', short: 'P1' },
  2: { label: 'P2 — Urgent', short: 'P2' },
  3: { label: 'P3 — Routine', short: 'P3' }
};

export const CASE_STATUSES = {
  pending: 'Pending review',
  open: 'Verified · Open',
  monitoring: 'Monitoring',
  closed: 'Resolved / Closed',
  rejected: 'Rejected'
};

export const STATUSES = {
  available: 'Available',
  busy: 'Busy',
  enroute: 'En route',
  onscene: 'On scene',
  offduty: 'Off duty'
};

export const ASSIGNMENT_STATES = {
  assigned: 'Assigned — awaiting reply',
  accepted: 'Accepted',
  declined: 'Declined',
  enroute: 'En route',
  onscene: 'On scene',
  cleared: 'Resolved'
};

/** Which buttons an assigned responder sees, by current assignment state. */
export const NEXT_STATES = {
  assigned: ['accepted', 'declined'],
  accepted: ['enroute', 'onscene', 'cleared'],
  enroute: ['onscene', 'cleared'],
  onscene: ['cleared'],
  declined: [],
  cleared: []
};

const ACTIVE_ASSIGNMENT = new Set(['assigned', 'accepted', 'enroute', 'onscene']);
const RECENT_CLOSED_MS = 12 * 3600 * 1000;
/** Status shown (and stored) for each active assignment state. */
const LOCK_STATUS = { assigned: 'busy', accepted: 'busy', enroute: 'enroute', onscene: 'onscene' };

/** A write refused by database.rules.json (Firebase SDK or REST). */
export function isPermissionDenied(err) {
  return !!err && /PERMISSION_DENIED|permission[_ ]denied/i.test(`${err.code || ''} ${err.message || ''}`);
}

export function isDispatcherRole(role) {
  return role === 'owner' || role === 'dispatcher';
}

/** May this member open a case of this type without review? */
export function canOpenDirect(type, member) {
  if (!member) return false;
  if (isDispatcherRole(member.role)) return true;
  const { unit, legacy } = profileOf(member);
  if (legacy) return false;
  return (type === 'fire' && unit === 'fire') || (type === 'transport' && unit === 'medical');
}

/**
 * An auto-assignment nobody has answered within the group's timeout. It no longer
 * counts towards the units a case needs, so the next closest unit is picked.
 */
export function isStaleAuto(a, settings, now = serverNow()) {
  if (!a || a.state !== 'assigned' || a.by !== 'auto') return false;
  const at = (a.t && a.t.assigned) || a.ts || 0;
  return now - at > normalizeSettings(settings).autoTimeoutS * 1000;
}

/** Assignment record for a database write: keeps earlier step times and stamps this one. */
function assignmentRecord(current, { name, state, unit, by, reason }) {
  const t = {};
  if (current && current.t && typeof current.t === 'object') {
    for (const [k, v] of Object.entries(current.t)) if (Number.isFinite(v)) t[k] = v;
  }
  t[state] = serverTimestamp();
  const record = { name, state, ts: serverTimestamp(), t };
  const cleanUnit = unit || (current && current.unit);
  if (FIELD_UNITS.includes(cleanUnit)) record.unit = cleanUnit;
  const cleanBy = by || (current && current.by);
  if (cleanBy === 'self' || cleanBy === 'dispatch' || cleanBy === 'auto') record.by = cleanBy;
  if (reason) record.reason = String(reason).slice(0, 40);
  return record;
}

/** Verified and still needing work (open or monitoring). */
export function isActive(inc) {
  return !!inc && (inc.state === 'open' || inc.state === 'monitoring');
}

export function isActiveAssignment(a) {
  return !!a && ACTIVE_ASSIGNMENT.has(a.state);
}

/** [uid, assignment] pairs with an active assignment on this case. */
export function activeAssignees(incident) {
  return Object.entries(incident.assigned || {}).filter(([, a]) => isActiveAssignment(a));
}

export class Dispatch extends EventTarget {
  /**
   * Events: 'incidents' {incidents}, 'status' {status}, 'settings' {settings}, 'error' {message}
   * @param {{gid, uid, name, onCaseEvent?: (event: string, incident: object) => void}} opts
   */
  constructor({ gid, uid, name, onCaseEvent }) {
    super();
    this.gid = gid;
    this.uid = uid;
    this.name = name;
    this.onCaseEvent = onCaseEvent || (() => {});
    this.incidents = new Map();
    this.status = new Map();
    this.settings = normalizeSettings(null);
    this.settingsLoaded = false;
    this.settingsMissing = false;
    this.settingsVersion = null;
    this.incidentsLoaded = false;
    this.statusLoaded = false;
    this.reconciling = false;
    this.unsubs = [];
  }

  start() {
    const fail = (err) => this.dispatchEvent(new CustomEvent('error', { detail: { message: err.message } }));
    this.unsubs.push(onValue(ref(db, `incidents/${this.gid}`), (snap) => {
      this.ingestIncidents(snap.val());
    }, fail));
    this.unsubs.push(onValue(ref(db, `status/${this.gid}`), (snap) => {
      this.status = new Map(Object.entries(snap.val() || {}));
      this.statusLoaded = true;
      this.dispatchEvent(new CustomEvent('status', { detail: { status: this.status } }));
      this.reconcileMyStatus();
    }, fail));
    this.unsubs.push(onValue(ref(db, `groups/${this.gid}/settings`), (snap) => {
      this.settingsLoaded = true;
      this.settingsMissing = !snap.exists();
      this.settingsVersion = snap.exists() && snap.val() ? snap.val().v : null;
      this.settings = normalizeSettings(snap.val());
      this.dispatchEvent(new CustomEvent('settings', { detail: { settings: this.settings } }));
    }, fail));
  }

  stop() {
    for (const unsub of this.unsubs) unsub();
    this.unsubs = [];
  }

  /** Also used by the Android background poller (native HTTP), same data shape. */
  ingestIncidents(value) {
    const next = new Map();
    for (const [id, inc] of Object.entries(value || {})) {
      if (inc && typeof inc === 'object') next.set(id, { id, ...inc });
    }
    this.incidents = next;
    this.incidentsLoaded = true;
    this.dispatchEvent(new CustomEvent('incidents', { detail: { incidents: this.incidents } }));
    this.reconcileMyStatus();
  }

  /* ---------------- Derived state ---------------- */

  /** The case a unit is locked to (active assignment on an active case), or null. */
  lockOf(uid) {
    let best = null;
    for (const inc of this.incidents.values()) {
      if (!isActive(inc)) continue;
      const a = inc.assigned && inc.assigned[uid];
      if (isActiveAssignment(a) && (!best || (a.ts || 0) > (best.assignment.ts || 0))) best = { incident: inc, assignment: a };
    }
    return best;
  }

  myLock() {
    return this.lockOf(this.uid);
  }

  /** Status to display for a unit: the lock wins over a stale stored status. */
  effectiveStatus(uid) {
    const lock = this.lockOf(uid);
    if (lock) return { state: LOCK_STATUS[lock.assignment.state], incidentId: lock.incident.id, locked: true };
    const st = this.status.get(uid);
    if (!st) return { state: 'available', locked: false };
    if (st.state === 'offduty') return { state: 'offduty', locked: false };
    if (st.state === 'busy' && !st.incidentId) return { state: 'busy', locked: false };
    return { state: 'available', locked: false };
  }

  /**
   * Keep my stored status in step with my assignments: locked to my active case
   * (e.g. right after a dispatcher assigned me), released once it is resolved or
   * closed (e.g. a dispatcher closed it while my phone was offline).
   */
  reconcileMyStatus() {
    if (!this.incidentsLoaded || !this.statusLoaded || this.reconciling) return;
    const lock = this.myLock();
    const mine = this.status.get(this.uid);
    let target = null;
    if (lock) {
      const want = LOCK_STATUS[lock.assignment.state];
      if (!mine || mine.incidentId !== lock.incident.id || mine.state !== want) {
        target = { state: want, incidentId: lock.incident.id, name: this.name, ts: serverTimestamp() };
      }
    } else if (mine && mine.incidentId) {
      target = { state: mine.state === 'offduty' ? 'offduty' : 'available', name: this.name, ts: serverTimestamp() };
    }
    if (!target) return;
    this.reconciling = true;
    set(ref(db, `status/${this.gid}/${this.uid}`), target)
      .catch((err) => console.warn('Status reconcile failed', err))
      .finally(() => { this.reconciling = false; });
  }

  /** Pending reports first, then active cases (SOS, open before monitoring, priority, oldest), then recent history. */
  board() {
    const now = serverNow();
    const pending = [];
    const open = [];
    const closed = [];
    for (const inc of this.incidents.values()) {
      if (inc.state === 'pending') pending.push(inc);
      else if (isActive(inc)) open.push(inc);
      else if (now - (inc.closedAt || inc.updatedAt || inc.createdAt || 0) < RECENT_CLOSED_MS) closed.push(inc);
    }
    pending.sort((a, b) => a.priority - b.priority || a.createdAt - b.createdAt);
    open.sort((a, b) => (a.type === 'sos' ? 0 : 1) - (b.type === 'sos' ? 0 : 1)
      || (a.state === 'open' ? 0 : 1) - (b.state === 'open' ? 0 : 1)
      || a.priority - b.priority || a.createdAt - b.createdAt);
    closed.sort((a, b) => (b.closedAt || 0) - (a.closedAt || 0));
    return { pending, open, closed };
  }

  myActiveSos() {
    for (const inc of this.incidents.values()) {
      if (inc.type === 'sos' && inc.state === 'open' && inc.createdBy === this.uid) return inc;
    }
    return null;
  }

  /** Units still needed on a case (dispatcher sets `need`, default 1). Unanswered auto-assignments past the timeout don't count. */
  stillNeeded(incident) {
    const now = serverNow();
    const counted = activeAssignees(incident).filter(([, a]) => !isStaleAuto(a, this.settings, now)).length;
    return Math.max(0, (incident.need || 1) - counted);
  }

  log(iid, text, kind = 'event') {
    return push(ref(db, `incidentLog/${this.gid}/${iid}`), {
      uid: this.uid, name: this.name, text: String(text).slice(0, 500), kind, ts: serverTimestamp()
    }).catch((err) => console.warn('Case log write failed', err));
  }

  emit(event, incident) {
    try { this.onCaseEvent(event, incident); } catch (err) { console.warn(err); }
  }

  /* ---------------- SOS ---------------- */

  async raiseSos(fix) {
    const existing = this.myActiveSos();
    if (existing) return existing.id;
    const iid = push(ref(db, `incidents/${this.gid}`)).key;
    const incident = {
      type: 'sos',
      title: `SOS — ${this.name}`.slice(0, 80),
      priority: 1,
      state: 'open',
      createdBy: this.uid,
      createdByName: this.name,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    if (fix && Number.isFinite(fix.lat) && Number.isFinite(fix.lng)) {
      incident.lat = fix.lat;
      incident.lng = fix.lng;
      incident.acc = Math.round(Math.min(fix.acc || 0, 100000));
      incident.source = 'gps';
    } else {
      incident.notes = 'No GPS fix when SOS was raised.';
    }
    await set(ref(db, `incidents/${this.gid}/${iid}`), incident);
    this.log(iid, fix ? `SOS raised (±${Math.round(fix.acc || 0)} m)` : 'SOS raised without GPS position');
    this.emit('sos', { id: iid, ...incident });
    return iid;
  }

  /** The reporter cancels their SOS, or withdraws a report still pending review. */
  async withdraw(iid) {
    const inc = this.incidents.get(iid);
    await update(ref(db, `incidents/${this.gid}/${iid}`), {
      state: 'closed', closedAt: serverTimestamp(), closedBy: this.uid, closedByName: this.name
    });
    const sos = inc && inc.type === 'sos';
    this.log(iid, sos ? 'SOS cancelled by sender' : 'Report withdrawn by reporter');
    if (inc) this.emit(sos ? 'sos_cancelled' : 'withdrawn', { ...inc, state: 'closed' });
  }

  async acknowledge(iid) {
    await set(ref(db, `incidents/${this.gid}/${iid}/acks/${this.uid}`), serverTimestamp());
    this.log(iid, 'Acknowledged alert');
  }

  /** Self-dispatch to an open SOS (locks me to it, status en route). */
  async respondToSos(iid) {
    await update(ref(db), {
      [`incidents/${this.gid}/${iid}/assigned/${this.uid}`]: assignmentRecord(null, { name: this.name, state: 'enroute', by: 'self' }),
      [`incidents/${this.gid}/${iid}/acks/${this.uid}`]: serverTimestamp(),
      [`status/${this.gid}/${this.uid}`]: { state: 'enroute', incidentId: iid, name: this.name, ts: serverTimestamp() }
    });
    this.log(iid, 'Responding to SOS (en route)');
  }

  /* ---------------- Reports and cases ---------------- */

  /**
   * Report a case. Members' reports go to the Pending Review queue; a dispatcher's
   * case is verified at once, as are a fire unit's fire case and a medical unit's
   * transport request (openDirect). Returns the case id (add photos with addPhoto).
   *
   * Only a valid location is required. Everything else falls back to a default:
   * type → "other", severity → P2, title → first line of the details or
   * "<type> — <reporter>". requires: equipment ids the case asks for (informational).
   * If the database refuses an opened-at-once case (e.g. a role change not yet
   * synced, or rules older than the app), it is sent again as a plain report for
   * review, so the report is never lost.
   */
  async reportCase({
    type, title, notes, priority, lat, lng, source, status = 'open', isDispatcher = false, openDirect = false,
    requires = [], rapid = false, linkedCase = null
  } = {}) {
    const latN = Number(lat);
    const lngN = Number(lng);
    if (!Number.isFinite(latN) || !Number.isFinite(lngN) || Math.abs(latN) > 90 || Math.abs(lngN) > 180) {
      throw new Error('Set the case location: drop a pin or use your GPS.');
    }
    const cleanType = REPORTABLE_TYPES.includes(type) ? type : 'other';
    const cleanPriority = PRIORITIES[Number(priority)] ? Number(priority) : 2;
    const cleanNotes = String(notes || '').replace(/\s+/g, ' ').trim().slice(0, 1000);
    const name = String(this.name || 'Member').trim().slice(0, 40) || 'Member';
    const cleanTitle = (String(title || '').replace(/\s+/g, ' ').trim()
      || cleanNotes.split(/[.!?\n]/)[0].trim()
      || `${caseTypeLabel(cleanType)} — ${name}`).slice(0, 80);
    const gear = (Array.isArray(requires) ? requires : []).filter((g) => GEAR_IDS.includes(g));
    const cleanSource = source === 'gps' ? 'gps' : (source === 'pin' ? 'pin' : 'map');

    const build = (direct, extras) => {
      const incident = {
        type: cleanType,
        title: cleanTitle,
        priority: cleanPriority,
        state: direct ? (isDispatcher && status === 'monitoring' ? 'monitoring' : 'open') : 'pending',
        lat: Math.round(latN * 1e6) / 1e6,
        lng: Math.round(lngN * 1e6) / 1e6,
        source: cleanSource,
        createdBy: this.uid,
        createdByName: name,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      if (cleanNotes) incident.notes = cleanNotes;
      if (extras) {
        if (gear.length) incident.requires = Object.fromEntries(gear.map((g) => [g, true]));
        if (rapid && cleanType === 'fire') incident.rapid = true;
        if (linkedCase && /^[A-Za-z0-9_-]{1,64}$/.test(linkedCase)) incident.linkedCase = linkedCase;
      }
      if (direct) {
        incident.verifiedBy = this.uid;
        incident.verifiedByName = name;
        incident.verifiedAt = serverTimestamp();
      }
      return incident;
    };

    let direct = !!isDispatcher || !!openDirect;
    let incident = build(direct, true);
    let iid = push(ref(db, `incidents/${this.gid}`)).key;
    try {
      await set(ref(db, `incidents/${this.gid}/${iid}`), incident);
    } catch (err) {
      if (!isPermissionDenied(err)) throw err;
      // Fall back to the simplest record every member may write: a pending report.
      direct = false;
      incident = build(false, false);
      iid = push(ref(db, `incidents/${this.gid}`)).key;
      try {
        await set(ref(db, `incidents/${this.gid}/${iid}`), incident);
      } catch (err2) {
        if (isPermissionDenied(err2)) {
          throw new Error('The database refused the case. If Trailguard was just updated, deploy the new rules (npm run deploy:rules); otherwise check you are still a member of this group.');
        }
        throw err2;
      }
    }

    const what = `${PRIORITIES[cleanPriority].short}, ${caseTypeLabel(cleanType)}${incident.requires ? `, ${gear.map((g) => GEAR[g].short).join('+')} requested` : ''}`;
    let logText;
    if (isDispatcher && direct) logText = `Case opened by dispatch (${what})`;
    else if (direct) logText = incident.rapid ? `RAPID FIRE ALERT raised in the field (${what})` : `Opened in the field without review (${what})`;
    else logText = `Report submitted for review (${what}, ${cleanSource === 'gps' ? 'GPS location' : 'pinned location'})`;
    this.log(iid, logText);
    this.emit(direct ? 'created' : 'reported', { id: iid, ...incident });
    return { iid, direct };
  }

  /** Store a resized JPEG (data URL) for instant review; returns the photo id. */
  async addPhoto(iid, { dataUrl, width, height }) {
    const photoRef = push(ref(db, `media/${this.gid}/${iid}`));
    await set(photoRef, { uid: this.uid, name: this.name, data: dataUrl, w: width, h: height, ts: serverTimestamp() });
    return photoRef.key;
  }

  setPhotoDriveUrl(iid, pid, url) {
    return set(ref(db, `media/${this.gid}/${iid}/${pid}/driveUrl`), String(url).slice(0, 500));
  }

  listenPhotos(iid, cb) {
    return onValue(ref(db, `media/${this.gid}/${iid}`), (snap) => {
      const items = [];
      snap.forEach((child) => { items.push({ id: child.key, ...child.val() }); });
      cb(items.sort((a, b) => a.ts - b.ts));
    }, () => cb([]));
  }

  async addNote(iid, text) {
    const note = String(text || '').trim();
    if (!note) throw new Error('Write a note first.');
    await push(ref(db, `incidentLog/${this.gid}/${iid}`), {
      uid: this.uid, name: this.name, text: note.slice(0, 500), kind: 'note', ts: serverTimestamp()
    });
  }

  listenLog(iid, cb) {
    return onValue(ref(db, `incidentLog/${this.gid}/${iid}`), (snap) => {
      const items = [];
      snap.forEach((child) => { items.push({ id: child.key, ...child.val() }); });
      cb(items.sort((a, b) => a.ts - b.ts));
    }, () => cb([]));
  }

  /* ---------------- Units (responders) ---------------- */

  /** Accept a verified case (from a proximity alert or the case screen); locks me to it. me: my member record. */
  async acceptCase(iid, me) {
    const inc = this.incidents.get(iid);
    if (!inc || inc.state !== 'open') throw new Error('This case is no longer open.');
    const lock = this.myLock();
    if (lock && lock.incident.id !== iid) throw new Error(`You are already on "${lock.incident.title}". Resolve it first.`);
    const current = inc.assigned && inc.assigned[this.uid];
    if (!current) {
      const fit = responderFit(inc, me, this.settings);
      if (!fit.ok) throw new Error(`You can't take this case: ${fit.reason}.`);
    }
    const assignment = assignmentRecord(current, { name: this.name, state: 'accepted', unit: profileOf(me).unit, by: current ? null : 'self' });
    await update(ref(db), {
      [`incidents/${this.gid}/${iid}/assigned/${this.uid}`]: assignment,
      [`status/${this.gid}/${this.uid}`]: { state: 'busy', incidentId: iid, name: this.name, ts: serverTimestamp() }
    });
    this.log(iid, 'Accepted the case');
    this.emit('accepted', { ...inc, assigned: { ...(inc.assigned || {}), [this.uid]: { name: this.name, state: 'accepted' } } });
  }

  /**
   * Auto-dispatch: lock myself to a case as the closest free unit with matching
   * gear (status BUSY at once). I still confirm with Accept; if I don't answer in
   * the group's timeout the assignment lapses and the next closest unit is picked.
   */
  async autoAssignSelf(iid, me) {
    const inc = this.incidents.get(iid);
    if (!inc || inc.state !== 'open' || (inc.assigned && inc.assigned[this.uid])) return false;
    if (this.myLock()) return false;
    if (!responderFit(inc, me, this.settings).ok) return false;
    await update(ref(db), {
      [`incidents/${this.gid}/${iid}/assigned/${this.uid}`]: assignmentRecord(null, { name: this.name, state: 'assigned', unit: profileOf(me).unit, by: 'auto' }),
      [`status/${this.gid}/${this.uid}`]: { state: 'busy', incidentId: iid, name: this.name, ts: serverTimestamp() }
    });
    this.log(iid, 'Auto-assigned (closest available unit with matching equipment)');
    this.emit('assigned', { ...inc, assigned: { ...(inc.assigned || {}), [this.uid]: { name: this.name, state: 'assigned' } } });
    return true;
  }

  /** My auto-assignment went unanswered: decline it so the next unit is picked and my lock is released. */
  async lapseAutoAssignment(iid) {
    const inc = this.incidents.get(iid);
    const current = inc && inc.assigned && inc.assigned[this.uid];
    if (!current || current.state !== 'assigned' || current.by !== 'auto') return;
    await update(ref(db), {
      [`incidents/${this.gid}/${iid}/assigned/${this.uid}`]: assignmentRecord(current, { name: this.name, state: 'declined', reason: 'timeout' }),
      [`status/${this.gid}/${this.uid}`]: { state: 'available', name: this.name, ts: serverTimestamp() }
    });
    this.log(iid, 'Auto-assignment not answered in time — passed to the next unit');
  }

  /** Dispatcher housekeeping: an unanswered auto-assignment on a unit whose phone is not responding. */
  async expireAutoAssignment(iid, uid) {
    const inc = this.incidents.get(iid);
    const current = inc && inc.assigned && inc.assigned[uid];
    if (!current || !isStaleAuto(current, this.settings)) return;
    const updates = {
      [`incidents/${this.gid}/${iid}/assigned/${uid}`]: assignmentRecord(current, { name: current.name, state: 'declined', reason: 'timeout' }),
      [`incidents/${this.gid}/${iid}/updatedAt`]: serverTimestamp()
    };
    const st = this.status.get(uid);
    if (st && st.incidentId === iid) updates[`status/${this.gid}/${uid}`] = { state: 'available', name: st.name, ts: serverTimestamp() };
    await update(ref(db), updates);
    this.log(iid, `${current.name} did not answer the auto-assignment — released`);
  }

  /** Not going: hide this case's proximity alert for me (recorded for dispatch). */
  async dismiss(iid) {
    await set(ref(db, `incidents/${this.gid}/${iid}/dismissed/${this.uid}`), serverTimestamp());
    this.log(iid, 'Dismissed the proximity alert');
  }

  /** Move my assignment on; resolving or declining releases the single-task lock. */
  async setAssignmentState(iid, nextState) {
    const inc = this.incidents.get(iid);
    const current = inc && inc.assigned && inc.assigned[this.uid];
    const assignment = assignmentRecord(current, { name: this.name, state: nextState });
    const statusValue = LOCK_STATUS[nextState]
      ? { state: LOCK_STATUS[nextState], incidentId: iid, name: this.name, ts: serverTimestamp() }
      : { state: 'available', name: this.name, ts: serverTimestamp() };
    await update(ref(db), {
      [`incidents/${this.gid}/${iid}/assigned/${this.uid}`]: assignment,
      [`status/${this.gid}/${this.uid}`]: statusValue
    });
    this.log(iid, ASSIGNMENT_STATES[nextState] || nextState);
  }

  /** My manual status when not locked: available, busy (e.g. on a break) or off duty. */
  async setStatus(state) {
    if (this.myLock()) throw new Error('You are on a case. Resolve it (or ask dispatch) before changing status.');
    if (!['available', 'busy', 'offduty'].includes(state)) throw new Error('Choose a status.');
    await set(ref(db, `status/${this.gid}/${this.uid}`), { state, name: this.name, ts: serverTimestamp() });
  }

  async writeEta(iid, { seconds, meters, src }) {
    await set(ref(db, `incidents/${this.gid}/${iid}/eta/${this.uid}`), {
      s: Math.max(0, Math.min(86400, Math.round(seconds))),
      m: Math.max(0, Math.min(1000000, Math.round(meters))),
      src: src === 'route' ? 'route' : 'estimate',
      ts: serverTimestamp()
    });
  }

  /* ---------------- Dispatcher ---------------- */

  /** Approve a pending report: it becomes a verified, open case and alerts nearby units. */
  async verifyReport(iid, { type, priority, requires } = {}) {
    const inc = this.incidents.get(iid);
    if (!inc || inc.state !== 'pending') throw new Error('This report has already been reviewed.');
    const changes = {
      state: 'open',
      verifiedBy: this.uid,
      verifiedByName: this.name,
      verifiedAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    if (type && type !== inc.type && REPORTABLE_TYPES.includes(type)) changes.type = type;
    if (priority && Number(priority) !== inc.priority && PRIORITIES[priority]) changes.priority = Number(priority);
    if (Array.isArray(requires)) {
      const gear = requires.filter((g) => GEAR_IDS.includes(g));
      changes.requires = gear.length ? Object.fromEntries(gear.map((g) => [g, true])) : null;
    }
    await update(ref(db, `incidents/${this.gid}/${iid}`), changes);
    this.log(iid, `Verified by dispatch${changes.type ? ` as ${caseTypeLabel(changes.type)}` : ''}${changes.priority ? ` (${PRIORITIES[changes.priority].short})` : ''}`);
    this.emit('verified', { ...inc, ...changes, state: 'open' });
  }

  async rejectReport(iid, reason) {
    const inc = this.incidents.get(iid);
    if (!inc || inc.state !== 'pending') throw new Error('This report has already been reviewed.');
    const why = String(reason || '').trim().slice(0, 200) || 'Not actionable';
    await update(ref(db, `incidents/${this.gid}/${iid}`), {
      state: 'rejected',
      rejectReason: why,
      closedAt: serverTimestamp(),
      closedBy: this.uid,
      closedByName: this.name,
      updatedAt: serverTimestamp()
    });
    this.log(iid, `Rejected: ${why}`);
    this.emit('rejected', { ...inc, state: 'rejected', notes: [inc.notes, `Rejected: ${why}`].filter(Boolean).join(' — ') });
  }

  /** Assign a unit (sets it busy in the same write; refused if it is locked to another case). */
  async assign(iid, member) {
    const inc = this.incidents.get(iid);
    if (!inc || !isActive(inc)) throw new Error('Only verified, active cases can be assigned.');
    const lock = this.lockOf(member.uid);
    if (lock && lock.incident.id !== iid) throw new Error(`${member.name} is busy on "${lock.incident.title}".`);
    const current = inc.assigned && inc.assigned[member.uid];
    const fresh = !current || !isActiveAssignment(current);
    const assignment = assignmentRecord(fresh ? null : current, { name: member.name, state: 'assigned', unit: profileOf(member).unit, by: 'dispatch' });
    await update(ref(db), {
      [`incidents/${this.gid}/${iid}/assigned/${member.uid}`]: assignment,
      [`incidents/${this.gid}/${iid}/updatedAt`]: serverTimestamp(),
      [`status/${this.gid}/${member.uid}`]: { state: 'busy', incidentId: iid, name: member.name, ts: serverTimestamp() }
    });
    this.log(iid, `Assigned ${member.name}`);
    this.emit('assigned', { ...inc, assigned: { ...(inc.assigned || {}), [member.uid]: { name: member.name, state: 'assigned' } } });
  }

  async unassign(iid, member) {
    const updates = {
      [`incidents/${this.gid}/${iid}/assigned/${member.uid}`]: null,
      [`incidents/${this.gid}/${iid}/eta/${member.uid}`]: null,
      [`incidents/${this.gid}/${iid}/updatedAt`]: serverTimestamp()
    };
    const st = this.status.get(member.uid);
    if (st && st.incidentId === iid) {
      updates[`status/${this.gid}/${member.uid}`] = { state: 'available', name: member.name, ts: serverTimestamp() };
    }
    await update(ref(db), updates);
    this.log(iid, `Unassigned ${member.name}`);
  }

  /** Release a unit's lock without touching the case (e.g. its phone died). */
  async releaseUnit(uid, name) {
    await set(ref(db, `status/${this.gid}/${uid}`), { state: 'available', name, ts: serverTimestamp() });
  }

  async setPriority(iid, priority) {
    await update(ref(db, `incidents/${this.gid}/${iid}`), { priority: Number(priority), updatedAt: serverTimestamp() });
    this.log(iid, `Severity set to ${PRIORITIES[priority].short}`);
    const inc = this.incidents.get(iid);
    if (inc) this.emit('updated', { ...inc, priority: Number(priority) });
  }

  async setCaseStatus(iid, status) {
    if (status !== 'open' && status !== 'monitoring') throw new Error('Choose a status.');
    await update(ref(db, `incidents/${this.gid}/${iid}`), { state: status, updatedAt: serverTimestamp() });
    this.log(iid, `Status set to ${CASE_STATUSES[status]}`);
    const inc = this.incidents.get(iid);
    if (inc) this.emit('updated', { ...inc, state: status });
  }

  /** Dispatcher: equipment a responder must carry for this case. */
  async setRequires(iid, gearIds) {
    const gear = (gearIds || []).filter((g) => GEAR_IDS.includes(g));
    await update(ref(db, `incidents/${this.gid}/${iid}`), {
      requires: gear.length ? Object.fromEntries(gear.map((g) => [g, true])) : null,
      updatedAt: serverTimestamp()
    });
    this.log(iid, gear.length ? `Required equipment: ${gear.map((g) => GEAR[g].short).join(', ')}` : 'No special equipment required');
  }

  async setNeed(iid, need) {
    const n = Math.max(1, Math.min(10, Math.round(Number(need)) || 1));
    await update(ref(db, `incidents/${this.gid}/${iid}`), { need: n, updatedAt: serverTimestamp() });
    this.log(iid, `Units needed: ${n}`);
  }

  /** Close (resolve) a case and release every unit locked to it. */
  async closeIncident(iid) {
    const inc = this.incidents.get(iid);
    const updates = {
      [`incidents/${this.gid}/${iid}/state`]: 'closed',
      [`incidents/${this.gid}/${iid}/closedAt`]: serverTimestamp(),
      [`incidents/${this.gid}/${iid}/closedBy`]: this.uid,
      [`incidents/${this.gid}/${iid}/closedByName`]: this.name,
      [`incidents/${this.gid}/${iid}/updatedAt`]: serverTimestamp()
    };
    for (const [uid, st] of this.status) {
      if (st.incidentId === iid) updates[`status/${this.gid}/${uid}`] = { state: 'available', name: st.name, ts: serverTimestamp() };
    }
    await update(ref(db), updates);
    this.log(iid, 'Case resolved and closed');
    if (inc) this.emit('closed', { ...inc, state: 'closed' });
  }

  async reopenIncident(iid) {
    await update(ref(db, `incidents/${this.gid}/${iid}`), {
      state: 'open', closedAt: null, closedBy: null, closedByName: null, updatedAt: serverTimestamp()
    });
    this.log(iid, 'Case reopened');
    const inc = this.incidents.get(iid);
    if (inc) this.emit('reopened', { ...inc, state: 'open' });
  }

  async deletePhotos(iid) {
    await remove(ref(db, `media/${this.gid}/${iid}`));
  }

  /* ---------------- Settings ---------------- */

  /** Dispatchers: proximity radius, master switch, auto-assign and which roles respond to which case types. */
  async saveSettings({ proximityM, proximityOn = true, autoAssign = false, autoTimeoutS, caseUnits }) {
    const clean = {
      v: SETTINGS_VERSION,
      proximityM: Math.round(Number(proximityM)),
      proximityOn: proximityOn !== false,
      autoAssign: autoAssign === true,
      autoTimeoutS: Math.round(Number(autoTimeoutS || this.settings.autoTimeoutS)),
      caseUnits: {}
    };
    if (!Number.isFinite(clean.proximityM) || clean.proximityM < MIN_PROXIMITY_M || clean.proximityM > MAX_PROXIMITY_M) {
      throw new Error(`Proximity radius must be between ${MIN_PROXIMITY_M} and ${MAX_PROXIMITY_M} m.`);
    }
    if (!Number.isFinite(clean.autoTimeoutS) || clean.autoTimeoutS < 30 || clean.autoTimeoutS > 600) {
      throw new Error('Auto-assign answer time must be between 30 and 600 seconds.');
    }
    for (const type of REPORTABLE_TYPES) {
      const units = Object.entries((caseUnits || {})[type] || {}).filter(([u, on]) => on === true && FIELD_UNITS.includes(u));
      if (units.length) clean.caseUnits[type] = Object.fromEntries(units);
    }
    await set(ref(db, `groups/${this.gid}/settings`), clean);
  }

  /**
   * Groups created before 1.3 have no settings, and 1.3 settings name the old
   * units: a dispatcher writes 1.4 defaults once (an earlier radius is kept, clamped).
   */
  async ensureSettings() {
    if (!this.settingsLoaded || (!this.settingsMissing && this.settingsVersion === SETTINGS_VERSION)) return;
    const next = defaultSettings();
    if (!this.settingsMissing && Number.isFinite(this.settings.proximityM)) next.proximityM = this.settings.proximityM;
    await set(ref(db, `groups/${this.gid}/settings`), next);
  }
}
