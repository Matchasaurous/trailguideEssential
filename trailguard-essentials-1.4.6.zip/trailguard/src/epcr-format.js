// Patient care record vocabulary and the pure parts of the ePCR: vital-sign
// ranges and abnormal flags, form cleaning and the SOAP handover generator.
// No database access, so it can be used by analytics and tests directly.
import { caseTypeLabel } from './roles.js';

export const DISPOSITIONS = {
  released: 'Treated and released',
  transported: 'Transported',
  handover: 'Handed over (ambulance / hospital / doctor)',
  refused: 'Refused care or transport',
  other: 'Other'
};

export const TRIAGE = {
  red: 'Red — immediate',
  yellow: 'Yellow — urgent',
  green: 'Green — minor / walking',
  black: 'Black — deceased / expectant'
};

export const SEXES = { M: 'Male', F: 'Female', X: 'Other', U: 'Unknown' };

/** Accepted ranges (match database.rules.json) and the normal range used to flag values. */
export const VITAL_FIELDS = {
  hr: { label: 'HR', unit: '/min', min: 0, max: 300, low: 50, high: 120, step: 1 },
  sbp: { label: 'SBP', unit: 'mmHg', min: 0, max: 300, low: 90, high: 180, step: 1 },
  dbp: { label: 'DBP', unit: 'mmHg', min: 0, max: 250, low: 40, high: 110, step: 1 },
  spo2: { label: 'SpO₂', unit: '%', min: 0, max: 100, low: 94, high: 101, step: 1 },
  rr: { label: 'RR', unit: '/min', min: 0, max: 80, low: 10, high: 24, step: 1 },
  temp: { label: 'Temp', unit: '°C', min: 25, max: 45, low: 35, high: 38.5, step: 0.1 },
  gcsE: { label: 'GCS E', unit: '', min: 1, max: 4, step: 1 },
  gcsV: { label: 'GCS V', unit: '', min: 1, max: 5, step: 1 },
  gcsM: { label: 'GCS M', unit: '', min: 1, max: 6, step: 1 },
  bgl: { label: 'BGL', unit: 'mmol/L', min: 0, max: 50, low: 4, high: 11, step: 0.1 },
  pain: { label: 'Pain', unit: '/10', min: 0, max: 10, step: 1 }
};

const INFO_TEXT = {
  complaint: 200, history: 1000, allergies: 200, ownMeds: 300, findings: 1000, assessment: 500, plan: 500, destination: 120
};

/** GCS total, or null unless all three components are present. */
export function gcsTotal(v) {
  return v && Number.isFinite(v.gcsE) && Number.isFinite(v.gcsV) && Number.isFinite(v.gcsM) ? v.gcsE + v.gcsV + v.gcsM : null;
}

/** Field names in a vitals set that are outside the normal range (GCS < 15 counts). */
export function abnormal(v) {
  const out = [];
  for (const [key, f] of Object.entries(VITAL_FIELDS)) {
    if (!Number.isFinite(v[key]) || f.low === undefined) continue;
    if (v[key] < f.low || v[key] > f.high) out.push(key);
  }
  const gcs = gcsTotal(v);
  if (gcs !== null && gcs < 15) out.push('gcs');
  return out;
}

/** Clean a vitals form: numbers within range only; at least one value. Throws with a readable message. */
export function cleanVitals(input) {
  const out = {};
  for (const [key, f] of Object.entries(VITAL_FIELDS)) {
    const raw = input[key];
    if (raw === '' || raw === null || raw === undefined) continue;
    const n = Number(raw);
    if (!Number.isFinite(n) || n < f.min || n > f.max) throw new Error(`${f.label} must be between ${f.min} and ${f.max}.`);
    out[key] = f.step < 1 ? Math.round(n * 10) / 10 : Math.round(n);
  }
  if (!Object.keys(out).length) throw new Error('Enter at least one vital sign.');
  const gcsParts = ['gcsE', 'gcsV', 'gcsM'].filter((k) => k in out).length;
  if (gcsParts > 0 && gcsParts < 3) throw new Error('Enter all three GCS parts (E, V and M), or none.');
  return out;
}

export function cleanInfoPatch(patch) {
  const out = {};
  for (const [key, max] of Object.entries(INFO_TEXT)) {
    if (key in patch) out[key] = String(patch[key] || '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max);
  }
  if ('disposition' in patch) out.disposition = DISPOSITIONS[patch.disposition] ? patch.disposition : null;
  if ('triage' in patch) out.triage = TRIAGE[patch.triage] ? patch.triage : null;
  if ('patient' in patch) {
    const p = patch.patient || {};
    const patient = {};
    const age = Number(p.age);
    if (p.age !== '' && p.age !== null && p.age !== undefined && Number.isFinite(age) && age >= 0 && age <= 130) patient.age = Math.round(age);
    if (SEXES[p.sex]) patient.sex = p.sex;
    const ident = String(p.ident || '').trim().slice(0, 60);
    if (ident) patient.ident = ident;
    out.patient = Object.keys(patient).length ? patient : null;
  }
  if ('status' in patch) out.status = patch.status === 'closed' ? 'closed' : 'open';
  return out;
}

function fmtTime(ts) {
  if (!Number.isFinite(ts)) return '--:--';
  return new Date(ts).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
}

function fmtDateTime(ts) {
  if (!Number.isFinite(ts)) return 'unknown';
  return new Date(ts).toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export function describeVitals(v) {
  const parts = [];
  if (Number.isFinite(v.hr)) parts.push(`HR ${v.hr}`);
  if (Number.isFinite(v.sbp) || Number.isFinite(v.dbp)) parts.push(`BP ${Number.isFinite(v.sbp) ? v.sbp : '?'}/${Number.isFinite(v.dbp) ? v.dbp : '?'}`);
  if (Number.isFinite(v.spo2)) parts.push(`SpO2 ${v.spo2}%`);
  if (Number.isFinite(v.rr)) parts.push(`RR ${v.rr}`);
  if (Number.isFinite(v.temp)) parts.push(`T ${v.temp}°C`);
  const gcs = gcsTotal(v);
  if (gcs !== null) parts.push(`GCS ${gcs} (E${v.gcsE}V${v.gcsV}M${v.gcsM})`);
  if (Number.isFinite(v.bgl)) parts.push(`BGL ${v.bgl}`);
  if (Number.isFinite(v.pain)) parts.push(`Pain ${v.pain}/10`);
  return parts.join(', ');
}

const sorted = (obj) => Object.entries(obj || {}).map(([id, v]) => ({ id, ...v })).sort((a, b) => (a.ts || 0) - (b.ts || 0));

/**
 * Structured SOAP handover note (plain text) for a patient record.
 * @param {object} record { id, info, vitals, treatments, meds }
 * @param {{incident?: object, groupName?: string}} ctx
 */
export function generateSoap(record, { incident = null, groupName = '' } = {}) {
  const info = record.info || {};
  const p = info.patient || {};
  const vitals = sorted(record.vitals);
  const treatments = sorted(record.treatments);
  const meds = sorted(record.meds);
  const lines = [];
  const who = [Number.isFinite(p.age) ? `${p.age} y` : 'age unknown', SEXES[p.sex] || 'sex unknown', p.ident ? `ID ${p.ident}` : null]
    .filter(Boolean).join(', ');
  lines.push('PATIENT HANDOVER — SOAP');
  lines.push(`Patient: ${who}${info.triage ? ` · Triage ${TRIAGE[info.triage]}` : ''}`);
  if (incident) {
    lines.push(`Case: ${incident.title} (${caseTypeLabel(incident.type)}, P${incident.priority})${groupName ? ` · ${groupName}` : ''}`);
    if (Number.isFinite(incident.lat)) lines.push(`Location: ${incident.lat.toFixed(5)}, ${incident.lng.toFixed(5)}`);
  }
  lines.push(`First contact: ${fmtDateTime(info.createdAt)} · Record by ${info.byName || 'medic'}`);
  lines.push('');
  lines.push('S — SUBJECTIVE');
  lines.push(`Chief complaint: ${info.complaint || 'not recorded'}`);
  if (info.history) lines.push(`History: ${info.history}`);
  lines.push(`Allergies: ${info.allergies || 'not recorded'}`);
  lines.push(`Own medications: ${info.ownMeds || 'not recorded'}`);
  lines.push('');
  lines.push('O — OBJECTIVE');
  if (vitals.length) {
    lines.push('Vital signs:');
    for (const v of vitals) {
      const flags = abnormal(v);
      lines.push(`  ${fmtTime(v.ts)}  ${describeVitals(v)}${flags.length ? '  [ABNORMAL]' : ''}  (${v.name})`);
    }
  } else {
    lines.push('Vital signs: none recorded');
  }
  if (info.findings) lines.push(`Examination: ${info.findings}`);
  lines.push('');
  lines.push('A — ASSESSMENT');
  lines.push(info.assessment || 'Not recorded');
  const last = vitals[vitals.length - 1];
  if (last) {
    const flags = abnormal(last);
    if (flags.length) lines.push(`Latest abnormal values: ${flags.map((f) => (f === 'gcs' ? 'GCS' : VITAL_FIELDS[f].label)).join(', ')}`);
  }
  lines.push('');
  lines.push('P — PLAN / CARE GIVEN');
  if (treatments.length) {
    lines.push('Treatments:');
    for (const t of treatments) lines.push(`  ${fmtTime(t.ts)}  ${t.text}  (${t.name})`);
  } else {
    lines.push('Treatments: none recorded');
  }
  if (meds.length) {
    lines.push('Medications given:');
    for (const m of meds) lines.push(`  ${fmtTime(m.ts)}  ${m.drug}${m.dose ? ` ${m.dose}` : ''}${m.route ? ` ${m.route}` : ''}  (${m.name})`);
  } else {
    lines.push('Medications given: none');
  }
  if (info.plan) lines.push(`Plan: ${info.plan}`);
  lines.push(`Disposition: ${info.disposition ? DISPOSITIONS[info.disposition] : 'not yet decided'}${info.destination ? ` → ${info.destination}` : ''}`);
  lines.push('');
  lines.push(`Generated by Trailguard Essentials ${fmtDateTime(Date.now())}`);
  return lines.join('\n');
}

