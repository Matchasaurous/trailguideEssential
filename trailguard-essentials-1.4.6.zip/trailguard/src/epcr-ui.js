// ePCR screen: one tab per patient on a case; patient details, SOAP sections,
// timed vital signs (with abnormal values flagged), treatments and medications,
// disposition; SOAP handover (copy / share), archive to Drive, request transport.
// Text fields save when they change (on blur), entries are added one at a time.
import { $, h, toast, openSheet, closeSheets, isSheetOpen } from './ui.js';
import {
  VITAL_FIELDS, DISPOSITIONS, abnormal, gcsTotal, generateSoap
} from './epcr.js';
import { caseTypeLabel } from './roles.js';

const TEXT_FIELDS = {
  'epcr-complaint': 'complaint',
  'epcr-history': 'history',
  'epcr-allergies': 'allergies',
  'epcr-ownmeds': 'ownMeds',
  'epcr-findings': 'findings',
  'epcr-assessment': 'assessment',
  'epcr-plan': 'plan',
  'epcr-destination': 'destination',
  'epcr-disposition': 'disposition',
  'epcr-triage': 'triage'
};
const PATIENT_FIELDS = ['epcr-age', 'epcr-sex', 'epcr-ident'];
const VITAL_INPUTS = Object.keys(VITAL_FIELDS).map((k) => [k, `v-${k}`]);

const sortedEntries = (obj) => Object.entries(obj || {}).map(([id, v]) => ({ id, ...v })).sort((a, b) => (a.ts || 0) - (b.ts || 0));
const time = (ts) => (Number.isFinite(ts) ? new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '');

export class EpcrUI {
  /**
   * @param {object} ctx
   *   store (EpcrStore), dispatch (Dispatch), bodycam (Bodycam), getGroupName(),
   *   requestTransport(iid), canTransport(): boolean
   */
  constructor(ctx) {
    this.ctx = ctx;
    this.ac = new AbortController();
    this.iid = null;
    this.pid = null;
    this.records = [];
    this.unsub = null;
    this.saving = 0;
  }

  on(selector, event, handler) {
    $(selector).addEventListener(event, handler, { signal: this.ac.signal });
  }

  start() {
    this.on('#epcr-new', 'click', () => this.newPatient());
    for (const [id, key] of Object.entries(TEXT_FIELDS)) {
      this.on(`#${id}`, 'change', (e) => this.save({ [key]: e.target.value }));
    }
    for (const id of PATIENT_FIELDS) this.on(`#${id}`, 'change', () => this.save({ patient: this.patientFromForm() }));
    for (const k of ['gcsE', 'gcsV', 'gcsM']) this.on(`#v-${k}`, 'change', () => this.renderGcsPreview());
    this.on('#epcr-add-vitals', 'click', () => this.addVitals());
    this.on('#epcr-add-treatment', 'click', () => this.addTreatment());
    this.on('#epcr-treatment', 'keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); this.addTreatment(); } });
    this.on('#epcr-add-med', 'click', () => this.addMedication());
    this.on('#epcr-handover', 'click', () => this.showHandover());
    this.on('#epcr-archive', 'click', () => this.archive());
    this.on('#epcr-request-transport', 'click', () => { if (this.iid) this.ctx.requestTransport(this.iid); });
    this.on('#epcr-close', 'click', () => this.closeRecord());
    this.on('#epcr-soap-copy', 'click', () => this.copySoap());
    this.on('#epcr-soap-share', 'click', () => this.shareSoap());
    this.on('#epcr-soap-hide', 'click', () => { $('#epcr-soap-wrap').hidden = true; });
    this.on('#epcr-form', 'submit', (e) => e.preventDefault());
  }

  stop() {
    this.ac.abort();
    if (this.unsub) this.unsub();
    this.unsub = null;
  }

  /** Open the patient records of a case (optionally a given patient). */
  open(iid, pid = null) {
    const inc = this.ctx.dispatch.incidents.get(iid);
    if (!inc) {
      toast('That case is no longer available.');
      return;
    }
    if (this.iid !== iid) {
      if (this.unsub) this.unsub();
      this.iid = iid;
      this.pid = pid;
      this.records = [];
      this.unsub = this.ctx.store.listen(iid, (records) => {
        if (this.iid !== iid) return;
        this.records = records;
        if (!this.pid || !records.some((r) => r.id === this.pid)) this.pid = records.length ? records[records.length - 1].id : null;
        this.render();
      }, (err) => toast(`Patient records unavailable: ${err.message}`, 'error'));
    } else if (pid) {
      this.pid = pid;
    }
    $('#epcr-soap-wrap').hidden = true;
    $('#epcr-case').textContent = `${inc.title} · ${caseTypeLabel(inc.type)} · P${inc.priority}`;
    openSheet('epcr-sheet', () => {
      if (this.unsub) this.unsub();
      this.unsub = null;
      this.iid = null;
      this.pid = null;
    });
    this.render();
  }

  get record() {
    return this.records.find((r) => r.id === this.pid) || null;
  }

  render() {
    if (!isSheetOpen('epcr-sheet')) return;
    const records = this.records;
    $('#epcr-empty').hidden = records.length > 0;
    $('#epcr-patients').replaceChildren(...records.map((r, i) => {
      const p = r.info.patient || {};
      const label = [`Patient ${i + 1}`, Number.isFinite(p.age) ? `${p.age}${p.sex && p.sex !== 'U' ? p.sex : ''}` : null, r.info.triage ? r.info.triage.toUpperCase() : null]
        .filter(Boolean).join(' · ');
      return h('button', {
        type: 'button',
        role: 'tab',
        class: `patient-tab${r.id === this.pid ? ' active' : ''}${r.info.status === 'closed' ? ' closed' : ''}`,
        'aria-selected': String(r.id === this.pid),
        dataset: { triage: r.info.triage || '' },
        onClick: () => { this.pid = r.id; $('#epcr-soap-wrap').hidden = true; this.render(); }
      }, label);
    }));
    const rec = this.record;
    $('#epcr-form').hidden = !rec;
    if (!rec) return;
    this.fillForm(rec);
    this.renderVitals(rec);
    this.renderEntries(rec);
    this.renderGcsPreview();
    $('#epcr-request-transport').hidden = !this.ctx.canTransport();
    $('#epcr-close').textContent = rec.info.status === 'closed' ? 'Reopen record' : 'Close record';
    $('#epcr-archive').textContent = rec.info.driveUrl ? 'Save to Drive again' : 'Save to Drive';
  }

  /** Put stored values into the form, except the field being edited. */
  fillForm(rec) {
    const info = rec.info;
    const set = (id, value) => {
      const el = $(`#${id}`);
      if (document.activeElement === el) return;
      el.value = value === undefined || value === null ? '' : String(value);
    };
    const p = info.patient || {};
    set('epcr-age', p.age);
    set('epcr-sex', p.sex || '');
    set('epcr-ident', p.ident);
    for (const [id, key] of Object.entries(TEXT_FIELDS)) set(id, info[key] || '');
  }

  renderVitals(rec) {
    const rows = sortedEntries(rec.vitals);
    const table = $('#epcr-vitals');
    if (!rows.length) {
      table.replaceChildren(h('tbody', {}, h('tr', {}, h('td', { class: 'muted small' }, 'No vital signs yet.'))));
      return;
    }
    const cell = (v, key, text) => h('td', { class: abnormal(v).includes(key) ? 'abn' : '' }, text);
    table.replaceChildren(
      h('thead', {}, h('tr', {}, ...['Time', 'HR', 'BP', 'SpO₂', 'RR', 'T °C', 'GCS', 'BGL', 'Pain', 'By'].map((t) => h('th', {}, t)))),
      h('tbody', {}, ...rows.map((v) => {
        const gcs = gcsTotal(v);
        const flags = abnormal(v);
        return h('tr', {},
          h('td', {}, time(v.ts)),
          cell(v, 'hr', Number.isFinite(v.hr) ? String(v.hr) : ''),
          h('td', { class: flags.includes('sbp') || flags.includes('dbp') ? 'abn' : '' },
            Number.isFinite(v.sbp) || Number.isFinite(v.dbp) ? `${v.sbp ?? '?'}/${v.dbp ?? '?'}` : ''),
          cell(v, 'spo2', Number.isFinite(v.spo2) ? String(v.spo2) : ''),
          cell(v, 'rr', Number.isFinite(v.rr) ? String(v.rr) : ''),
          cell(v, 'temp', Number.isFinite(v.temp) ? String(v.temp) : ''),
          h('td', { class: flags.includes('gcs') ? 'abn' : '' }, gcs !== null ? `${gcs} (${v.gcsE}/${v.gcsV}/${v.gcsM})` : ''),
          cell(v, 'bgl', Number.isFinite(v.bgl) ? String(v.bgl) : ''),
          h('td', {}, Number.isFinite(v.pain) ? String(v.pain) : ''),
          h('td', { class: 'muted' }, v.name));
      })));
  }

  renderEntries(rec) {
    const treatments = sortedEntries(rec.treatments);
    $('#epcr-treatments').replaceChildren(...treatments.map((t) => h('li', {},
      h('span', { class: 'when' }, time(t.ts)), h('span', { class: 'grow' }, t.text), h('span', { class: 'small muted' }, t.name))));
    const meds = sortedEntries(rec.meds);
    $('#epcr-meds').replaceChildren(...meds.map((m) => h('li', {},
      h('span', { class: 'when' }, time(m.ts)),
      h('span', { class: 'grow' }, [m.drug, m.dose, m.route].filter(Boolean).join(' · ')),
      h('span', { class: 'small muted' }, m.name))));
  }

  renderGcsPreview() {
    const v = {};
    for (const k of ['gcsE', 'gcsV', 'gcsM']) {
      const raw = $(`#v-${k}`).value;
      if (raw !== '') v[k] = Number(raw);
    }
    const total = gcsTotal(v);
    $('#v-gcs-total').textContent = total !== null ? `· GCS ${total}` : '';
  }

  patientFromForm() {
    return { age: $('#epcr-age').value, sex: $('#epcr-sex').value, ident: $('#epcr-ident').value };
  }

  setSaved(text) {
    $('#epcr-saved').textContent = text;
  }

  async save(patch) {
    if (!this.iid || !this.pid) return;
    this.saving += 1;
    this.setSaved('Saving…');
    try {
      await this.ctx.store.updateInfo(this.iid, this.pid, patch);
      this.setSaved(`Saved ${time(Date.now())}`);
    } catch (err) {
      this.setSaved('Not saved');
      toast(/permission/i.test(err.message) ? 'Only medical responders and dispatchers can edit patient records.' : err.message, 'error');
    } finally {
      this.saving -= 1;
    }
  }

  async newPatient() {
    if (!this.iid) return;
    try {
      this.pid = await this.ctx.store.createPatient(this.iid, {});
      this.setSaved('New patient record');
      this.render();
      $('#epcr-age').focus();
    } catch (err) {
      toast(/permission/i.test(err.message) ? 'Only medical responders and dispatchers can create patient records.' : err.message, 'error');
    }
  }

  async addVitals() {
    if (!this.iid || !this.pid) return;
    const input = {};
    for (const [key, id] of VITAL_INPUTS) input[key] = $(`#${id}`).value;
    try {
      const v = await this.ctx.store.addVitals(this.iid, this.pid, input);
      for (const [, id] of VITAL_INPUTS) $(`#${id}`).value = '';
      this.renderGcsPreview();
      const flags = abnormal(v);
      toast(flags.length ? `Vitals added — abnormal: ${flags.map((f) => (f === 'gcs' ? 'GCS' : VITAL_FIELDS[f].label)).join(', ')}` : 'Vitals added', flags.length ? 'error' : 'ok');
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  async addTreatment() {
    if (!this.iid || !this.pid) return;
    try {
      await this.ctx.store.addTreatment(this.iid, this.pid, $('#epcr-treatment').value);
      $('#epcr-treatment').value = '';
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  async addMedication() {
    if (!this.iid || !this.pid) return;
    try {
      await this.ctx.store.addMedication(this.iid, this.pid, {
        drug: $('#epcr-drug').value, dose: $('#epcr-dose').value, route: $('#epcr-route').value
      });
      $('#epcr-drug').value = '';
      $('#epcr-dose').value = '';
      $('#epcr-route').value = '';
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  soapText() {
    const rec = this.record;
    if (!rec) return '';
    return generateSoap(rec, { incident: this.ctx.dispatch.incidents.get(this.iid), groupName: this.ctx.getGroupName() });
  }

  async showHandover() {
    // Let a field that is still focused save first.
    if (document.activeElement && document.activeElement.form === $('#epcr-form')) document.activeElement.blur();
    $('#epcr-soap').value = this.soapText();
    $('#epcr-soap-wrap').hidden = false;
    $('#epcr-soap').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  async copySoap() {
    try {
      await navigator.clipboard.writeText($('#epcr-soap').value);
      toast('Handover copied', 'ok');
    } catch {
      $('#epcr-soap').select();
      toast('Select all and copy the handover text.');
    }
  }

  async shareSoap() {
    const text = $('#epcr-soap').value;
    if (!navigator.share) {
      await this.copySoap();
      return;
    }
    try {
      await navigator.share({ title: 'Patient handover', text });
    } catch (err) {
      if (err && err.name !== 'AbortError') toast('Could not share — copy it instead.', 'error');
    }
  }

  async archive() {
    const rec = this.record;
    if (!rec) return;
    const button = $('#epcr-archive');
    button.disabled = true;
    try {
      this.ctx.bodycam.groupName = this.ctx.getGroupName();
      const inc = this.ctx.dispatch.incidents.get(this.iid);
      const file = await this.ctx.bodycam.sendEpcr({
        caseId: this.iid,
        patientId: rec.id,
        caseTitle: inc ? inc.title : '',
        record: { info: rec.info, vitals: rec.vitals, treatments: rec.treatments, meds: rec.meds },
        soap: this.soapText()
      });
      if (file && file.url) await this.ctx.store.setDriveUrl(this.iid, rec.id, file.url);
      toast('Patient record saved to the restricted Drive folder', 'ok');
    } catch (err) {
      toast(`Not saved to Drive: ${err.message}`, 'error', 6000);
    } finally {
      button.disabled = false;
    }
  }

  async closeRecord() {
    const rec = this.record;
    if (!rec) return;
    if (rec.info.status === 'closed') {
      await this.save({ status: 'open' });
      return;
    }
    if (!rec.info.disposition && !confirm('No disposition recorded yet. Close this record anyway?')) return;
    await this.save({ status: 'closed' });
    toast(`Record closed${rec.info.disposition ? ` — ${DISPOSITIONS[rec.info.disposition]}` : ''}. Save it to Drive for the archive.`, 'ok');
  }

  close() {
    if (isSheetOpen('epcr-sheet')) closeSheets();
  }
}
