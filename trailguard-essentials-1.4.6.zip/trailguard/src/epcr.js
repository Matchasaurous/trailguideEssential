// Digital ePCR (electronic patient care record) for medical responders.
//
// One record per patient, under the case it belongs to:
//   epcr/{gid}/{caseId}/{patientId}/info        — patient, complaint, history, exam,
//                                                  assessment, plan, disposition (editable)
//   epcr/{gid}/{caseId}/{patientId}/vitals/*    — timed vital-sign sets (append-only)
//   epcr/{gid}/{caseId}/{patientId}/treatments/* — treatments given (append-only)
//   epcr/{gid}/{caseId}/{patientId}/meds/*      — medications given (append-only)
// Only medical responders and dispatchers can read or write these (database
// rules). Entries are append-only so the record is an audit trail; a correction
// is a new entry. generateSoap() turns a record into a structured handover note
// for the ambulance crew or hospital, and the record can be archived to the
// restricted "Patient Records" folder in Google Drive through the Apps Script.
//
// Privacy (Singapore PDPA / similar laws): record only what care needs. The
// patient identifier is optional (a bib or wristband number is enough); names
// and NRIC numbers are not required anywhere.
import { ref, set, push, update, onValue, serverTimestamp } from 'firebase/database';
import { db } from './firebase.js';
import { cleanInfoPatch, cleanVitals } from './epcr-format.js';

export {
  DISPOSITIONS, TRIAGE, SEXES, VITAL_FIELDS, gcsTotal, abnormal, cleanVitals, describeVitals, generateSoap
} from './epcr-format.js';

/** Read / write patient records for one group. */
export class EpcrStore {
  constructor({ gid, uid, name }) {
    this.gid = gid;
    this.uid = uid;
    this.name = name;
  }

  path(iid, pid = null, child = null) {
    return ['epcr', this.gid, iid, pid, child].filter(Boolean).join('/');
  }

  /** cb(records: Array<{id, info, vitals, treatments, meds}>) for every patient on a case. */
  listen(iid, cb, onError) {
    return onValue(ref(db, this.path(iid)), (snap) => {
      const records = [];
      snap.forEach((child) => {
        const v = child.val() || {};
        if (v.info) records.push({ id: child.key, info: v.info, vitals: v.vitals || {}, treatments: v.treatments || {}, meds: v.meds || {} });
      });
      cb(records.sort((a, b) => (a.info.createdAt || 0) - (b.info.createdAt || 0)));
    }, (err) => { if (onError) onError(err); cb([]); });
  }

  /** Every record in the group (dispatchers, for after-action analytics). */
  listenAll(cb) {
    return onValue(ref(db, `epcr/${this.gid}`), (snap) => cb(snap.val() || {}), () => cb({}));
  }

  async createPatient(iid, patch = {}) {
    const node = push(ref(db, this.path(iid)));
    const info = {
      ...cleanInfoPatch(patch),
      by: this.uid,
      byName: this.name,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      updatedBy: this.uid,
      status: 'open'
    };
    for (const k of Object.keys(info)) if (info[k] === null) delete info[k];
    await set(ref(db, this.path(iid, node.key, 'info')), info);
    return node.key;
  }

  async updateInfo(iid, pid, patch) {
    const clean = cleanInfoPatch(patch);
    if (!Object.keys(clean).length) return;
    await update(ref(db, this.path(iid, pid, 'info')), { ...clean, updatedAt: serverTimestamp(), updatedBy: this.uid });
  }

  async addVitals(iid, pid, input) {
    const v = cleanVitals(input);
    await set(push(ref(db, this.path(iid, pid, 'vitals'))), { ...v, by: this.uid, name: this.name, ts: serverTimestamp() });
    return v;
  }

  async addTreatment(iid, pid, text) {
    const clean = String(text || '').trim().slice(0, 200);
    if (!clean) throw new Error('Describe the treatment.');
    await set(push(ref(db, this.path(iid, pid, 'treatments'))), { text: clean, by: this.uid, name: this.name, ts: serverTimestamp() });
  }

  async addMedication(iid, pid, { drug, dose, route }) {
    const d = String(drug || '').trim().slice(0, 80);
    if (!d) throw new Error('Enter the medication name.');
    const entry = { drug: d, by: this.uid, name: this.name, ts: serverTimestamp() };
    const cleanDose = String(dose || '').trim().slice(0, 40);
    const cleanRoute = String(route || '').trim().slice(0, 30);
    if (cleanDose) entry.dose = cleanDose;
    if (cleanRoute) entry.route = cleanRoute;
    await set(push(ref(db, this.path(iid, pid, 'meds'))), entry);
  }

  async setDriveUrl(iid, pid, url) {
    if (!/^https:\/\//.test(String(url))) return;
    await update(ref(db, this.path(iid, pid, 'info')), { driveUrl: String(url).slice(0, 500), updatedAt: serverTimestamp(), updatedBy: this.uid });
  }
}
