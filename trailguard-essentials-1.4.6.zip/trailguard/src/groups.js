// Group lifecycle: create, join by code, leave, disband, remove/block members,
// rotate invite codes. All writes are multi-path updates so each operation is
// atomic, and database.rules.json enforces who may do what.
import { ref, get, set, update, remove, push, serverTimestamp } from 'firebase/database';
import { db } from './firebase.js';
import { defaultSettings, FIELD_UNITS, GEAR, MODES } from './roles.js';
import { setting } from './runtime-config.js';

const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 32 symbols, no I/O/0/1
const CODE_RE = /^[A-HJ-NP-Z2-9]{8}$/;

export function generateCode() {
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => CODE_ALPHABET[b % 32]).join(''); // 256 % 32 === 0: unbiased
}

/** Accepts "abcd-efgh", "ABCD EFGH", a full invite URL, etc. Returns null if invalid. */
export function normalizeCode(input) {
  let text = String(input || '').trim();
  const match = text.match(/[?&#]join=([A-Za-z0-9-]+)/);
  if (match) text = match[1];
  const code = text.toUpperCase().replace(/[^A-Z0-9]/g, '');
  return CODE_RE.test(code) ? code : null;
}

export function formatCode(code) {
  return code ? `${code.slice(0, 4)}-${code.slice(4)}` : '';
}

export function inviteLink(code) {
  const base = String(setting('publicUrl', import.meta.env.VITE_PUBLIC_URL || '') || '').trim() || `${location.origin}${location.pathname}`;
  const url = new URL(base);
  url.searchParams.set('join', code);
  return url.toString();
}

function isPermissionDenied(err) {
  return !!err && /permission[_ ]denied/i.test(`${err.code || ''} ${err.message || ''}`);
}

export async function saveProfile(user, displayName) {
  await update(ref(db, `users/${user.uid}/profile`), {
    displayName,
    email: user.email || '',
    createdAt: Date.now()
  });
}

export async function loadProfileName(user) {
  try {
    const snap = await get(ref(db, `users/${user.uid}/profile/displayName`));
    return snap.exists() ? snap.val() : null;
  } catch {
    return null;
  }
}

/** Groups the user belongs to. Index entries for groups we were removed from are cleaned up. */
export async function listMyGroups(uid) {
  const snap = await get(ref(db, `users/${uid}/groups`));
  const ids = snap.exists() ? Object.keys(snap.val()) : [];
  const results = await Promise.all(ids.map(async (gid) => {
    try {
      const [meta, member] = await Promise.all([
        get(ref(db, `groups/${gid}/meta`)),
        get(ref(db, `groups/${gid}/members/${uid}`))
      ]);
      if (!meta.exists() || !member.exists()) throw Object.assign(new Error('gone'), { code: 'PERMISSION_DENIED' });
      return { gid, ...meta.val(), role: member.val().role };
    } catch (err) {
      if (isPermissionDenied(err)) {
        await remove(ref(db, `users/${uid}/groups/${gid}`)).catch(() => {});
        return null;
      }
      throw err;
    }
  }));
  return results.filter(Boolean).sort((a, b) => a.name.localeCompare(b.name));
}

export async function createGroup(user, groupName, displayName) {
  const name = String(groupName || '').trim().slice(0, 60);
  if (!name) throw new Error('Give the group a name.');
  const gid = push(ref(db, 'groups')).key;

  for (let attempt = 0; attempt < 4; attempt++) {
    const code = generateCode();
    try {
      await update(ref(db), {
        [`groups/${gid}/meta`]: { name, owner: user.uid, code, createdAt: serverTimestamp() },
        [`groups/${gid}/members/${user.uid}`]: { name: displayName, role: 'owner', code, joinedAt: serverTimestamp() },
        [`groups/${gid}/settings`]: defaultSettings(),
        [`groupCodes/${code}`]: gid,
        [`users/${user.uid}/groups/${gid}`]: true
      });
      return { gid, code, name };
    } catch (err) {
      // A code collision makes the groupCodes write fail; try a fresh code.
      if (!isPermissionDenied(err) || attempt === 3) throw err;
    }
  }
  throw new Error('Could not create the group.');
}

export async function joinGroup(user, rawCode, displayName) {
  const code = normalizeCode(rawCode);
  if (!code) throw new Error('Invite codes are 8 characters, like ABCD-EFGH.');
  const codeSnap = await get(ref(db, `groupCodes/${code}`));
  if (!codeSnap.exists()) throw new Error('No group uses that code. Check it with the group owner.');
  const gid = codeSnap.val();

  // Already a member? (Reading the member node only succeeds for members.)
  try {
    const existing = await get(ref(db, `groups/${gid}/members/${user.uid}`));
    if (existing.exists()) {
      await set(ref(db, `users/${user.uid}/groups/${gid}`), true);
      return gid;
    }
  } catch (err) {
    if (!isPermissionDenied(err)) throw err;
  }

  try {
    await update(ref(db), {
      [`groups/${gid}/members/${user.uid}`]: { name: displayName, role: 'member', code, joinedAt: serverTimestamp() },
      [`users/${user.uid}/groups/${gid}`]: true
    });
  } catch (err) {
    if (isPermissionDenied(err)) throw new Error('You cannot join this group. The code may have changed, or the owner blocked you.');
    throw err;
  }
  return gid;
}

export async function leaveGroup(uid, gid) {
  await update(ref(db), {
    [`groups/${gid}/members/${uid}`]: null,
    [`presence/${gid}/${uid}`]: null,
    [`locations/${gid}/${uid}`]: null,
    [`signals/${gid}/${uid}`]: null,
    [`status/${gid}/${uid}`]: null,
    [`users/${uid}/groups/${gid}`]: null
  });
}

export async function disbandGroup(uid, gid, code) {
  const updates = {
    [`groups/${gid}`]: null,
    [`presence/${gid}`]: null,
    [`locations/${gid}`]: null,
    [`ptt/${gid}`]: null,
    [`signals/${gid}`]: null,
    [`uploads/${gid}`]: null,
    [`incidents/${gid}`]: null,
    [`incidentLog/${gid}`]: null,
    [`status/${gid}`]: null,
    [`media/${gid}`]: null,
    [`liveRequests/${gid}`]: null,
    [`epcr/${gid}`]: null,
    [`announcements/${gid}`]: null,
    [`overlays/${gid}`]: null,
    [`users/${uid}/groups/${gid}`]: null
  };
  if (code) updates[`groupCodes/${code}`] = null;
  await update(ref(db), updates);
}

export async function removeMember(gid, targetUid, targetName, block) {
  const updates = {
    [`groups/${gid}/members/${targetUid}`]: null,
    [`presence/${gid}/${targetUid}`]: null,
    [`locations/${gid}/${targetUid}`]: null,
    [`status/${gid}/${targetUid}`]: null
  };
  if (block) updates[`groups/${gid}/banned/${targetUid}`] = String(targetName || 'Member').slice(0, 40);
  await update(ref(db), updates);
}

export async function unblockMember(gid, targetUid) {
  await remove(ref(db, `groups/${gid}/banned/${targetUid}`));
}

export async function rotateCode(gid, oldCode) {
  for (let attempt = 0; attempt < 4; attempt++) {
    const code = generateCode();
    try {
      await update(ref(db), {
        [`groups/${gid}/meta/code`]: code,
        [`groupCodes/${code}`]: gid,
        [`groupCodes/${oldCode}`]: null
      });
      return code;
    } catch (err) {
      if (!isPermissionDenied(err) || attempt === 3) throw err;
    }
  }
  throw new Error('Could not change the code.');
}

/** Owner only: make a member a dispatcher, or back to a responder. */
export async function setMemberRole(gid, targetUid, role) {
  if (role !== 'dispatcher' && role !== 'member') throw new Error('Invalid role.');
  await set(ref(db, `groups/${gid}/members/${targetUid}/role`), role);
}

/** Set a member's primary role only, clearing equipment from another role (self, or a dispatcher for anyone). */
export async function setMemberUnit(gid, targetUid, unit) {
  return setMemberProfile(gid, targetUid, { unit, gear: [], mode: undefined });
}

/**
 * Set a member's primary role, equipment (sub-roles) and travel mode in one atomic
 * write (self, or a dispatcher for anyone). Equipment that doesn't belong to the
 * role is dropped. mode undefined keeps the current travel mode.
 */
export async function setMemberProfile(gid, targetUid, { unit, gear = [], mode }) {
  if (!FIELD_UNITS.includes(unit)) throw new Error('Choose a role.');
  const kept = gear.filter((g) => GEAR[g] && GEAR[g].role === unit);
  const base = `groups/${gid}/members/${targetUid}`;
  const updates = {
    [`${base}/unit`]: unit,
    [`${base}/gear`]: kept.length ? Object.fromEntries(kept.map((g) => [g, true])) : null
  };
  if (mode !== undefined) {
    if (!MODES[mode]) throw new Error('Choose how you travel.');
    updates[`${base}/mode`] = mode;
  }
  await update(ref(db), updates);
}
