// GPS tracking and Firebase sync of member positions, plus the geometry the
// dispatch features need: Haversine distances, proximity alarms (which verified
// cases are close enough — 100–2000 m, default 600 m — to alert a free unit
// whose role and equipment fit), ETA estimates from a routing service with a
// straight-line fallback, and the course-map overlay loader (GeoJSON / KML).
//
// Positions come from native.watchLocation(): a foreground-service watcher on
// Android (keeps running with the screen off) or watchPosition on the web.
// While the Android app is backgrounded, writes go through native HTTP to the
// Realtime Database REST API, because Android throttles WebView requests.
// While offline, the newest position waits in the BackgroundService outbox and
// is sent the moment the connection returns (by this page, or on the web by the
// service worker's Background Sync if the page has been closed).
import {
  ref, set, remove, push, onValue, serverTimestamp, onChildAdded, onChildChanged, onChildRemoved
} from 'firebase/database';
import { db } from './firebase.js';
import { serverNow } from './clock.js';
import { watchLocation, useNativeHttp, restPut, isNative } from './native.js';
import { MODES, MIN_PROXIMITY_M, MAX_PROXIMITY_M, responderFit } from './roles.js';
import { setting } from './runtime-config.js';

// Sized for groups of ~15: every write is fanned out to every member.
const MIN_WRITE_INTERVAL_MS = 2000;   // at most one write per 2 s (rules allow ≥ 500 ms)
const MIN_MOVE_METERS = 5;            // write on movement beyond GPS jitter…
const HEARTBEAT_MS = 30000;           // …and at least every 30 s while stationary
const MAX_USABLE_ACCURACY_M = 500;    // ignore very coarse fixes once we have a good one

/** Great-circle distance in metres. */
export function haversine(a, b) {
  const R = 6371000;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

export class LocationTracker extends EventTarget {
  /**
   * @param {{gid: string, uid: string, name: string, getIdToken: () => Promise<string>}} opts
   * Events: 'fix' (own position), 'error' {code, message, openSettings?},
   *         'member' {uid, data}, 'member-removed' {uid}, 'state' {tracking}
   */
  constructor({ gid, uid, name, getIdToken, background }) {
    super();
    this.gid = gid;
    this.uid = uid;
    this.name = name;
    this.getIdToken = getIdToken;
    this.background = background || null;
    this.waitingForNetwork = false;
    this.onOnline = () => {
      if (!this.waitingForNetwork || !this.active) return;
      this.waitingForNetwork = false;
      if (!this.pendingFix && this.lastSent) this.pendingFix = this.lastSent.fix;
      this.flush(true);
    };
    if (this.background) this.background.addEventListener('online', this.onOnline);
    this.stopWatch = null;
    this.active = false;
    this.lastSent = null;       // { lat, lng, at, fix }
    this.pendingFix = null;
    this.flushTimer = null;
    this.heartbeatTimer = null;
    this.wakeLock = null;
    this.unsubs = [];
    this.writeInFlight = false;
    this.deniedRetries = 0;
    this.onVisibility = () => this.handleVisibility();
  }

  get tracking() {
    return this.active;
  }

  /** Subscribe to every member's position in this group. */
  subscribe() {
    const groupRef = ref(db, `locations/${this.gid}`);
    const emit = (snap) => {
      const data = snap.val();
      if (data && Number.isFinite(data.lat) && Number.isFinite(data.lng)) {
        this.dispatchEvent(new CustomEvent('member', { detail: { uid: snap.key, data } }));
      }
    };
    const onError = (err) => this.dispatchEvent(new CustomEvent('error', { detail: { code: 'sync', message: err.message } }));
    this.unsubs.push(
      onChildAdded(groupRef, emit, onError),
      onChildChanged(groupRef, emit, onError),
      onChildRemoved(groupRef, (snap) => this.dispatchEvent(new CustomEvent('member-removed', { detail: { uid: snap.key } })), onError)
    );
  }

  async start() {
    if (this.active) return;
    this.active = true;
    this.dispatchEvent(new CustomEvent('state', { detail: { tracking: true } }));
    this.heartbeatTimer = setInterval(() => this.heartbeat(), 5000);
    document.addEventListener('visibilitychange', this.onVisibility);
    this.acquireWakeLock();
    try {
      const stop = await watchLocation(
        (fix) => this.handleFix(fix),
        (err) => this.handleError(err)
      );
      if (!this.active) stop(); // stopped while the permission prompt was open
      else this.stopWatch = stop;
    } catch (err) {
      this.handleError({ code: 2, message: err.message || 'Could not start location.' });
      this.stop();
    }
  }

  stop({ clearRemote = false } = {}) {
    const wasActive = this.active;
    this.active = false;
    if (this.stopWatch) this.stopWatch();
    this.stopWatch = null;
    clearInterval(this.heartbeatTimer);
    clearTimeout(this.flushTimer);
    this.heartbeatTimer = null;
    this.flushTimer = null;
    this.pendingFix = null;
    document.removeEventListener('visibilitychange', this.onVisibility);
    this.releaseWakeLock();
    if (wasActive) this.dispatchEvent(new CustomEvent('state', { detail: { tracking: false } }));
    if (clearRemote) return remove(ref(db, `locations/${this.gid}/${this.uid}`)).catch(() => {});
    return Promise.resolve();
  }

  /** Stop tracking and detach every listener. */
  destroy({ clearRemote = false } = {}) {
    if (this.background) this.background.removeEventListener('online', this.onOnline);
    const done = this.stop({ clearRemote });
    for (const unsub of this.unsubs) unsub();
    this.unsubs = [];
    return done;
  }

  handleFix(raw) {
    if (!this.active || !Number.isFinite(raw.lat) || !Number.isFinite(raw.lng)) return;
    const fix = {
      lat: raw.lat,
      lng: raw.lng,
      acc: Math.max(0, Math.min(100000, raw.acc || 0)),
      heading: Number.isFinite(raw.heading) && raw.heading >= 0 && raw.heading < 360 ? raw.heading : null,
      speed: Number.isFinite(raw.speed) && raw.speed >= 0 ? Math.min(raw.speed, 400) : null,
      gpsTs: raw.gpsTs || Date.now()
    };

    // Local marker updates instantly regardless of network throttling.
    this.dispatchEvent(new CustomEvent('fix', { detail: { ...fix, ts: serverNow(), name: this.name } }));

    if (fix.acc > MAX_USABLE_ACCURACY_M && this.lastSent) return;
    this.pendingFix = fix;
    this.scheduleFlush();
  }

  scheduleFlush() {
    if (!this.active || this.flushTimer || !this.pendingFix) return;
    const sinceLast = this.lastSent ? Date.now() - this.lastSent.at : Infinity;
    const wait = Math.max(0, MIN_WRITE_INTERVAL_MS - sinceLast);
    this.flushTimer = setTimeout(() => {
      this.flushTimer = null;
      this.flush(false);
    }, wait);
  }

  heartbeat() {
    if (this.lastSent && Date.now() - this.lastSent.at >= HEARTBEAT_MS - 500) {
      if (!this.pendingFix) this.pendingFix = this.lastSent.fix;
      this.flush(true);
    }
  }

  async flush(force) {
    const fix = this.pendingFix;
    if (!fix || this.writeInFlight || !this.active) return;
    if (this.waitingForNetwork && !force) {
      // Offline: just refresh the queued position (cheap) without retrying writes.
      this.pendingFix = null;
      this.lastSent = { lat: fix.lat, lng: fix.lng, at: Date.now(), fix };
      if (this.background) {
        await this.background.saveForLater(`locations/${this.gid}/${this.uid}`, {
          lat: Math.round(fix.lat * 1e7) / 1e7,
          lng: Math.round(fix.lng * 1e7) / 1e7,
          acc: Math.round(fix.acc * 10) / 10,
          gpsTs: fix.gpsTs,
          ts: { '.sv': 'timestamp' },
          name: this.name,
          ...(fix.heading !== null ? { heading: Math.round(fix.heading * 10) / 10 } : {}),
          ...(fix.speed !== null ? { speed: Math.round(fix.speed * 100) / 100 } : {})
        });
      }
      return;
    }
    if (!force && this.lastSent) {
      const moved = haversine(this.lastSent, fix);
      const age = Date.now() - this.lastSent.at;
      if (moved < Math.max(MIN_MOVE_METERS, Math.min(fix.acc, 25) * 0.5) && age < HEARTBEAT_MS) return;
    }
    this.pendingFix = null;
    this.writeInFlight = true;

    const payload = {
      lat: Math.round(fix.lat * 1e7) / 1e7,
      lng: Math.round(fix.lng * 1e7) / 1e7,
      acc: Math.round(fix.acc * 10) / 10,
      gpsTs: fix.gpsTs,
      ts: serverTimestamp(),
      name: this.name
    };
    if (fix.heading !== null) payload.heading = Math.round(fix.heading * 10) / 10;
    if (fix.speed !== null) payload.speed = Math.round(fix.speed * 100) / 100;

    const path = `locations/${this.gid}/${this.uid}`;
    // REST form of the same write: {".sv":"timestamp"} is the server-timestamp placeholder.
    const restPayload = { ...payload, ts: { '.sv': 'timestamp' } };

    if (this.background && !this.background.isOnline()) {
      // No connection: keep the newest position in the outbox; 'online' resumes.
      this.waitingForNetwork = true;
      this.pendingFix = fix;
      this.writeInFlight = false;
      this.lastSent = { lat: fix.lat, lng: fix.lng, at: Date.now(), fix };
      await this.background.saveForLater(path, restPayload);
      return;
    }

    try {
      if (useNativeHttp()) {
        await restPut(path, restPayload, await this.getIdToken());
      } else {
        await set(ref(db, path), payload);
      }
      this.lastSent = { lat: fix.lat, lng: fix.lng, at: Date.now(), fix };
      this.deniedRetries = 0;
      if (this.background) this.background.clear(path);
    } catch (err) {
      if (err && err.code !== 'PERMISSION_DENIED' && this.background) {
        // Network failure on the native HTTP path: queue it and wait for the connection.
        this.waitingForNetwork = true;
        await this.background.saveForLater(path, restPayload);
        return;
      }
      // Denied: the 500 ms server rate limit (e.g. right after a reload) or a
      // revoked membership. Retry a few times so a stationary device still
      // publishes, then stop. The SDK queues writes while offline, so plain
      // connectivity loss does not reach this branch.
      this.deniedRetries += 1;
      if (this.deniedRetries <= 3 && !this.pendingFix) {
        setTimeout(() => {
          if (this.active && !this.pendingFix) {
            this.pendingFix = fix;
            this.scheduleFlush();
          }
        }, 1500 * this.deniedRetries);
      }
      this.dispatchEvent(new CustomEvent('error', { detail: { code: 'write', message: err.message } }));
    } finally {
      this.writeInFlight = false;
      if (this.pendingFix) this.scheduleFlush();
    }
  }

  handleError(detail) {
    this.dispatchEvent(new CustomEvent('error', { detail }));
    if (detail.code === 1) this.stop();
  }

  async acquireWakeLock() {
    // Web/PWA: keeps the screen on while tracking. On Android the foreground
    // service keeps the app running instead, so the screen may turn off.
    if (isNative) return;
    try {
      if ('wakeLock' in navigator && document.visibilityState === 'visible' && !this.wakeLock) {
        this.wakeLock = await navigator.wakeLock.request('screen');
        this.wakeLock.addEventListener('release', () => { this.wakeLock = null; });
      }
    } catch {
      this.wakeLock = null;
    }
  }

  releaseWakeLock() {
    if (this.wakeLock) {
      this.wakeLock.release().catch(() => {});
      this.wakeLock = null;
    }
  }

  handleVisibility() {
    if (document.visibilityState === 'visible' && this.active) {
      this.acquireWakeLock();
      this.heartbeat();
    }
  }
}

/* ============================== Proximity alarms ============================== */

/** Clamp a radius to the supported 100–2000 m range. */
export function clampRadius(m) {
  const n = Math.round(Number(m));
  return Number.isFinite(n) ? Math.min(MAX_PROXIMITY_M, Math.max(MIN_PROXIMITY_M, n)) : null;
}

/**
 * Verified cases that should raise a proximity alarm for this responder, nearest
 * first. A case qualifies when it is open (not pending, monitoring or SOS — SOS
 * alerts everyone separately), has a location, still needs units, my primary
 * role responds to it (responderFit — equipment is informational and never
 * filters), it is within the radius, and I have not
 * dismissed it. None while the group's master switch or this device's switch is
 * off, while I am locked to a case (single-task lock), or off duty.
 *
 * @returns {Array<{incident, distance: number, eta: {seconds, meters, src}}>}
 */
export function findProximityCases({
  incidents, uid, member, fix, settings, radiusM, locked, offDuty, dismissed, stillNeeded, deviceOn = true
}) {
  if (!member || locked || offDuty || !deviceOn || !settings || settings.proximityOn === false) return [];
  if (!fix || !Number.isFinite(fix.lat)) return [];
  const radius = clampRadius(radiusM) || settings.proximityM;
  const mode = MODES[member.mode] ? member.mode : 'foot';
  const out = [];
  for (const inc of incidents.values()) {
    if (inc.state !== 'open' || inc.type === 'sos') continue;
    if (!Number.isFinite(inc.lat) || !Number.isFinite(inc.lng)) continue;
    if (inc.assigned && inc.assigned[uid]) continue;
    if ((inc.dismissed && inc.dismissed[uid]) || (dismissed && dismissed.has(inc.id))) continue;
    if (stillNeeded && stillNeeded(inc) <= 0) continue;
    if (!responderFit(inc, member, settings).ok) continue;
    const distance = haversine(fix, inc);
    // Allow for GPS uncertainty up to 50 m so an alarm isn't missed at the edge.
    if (distance - Math.min(fix.acc || 0, 50) > radius) continue;
    out.push({ incident: inc, distance, eta: estimateEta(distance, mode) });
  }
  return out.sort((a, b) => a.incident.priority - b.incident.priority || a.distance - b.distance);
}

/* ============================== ETA ============================== */

const DETOUR_FACTOR = 1.35;   // streets are longer than the straight line
const ROUTE_MIN_INTERVAL_MS = 1100;   // public routing servers allow ≤ 1 request/s
const ROUTE_CACHE_MS = 60_000;
const ROUTE_TIMEOUT_MS = 6000;

/** Straight-line estimate for a travel mode (foot / bike / vehicle), used until / unless a route is known. */
export function estimateEta(distanceM, mode) {
  const speed = (MODES[mode] || MODES.foot).speed;
  const meters = distanceM * DETOUR_FACTOR;
  return { seconds: Math.round(meters / speed + 15), meters: Math.round(meters), src: 'estimate' };
}

export function formatEta(seconds) {
  if (!Number.isFinite(seconds)) return '';
  if (seconds < 60) return '<1 min';
  const min = Math.round(seconds / 60);
  if (min < 60) return `${min} min`;
  return `${Math.floor(min / 60)} h ${min % 60} min`;
}

/**
 * Street routing via an OSRM-compatible server (default: the FOSSGIS servers at
 * routing.openstreetmap.de, which have car / bike / foot profiles). Requests are
 * queued to at most one per 1.1 s and cached, and any failure falls back to the
 * straight-line estimate, so ETAs always show.
 */
export class EtaRouter {
  constructor(template = setting('routingUrl', import.meta.env.VITE_ROUTING_URL)) {
    this.template = template === undefined
      ? 'https://routing.openstreetmap.de/routed-{profile}/route/v1/driving/{fromLng},{fromLat};{toLng},{toLat}?overview=false&alternatives=false&steps=false'
      : String(template || '').trim();
    this.cache = new Map();
    this.queue = Promise.resolve();
    this.lastRequestAt = 0;
    this.failures = 0;
  }

  get enabled() {
    return !!this.template && this.failures < 5;
  }

  async eta(from, to, mode) {
    const straight = haversine(from, to);
    const fallback = estimateEta(straight, mode);
    if (!this.enabled || straight < 30) return fallback;
    const profile = (MODES[mode] || MODES.foot).profile;
    // Round the start to ~25 m so small GPS wobbles reuse the cached route.
    const key = `${profile}:${from.lat.toFixed(4)},${from.lng.toFixed(4)}>${to.lat.toFixed(5)},${to.lng.toFixed(5)}`;
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.at < ROUTE_CACHE_MS) return cached.value;

    const run = async () => {
      const wait = ROUTE_MIN_INTERVAL_MS - (Date.now() - this.lastRequestAt);
      if (wait > 0) await new Promise((r) => setTimeout(r, wait));
      this.lastRequestAt = Date.now();
      const url = this.template
        .replace('{profile}', profile)
        .replace('{fromLng}', from.lng.toFixed(6)).replace('{fromLat}', from.lat.toFixed(6))
        .replace('{toLng}', to.lng.toFixed(6)).replace('{toLat}', to.lat.toFixed(6));
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), ROUTE_TIMEOUT_MS);
      try {
        const res = await fetch(url, { signal: controller.signal, credentials: 'omit', cache: 'no-store' });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const body = await res.json();
        const route = body && body.code === 'Ok' && body.routes && body.routes[0];
        if (!route || !Number.isFinite(route.duration)) throw new Error('No route');
        this.failures = 0;
        return { seconds: Math.round(route.duration), meters: Math.round(route.distance), src: 'route' };
      } finally {
        clearTimeout(timer);
      }
    };

    const result = this.queue.then(run, run);
    this.queue = result.catch(() => {});
    try {
      const value = await result;
      this.cache.set(key, { at: Date.now(), value });
      return value;
    } catch (err) {
      this.failures += 1;
      console.debug('Routing unavailable, using straight-line ETA:', err.message);
      return fallback;
    }
  }
}

/**
 * Keeps my ETA to my active case up to date in the database so dispatch sees a
 * live, routed ETA: recomputed when I move > 75 m, my case changes, or every 45 s.
 */
export class EtaReporter {
  constructor({ dispatch, router, getMode }) {
    this.dispatch = dispatch;
    this.router = router;
    this.getMode = getMode;
    this.last = null;      // { iid, lat, lng, at }
    this.busy = false;
  }

  async update(fix) {
    if (this.busy || !fix || !Number.isFinite(fix.lat)) return;
    const lock = this.dispatch.myLock();
    if (!lock) { this.last = null; return; }
    const inc = lock.incident;
    if (!Number.isFinite(inc.lat) || !Number.isFinite(inc.lng)) return;
    if (lock.assignment.state === 'onscene') return;
    const now = Date.now();
    const moved = this.last ? haversine(this.last, fix) : Infinity;
    if (this.last && this.last.iid === inc.id && moved < 75 && now - this.last.at < 45_000) return;
    this.busy = true;
    try {
      const eta = await this.router.eta(fix, inc, this.getMode());
      await this.dispatch.writeEta(inc.id, eta);
      this.last = { iid: inc.id, lat: fix.lat, lng: fix.lng, at: now };
    } catch (err) {
      console.debug('ETA not written:', err.message);
    } finally {
      this.busy = false;
    }
  }
}

/* ============================== Course-map overlays ============================== */

// Dispatchers upload GeoJSON or KML (Google My Maps / Google Earth exports). KML
// is converted to GeoJSON in the browser, every feature gets a category from its
// properties or name, coordinates are rounded to ~1 m, and the result is stored
// at overlays/{gid}/{oid} so every phone draws the same layers.

export const OVERLAY_CATEGORIES = {
  course: { label: 'Course track', color: '#ff9f1a' },
  km: { label: 'Kilometre marker', color: '#ffd166' },
  aid: { label: 'Aid / medical station', color: '#ff5d73' },
  water: { label: 'Water point', color: '#4aa3ff' },
  closure: { label: 'Road closure', color: '#ff3b30' },
  access: { label: 'Emergency access corridor', color: '#34c759' },
  area: { label: 'Area', color: '#a78bfa' },
  poi: { label: 'Point of interest', color: '#cfd8dc' }
};

const MAX_OVERLAY_CHARS = 880_000;   // stored string (rules allow 900 000)
const MAX_OVERLAY_FEATURES = 20_000;
const MAX_UPLOAD_BYTES = 15 * 1024 * 1024;

/** Category from free text (name, description or folder), or null. */
function categoryFromText(text, isPoint) {
  const t = String(text || '').toLowerCase();
  if (!t.trim()) return null;
  if (/\b(road\s*clos|closure|closed|road\s*block|no\s*entry|barrier)/.test(t)) return 'closure';
  if (/\b(access|corridor|emergency\s*(route|lane|exit)|evac|ambulance\s*route)/.test(t)) return 'access';
  if (/\b(water|drink|hydration|refill)/.test(t)) return 'water';
  if (/\b(aid|first\s*aid|medical|med\s*tent|medic|ambulance|aed|treatment)/.test(t)) return 'aid';
  if (isPoint && /(^|\s)(km|k)\s*\d+|\d+(\.\d+)?\s*km\b|kilomet|mile\s*\d|\bmarker\b/.test(t)) return 'km';
  return null;
}

/**
 * Category for a GeoJSON feature: an explicit category / type / kind property
 * first, then keywords in its own name and description, then in its folder's
 * name (KML), then its geometry.
 */
export function classifyFeature(feature) {
  const props = (feature && feature.properties) || {};
  const explicit = String(props.category || props.type || props.kind || '').toLowerCase();
  if (OVERLAY_CATEGORIES[explicit]) return explicit;
  const geom = feature && feature.geometry ? feature.geometry.type : '';
  const isPoint = geom === 'Point' || geom === 'MultiPoint';
  const own = categoryFromText(`${props.name || ''} ${props.description || ''}`, isPoint);
  if (own) return own;
  const folder = categoryFromText(props.folder, isPoint);
  if (folder) return folder;
  if (geom === 'LineString' || geom === 'MultiLineString') return 'course';
  if (geom === 'Polygon' || geom === 'MultiPolygon') return 'area';
  return 'poi';
}

function textOf(el, tag) {
  const child = el.getElementsByTagName(tag)[0];
  return child ? child.textContent.trim() : '';
}

/** "lng,lat[,alt] lng,lat …" → [[lng, lat], …] */
function kmlCoords(text) {
  return String(text || '').trim().split(/\s+/).map((tuple) => tuple.split(',').map(Number))
    .filter((c) => c.length >= 2 && Number.isFinite(c[0]) && Number.isFinite(c[1]) && Math.abs(c[1]) <= 90 && Math.abs(c[0]) <= 180)
    .map((c) => [c[0], c[1]]);
}

function kmlGeometries(node) {
  const out = [];
  for (const child of Array.from(node.children)) {
    const tag = child.localName;
    if (tag === 'Point') {
      const c = kmlCoords(textOf(child, 'coordinates'))[0];
      if (c) out.push({ type: 'Point', coordinates: c });
    } else if (tag === 'LineString' || tag === 'LinearRing') {
      const c = kmlCoords(textOf(child, 'coordinates'));
      if (c.length >= 2) out.push({ type: 'LineString', coordinates: c });
    } else if (tag === 'Polygon') {
      const rings = [];
      const outer = child.getElementsByTagName('outerBoundaryIs')[0];
      if (outer) rings.push(kmlCoords(textOf(outer, 'coordinates')));
      for (const inner of Array.from(child.getElementsByTagName('innerBoundaryIs'))) rings.push(kmlCoords(textOf(inner, 'coordinates')));
      if (rings.length && rings[0].length >= 4) out.push({ type: 'Polygon', coordinates: rings.filter((r) => r.length >= 4) });
    } else if (tag === 'Track') {   // gx:Track: <gx:coord>lng lat alt</gx:coord>
      const c = Array.from(child.getElementsByTagName('*')).filter((e) => e.localName === 'coord')
        .map((e) => e.textContent.trim().split(/\s+/).map(Number)).filter((v) => Number.isFinite(v[0]) && Number.isFinite(v[1]))
        .map((v) => [v[0], v[1]]);
      if (c.length >= 2) out.push({ type: 'LineString', coordinates: c });
    } else if (tag === 'MultiGeometry' || tag === 'MultiTrack') {
      out.push(...kmlGeometries(child));
    }
  }
  return out;
}

/** KML text → GeoJSON FeatureCollection (Placemarks with Point / LineString / Polygon / gx:Track / MultiGeometry). */
export function kmlToGeoJSON(kmlText) {
  const doc = new DOMParser().parseFromString(kmlText, 'application/xml');
  if (doc.getElementsByTagName('parsererror').length) throw new Error('That KML file could not be read.');
  const features = [];
  for (const pm of Array.from(doc.getElementsByTagName('Placemark'))) {
    const properties = {};
    const name = textOf(pm, 'name');
    if (name) properties.name = name.slice(0, 120);
    const description = textOf(pm, 'description').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
    if (description) properties.description = description.slice(0, 300);
    const folder = pm.parentElement && pm.parentElement.localName === 'Folder' ? textOf(pm.parentElement, 'name') : '';
    if (folder) properties.folder = folder.slice(0, 80);
    for (const data of Array.from(pm.getElementsByTagName('Data'))) {
      const key = String(data.getAttribute('name') || '').slice(0, 40);
      if (key && /^[\w -]+$/.test(key)) properties[key] = textOf(data, 'value').slice(0, 120);
    }
    const geoms = kmlGeometries(pm);
    for (const geometry of geoms) features.push({ type: 'Feature', properties: { ...properties }, geometry });
  }
  return { type: 'FeatureCollection', features };
}

const round = (n, d) => Math.round(n * 10 ** d) / 10 ** d;

function mapCoords(coords, fn) {
  return typeof coords[0] === 'number' ? fn(coords) : coords.map((c) => mapCoords(c, fn));
}

function decimate(coords, step) {
  if (typeof coords[0] === 'number') return coords;
  if (typeof coords[0][0] === 'number') {
    if (coords.length <= 4 || step <= 1) return coords;
    const kept = coords.filter((_, i) => i % step === 0);
    if (kept[kept.length - 1] !== coords[coords.length - 1]) kept.push(coords[coords.length - 1]);
    return kept;
  }
  return coords.map((c) => decimate(c, step));
}

const GEOMETRY_TYPES = new Set(['Point', 'MultiPoint', 'LineString', 'MultiLineString', 'Polygon', 'MultiPolygon']);

/**
 * Clean, classify and size-limit a FeatureCollection for storage: only known
 * geometry types, only short string/number properties, coordinates to 6 (then
 * 5) decimals, and long lines thinned until it fits.
 */
export function prepareOverlay(geojson) {
  const input = geojson && geojson.type === 'FeatureCollection' ? geojson.features
    : geojson && geojson.type === 'Feature' ? [geojson]
      : geojson && GEOMETRY_TYPES.has(geojson.type) ? [{ type: 'Feature', properties: {}, geometry: geojson }] : null;
  if (!Array.isArray(input)) throw new Error('Not a GeoJSON file.');
  const flat = [];
  for (const f of input) {
    const g = f && f.geometry;
    if (!g) continue;
    if (g.type === 'GeometryCollection') {
      for (const part of g.geometries || []) flat.push({ properties: f.properties, geometry: part });
    } else flat.push({ properties: f.properties, geometry: g });
  }
  const features = [];
  for (const f of flat) {
    if (!GEOMETRY_TYPES.has(f.geometry.type) || !Array.isArray(f.geometry.coordinates)) continue;
    const props = {};
    for (const [k, v] of Object.entries(f.properties || {})) {
      if (!/^[\w -]{1,40}$/.test(k)) continue;
      if (typeof v === 'string') props[k] = v.slice(0, 200);
      else if (typeof v === 'number' && Number.isFinite(v)) props[k] = v;
    }
    let valid = true;
    const coordinates = mapCoords(f.geometry.coordinates, (c) => {
      if (!Number.isFinite(c[0]) || !Number.isFinite(c[1]) || Math.abs(c[1]) > 90 || Math.abs(c[0]) > 180) valid = false;
      return [round(c[0], 6), round(c[1], 6)];
    });
    if (!valid) continue;
    const feature = { type: 'Feature', properties: props, geometry: { type: f.geometry.type, coordinates } };
    feature.properties.category = classifyFeature(feature);
    features.push(feature);
    if (features.length >= MAX_OVERLAY_FEATURES) break;
  }
  if (!features.length) throw new Error('No map features found in that file.');
  let fc = { type: 'FeatureCollection', features };
  let text = JSON.stringify(fc);
  if (text.length > MAX_OVERLAY_CHARS) {
    fc = { type: 'FeatureCollection', features: features.map((f) => ({ ...f, geometry: { ...f.geometry, coordinates: mapCoords(f.geometry.coordinates, (c) => [round(c[0], 5), round(c[1], 5)]) } })) };
    text = JSON.stringify(fc);
  }
  for (let step = 2; text.length > MAX_OVERLAY_CHARS && step <= 64; step *= 2) {
    const thinned = { type: 'FeatureCollection', features: fc.features.map((f) => ({ ...f, geometry: { ...f.geometry, coordinates: decimate(f.geometry.coordinates, step) } })) };
    text = JSON.stringify(thinned);
  }
  if (text.length > MAX_OVERLAY_CHARS) throw new Error('That map file is too large even after simplifying. Split it into smaller layers.');
  return { text, count: features.length };
}

/** Read an uploaded .geojson / .json / .kml / .kmz-free file into storable overlay text. */
export async function parseOverlayFile(file) {
  if (!file) throw new Error('Choose a file.');
  if (file.size > MAX_UPLOAD_BYTES) throw new Error('That file is larger than 15 MB.');
  const name = String(file.name || 'Layer');
  if (/\.kmz$/i.test(name)) throw new Error('KMZ is zipped: open it in Google Earth and save as .kml, or export GeoJSON.');
  const raw = await file.text();
  const isKml = /\.kml$/i.test(name) || /^\s*<\?xml|<kml[\s>]/i.test(raw.slice(0, 500));
  let geojson;
  if (isKml) geojson = kmlToGeoJSON(raw);
  else {
    try { geojson = JSON.parse(raw); } catch { throw new Error('That file is not valid GeoJSON or KML.'); }
  }
  const { text, count } = prepareOverlay(geojson);
  return { name: name.replace(/\.(geo)?json$|\.kml$/i, '').slice(0, 80) || 'Layer', text, count };
}

/** Shared overlays for a group: listen, add (dispatchers), show/hide and remove. */
export class OverlayStore extends EventTarget {
  /** Events: 'change' {overlays: Array<{id, name, by, ts, count, visible, geojson}>} */
  constructor({ gid, uid }) {
    super();
    this.gid = gid;
    this.uid = uid;
    this.overlays = [];
    this.unsub = null;
  }

  start() {
    this.unsub = onValue(ref(db, `overlays/${this.gid}`), (snap) => {
      const list = [];
      snap.forEach((child) => {
        const v = child.val();
        if (!v || typeof v.data !== 'string') return;
        let geojson = null;
        try { geojson = JSON.parse(v.data); } catch { geojson = null; }
        if (geojson) list.push({ id: child.key, name: v.name, by: v.by, ts: v.ts, count: v.count, visible: v.visible !== false, geojson });
      });
      this.overlays = list.sort((a, b) => a.ts - b.ts);
      this.dispatchEvent(new CustomEvent('change', { detail: { overlays: this.overlays } }));
    }, () => {});
  }

  stop() {
    if (this.unsub) this.unsub();
    this.unsub = null;
  }

  async add({ name, text, count }) {
    const node = push(ref(db, `overlays/${this.gid}`));
    await set(node, { name: String(name).slice(0, 80) || 'Layer', by: this.uid, ts: serverTimestamp(), data: text, count, visible: true });
    return node.key;
  }

  async setVisible(id, visible) {
    await set(ref(db, `overlays/${this.gid}/${id}/visible`), !!visible);
  }

  async remove(id) {
    await remove(ref(db, `overlays/${this.gid}/${id}`));
  }
}
