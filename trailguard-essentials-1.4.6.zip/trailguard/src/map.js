// Leaflet map handler: member markers with smooth movement, accuracy circles,
// heading arrows, stale/talking states, follow-me and fit-group re-centering,
// plus case markers (SOS pulses), a drop-pin mode for placing cases by click or
// tap, LIVE badges on members broadcasting their bodycam, role colours and
// equipment badges (AED, BAG, TRM, ALS, EXT, FRK, CRD, ESC, BIKE, VEH) on member
// markers, course-map overlays (GeoJSON) and marker popups with actions (view
// live video, request live video).
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { config } from './firebase.js';
import { colorFor, initials, formatAgo } from './ui.js';
import { serverNow } from './clock.js';
import { OVERLAY_CATEGORIES } from './location.js';
import { GEAR } from './roles.js';

const ANIMATION_MS = 900;
const STALE_AFTER_MS = 2 * 60 * 1000;
const DEFAULT_VIEW = { center: [1.3521, 103.8198], zoom: 12 };

export class MapView {
  constructor(elementId, { selfUid, onUserPan, onIncidentClick, onLongPress, popupActions } = {}) {
    this.selfUid = selfUid;
    this.onUserPan = onUserPan;
    this.onIncidentClick = onIncidentClick;
    this.onLongPress = onLongPress;
    this.popupActions = popupActions;   // (uid) => [{label, primary?, onClick}]
    this.liveUids = new Set();
    this.watchedUid = null;
    this.followUid = null;              // null = follow my own position
    this.pickHandler = null;
    this.markers = new Map(); // uid -> { marker, circle, data, anim }
    this.incidentMarkers = new Map(); // incident id -> { marker, key }
    this.follow = true;
    this.speakerUid = null;
    this.hasCentered = false;
    this.profiles = new Map();          // uid -> { role, color, roleShort, badges: string[] }
    this.overlayKey = '';

    this.map = L.map(elementId, {
      zoomControl: false,
      attributionControl: true,
      center: DEFAULT_VIEW.center,
      zoom: DEFAULT_VIEW.zoom,
      worldCopyJump: true,
      preferCanvas: false
    });

    L.tileLayer(config.tileUrl, {
      maxZoom: 19,
      attribution: config.tileAttribution,
      crossOrigin: true
    }).addTo(this.map);

    // Course overlays sit under the markers (their own pane, below markerPane).
    this.map.createPane('overlays');
    this.map.getPane('overlays').style.zIndex = '350';
    this.overlayLayer = L.layerGroup().addTo(this.map);

    // A drag by the user means "stop following me".
    this.map.on('dragstart', () => {
      if (this.follow) {
        this.follow = false;
        if (this.onUserPan) this.onUserPan();
      }
    });

    // Long-press (touch) or right-click: Leaflet reports both as 'contextmenu'.
    this.map.on('contextmenu', (e) => {
      if (this.pickHandler) return this.finishPick(e.latlng);
      if (this.onLongPress) this.onLongPress(e.latlng);
    });
    // Click / tap while in drop-pin mode places the pin.
    this.map.on('click', (e) => {
      if (this.pickHandler) this.finishPick(e.latlng);
    });

    this.staleTimer = setInterval(() => this.refreshStaleness(), 15000);
  }

  /** Show / update / remove incident markers. incidents: open incidents with lat/lng. */
  setIncidents(incidents) {
    const seen = new Set();
    for (const inc of incidents) {
      if (!Number.isFinite(inc.lat) || !Number.isFinite(inc.lng)) continue;
      seen.add(inc.id);
      const key = `${inc.type}|${inc.priority}|${inc.state}|${inc.title}|${inc.lat}|${inc.lng}|${Object.keys(inc.requires || {}).join(',')}|${inc.rapid ? 1 : 0}`;
      const existing = this.incidentMarkers.get(inc.id);
      if (existing && existing.key === key) continue;
      if (existing) existing.marker.remove();
      const el = document.createElement('div');
      el.className = `incident-marker p${inc.priority}${inc.type === 'sos' ? ' sos' : ''}${inc.state === 'pending' ? ' pending' : ''}${inc.state === 'monitoring' ? ' monitoring' : ''}`;
      const label = document.createElement('span');
      label.textContent = inc.type === 'sos' ? 'SOS' : inc.state === 'pending' ? '?' : `P${inc.priority}`;
      const title = document.createElement('div');
      title.className = 'incident-label';
      const needs = Object.keys(inc.requires || {}).filter((g) => GEAR[g]).map((g) => GEAR[g].short);
      title.textContent = needs.length ? `${inc.title} · ${needs.join('+')} requested` : inc.title;
      if (inc.rapid) el.classList.add('rapid');
      el.append(label, title);
      const marker = L.marker([inc.lat, inc.lng], {
        icon: L.divIcon({ html: el, className: '', iconSize: [44, 44], iconAnchor: [22, 22] }),
        zIndexOffset: inc.type === 'sos' ? 3000 : inc.state === 'pending' ? 1500 : 2000,
        keyboard: false
      }).addTo(this.map);
      marker.on('click', () => { if (this.onIncidentClick) this.onIncidentClick(inc.id); });
      this.incidentMarkers.set(inc.id, { marker, key });
    }
    for (const [id, entry] of this.incidentMarkers) {
      if (!seen.has(id)) {
        entry.marker.remove();
        this.incidentMarkers.delete(id);
      }
    }
  }

  /**
   * Role colour and equipment badges per member: profiles = Map<uid, {role, color, roleShort, badges}>.
   * Only markers whose profile changed are redrawn.
   */
  setProfiles(profiles) {
    const changed = [];
    const sig = (p) => (p ? `${p.role}|${p.color}|${p.badges.join(',')}` : '');
    for (const uid of new Set([...this.profiles.keys(), ...profiles.keys()])) {
      if (sig(this.profiles.get(uid)) !== sig(profiles.get(uid))) changed.push(uid);
    }
    this.profiles = new Map(profiles);
    for (const uid of changed) this.refreshIcon(uid);
  }

  /** Draw the group's visible overlays: [{id, name, visible, geojson}]. */
  setOverlays(overlays) {
    const visible = overlays.filter((o) => o.visible);
    const key = visible.map((o) => `${o.id}:${o.ts}`).join('|');
    if (key === this.overlayKey) return;
    this.overlayKey = key;
    this.overlayLayer.clearLayers();
    for (const overlay of visible) {
      const layer = L.geoJSON(overlay.geojson, {
        pane: 'overlays',
        style: (feature) => this.overlayStyle(feature),
        pointToLayer: (feature, latlng) => this.overlayPoint(feature, latlng),
        onEachFeature: (feature, lyr) => {
          const props = feature.properties || {};
          const cat = OVERLAY_CATEGORIES[props.category] || OVERLAY_CATEGORIES.poi;
          const wrap = document.createElement('div');
          const title = document.createElement('strong');
          title.textContent = props.name || cat.label;
          const sub = document.createElement('div');
          sub.className = 'muted';
          sub.textContent = `${cat.label} · ${overlay.name}`;
          wrap.append(title, sub);
          if (props.description) {
            const d = document.createElement('div');
            d.textContent = props.description;
            wrap.append(d);
          }
          lyr.bindPopup(wrap);
        }
      });
      layer.addTo(this.overlayLayer);
    }
  }

  overlayStyle(feature) {
    const cat = (feature.properties && feature.properties.category) || 'poi';
    const color = (OVERLAY_CATEGORIES[cat] || OVERLAY_CATEGORIES.poi).color;
    switch (cat) {
      case 'course': return { color, weight: 5, opacity: 0.85, lineCap: 'round', lineJoin: 'round' };
      case 'closure': return { color, weight: 5, opacity: 0.9, dashArray: '2 8', fillColor: color, fillOpacity: 0.18 };
      case 'access': return { color, weight: 5, opacity: 0.9, dashArray: '10 6', fillColor: color, fillOpacity: 0.12 };
      case 'area': return { color, weight: 2, opacity: 0.8, fillColor: color, fillOpacity: 0.12 };
      default: return { color, weight: 3, opacity: 0.85, fillColor: color, fillOpacity: 0.15 };
    }
  }

  overlayPoint(feature, latlng) {
    const props = feature.properties || {};
    const cat = props.category || 'poi';
    const color = (OVERLAY_CATEGORIES[cat] || OVERLAY_CATEGORIES.poi).color;
    const el = document.createElement('div');
    el.className = `overlay-point cat-${cat}`;
    el.style.setProperty('--cat', color);
    const glyph = { km: 'KM', water: 'H₂O', aid: '+', closure: '✕', access: '➜', poi: '•', course: '•', area: '•' }[cat] || '•';
    const icon = document.createElement('span');
    icon.textContent = cat === 'km' && props.name ? String(props.name).replace(/[^0-9.]/g, '').slice(0, 4) || 'KM' : glyph;
    el.append(icon);
    return L.marker(latlng, {
      pane: 'overlays',
      icon: L.divIcon({ html: el, className: '', iconSize: [26, 26], iconAnchor: [13, 13], popupAnchor: [0, -12] }),
      keyboard: false,
      zIndexOffset: -500
    });
  }

  /** Drop-pin mode: the next click / tap on the map calls onPick({lat, lng}). */
  startPick(onPick) {
    this.pickHandler = onPick;
    this.map.getContainer().classList.add('picking');
    this.map.closePopup();
  }

  cancelPick() {
    this.pickHandler = null;
    this.map.getContainer().classList.remove('picking');
  }

  get picking() {
    return !!this.pickHandler;
  }

  finishPick(latlng) {
    const handler = this.pickHandler;
    this.cancelPick();
    if (handler) handler({ lat: latlng.lat, lng: latlng.lng });
  }

  /** Members currently broadcasting live video (shown with a LIVE badge). */
  setLive(uids) {
    const next = new Set(uids);
    const changed = [...next].filter((u) => !this.liveUids.has(u)).concat([...this.liveUids].filter((u) => !next.has(u)));
    this.liveUids = next;
    for (const uid of changed) this.refreshIcon(uid);
  }

  /** Highlight the member whose video is open, and optionally keep them centred. */
  setWatched(uid, follow) {
    const previous = this.watchedUid;
    this.watchedUid = uid || null;
    this.refreshIcon(previous);
    this.refreshIcon(uid);
    this.followUid = uid && follow ? uid : null;
    if (this.followUid) {
      this.follow = true;
      const entry = this.markers.get(uid);
      if (entry) this.map.setView(entry.marker.getLatLng(), Math.max(this.map.getZoom(), 16), { animate: true });
    }
  }

  refreshIcon(uid) {
    const entry = uid && this.markers.get(uid);
    if (entry) entry.marker.setIcon(this.buildIcon(uid, entry.data, serverNow()));
  }

  focusPoint(lat, lng, zoom = 17) {
    this.follow = false;
    this.map.setView([lat, lng], Math.max(this.map.getZoom(), zoom), { animate: true });
  }

  center() {
    const c = this.map.getCenter();
    return { lat: c.lat, lng: c.lng };
  }

  /** Must be called after the container becomes visible or changes size. */
  invalidate() {
    requestAnimationFrame(() => this.map.invalidateSize());
  }

  setFollow(enabled) {
    this.follow = enabled;
    if (!enabled) this.followUid = null;
    if (enabled && !this.followUid) this.centerOnSelf(true);
  }

  centerOnSelf(animate = true) {
    const self = this.markers.get(this.selfUid);
    if (!self) return false;
    const zoom = Math.max(this.map.getZoom(), 16);
    this.map.setView(self.marker.getLatLng(), zoom, { animate });
    return true;
  }

  fitGroup() {
    const points = [...this.markers.values()].map((m) => m.marker.getLatLng());
    if (points.length === 0) return false;
    if (points.length === 1) {
      this.map.setView(points[0], 16, { animate: true });
    } else {
      this.map.fitBounds(L.latLngBounds(points), { padding: [60, 60], maxZoom: 17, animate: true });
    }
    return true;
  }

  /** Insert or update a member's position. data = { lat, lng, acc, heading, speed, ts, name } */
  upsert(uid, data) {
    const now = serverNow();
    if (!Number.isFinite(data.lat) || !Number.isFinite(data.lng)) return;
    const target = L.latLng(data.lat, data.lng);
    let entry = this.markers.get(uid);

    if (!entry) {
      const marker = L.marker(target, {
        icon: this.buildIcon(uid, data, now),
        keyboard: false,
        zIndexOffset: uid === this.selfUid ? 1000 : 0
      }).addTo(this.map);
      const circle = L.circle(target, {
        radius: Math.min(data.acc || 0, 2000),
        color: colorFor(uid),
        weight: 1,
        opacity: 0.6,
        fillOpacity: 0.08,
        interactive: false
      }).addTo(this.map);
      marker.bindPopup(() => this.popupContent(uid));
      entry = { marker, circle, data, anim: null };
      this.markers.set(uid, entry);
    } else {
      entry.data = data;
      entry.marker.setIcon(this.buildIcon(uid, data, now));
      this.animateTo(entry, target);
      entry.circle.setRadius(Math.min(data.acc || 0, 2000));
    }

    const followed = this.followUid || this.selfUid;
    if (uid === followed && this.hasCentered && this.follow) {
      this.map.panTo(target, { animate: true, duration: 0.8 });
    }
    if (uid === this.selfUid) {
      if (!this.hasCentered) {
        this.hasCentered = true;
        this.map.setView(target, 16, { animate: false });
      }
    } else if (!this.hasCentered && !this.markers.has(this.selfUid)) {
      // No own fix yet: show the first teammate we hear about.
      this.hasCentered = true;
      this.map.setView(target, 15, { animate: false });
    }
  }

  remove(uid) {
    const entry = this.markers.get(uid);
    if (!entry) return;
    if (entry.anim) cancelAnimationFrame(entry.anim);
    entry.marker.remove();
    entry.circle.remove();
    this.markers.delete(uid);
  }

  setSpeaker(uid) {
    const previous = this.speakerUid;
    this.speakerUid = uid;
    for (const id of [previous, uid]) {
      const entry = id && this.markers.get(id);
      if (entry) entry.marker.setIcon(this.buildIcon(id, entry.data, serverNow()));
    }
  }

  refreshStaleness() {
    const now = serverNow();
    for (const [uid, entry] of this.markers) entry.marker.setIcon(this.buildIcon(uid, entry.data, now));
  }

  animateTo(entry, target) {
    if (entry.anim) cancelAnimationFrame(entry.anim);
    const from = entry.marker.getLatLng();
    if (from.distanceTo(target) > 5000) {
      // Large jump (e.g. first fix after a long gap): don't slide across the map.
      entry.marker.setLatLng(target);
      entry.circle.setLatLng(target);
      return;
    }
    const start = performance.now();
    const step = (t) => {
      const k = Math.min(1, (t - start) / ANIMATION_MS);
      const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2; // easeInOutQuad
      const pos = L.latLng(from.lat + (target.lat - from.lat) * e, from.lng + (target.lng - from.lng) * e);
      entry.marker.setLatLng(pos);
      entry.circle.setLatLng(pos);
      entry.anim = k < 1 ? requestAnimationFrame(step) : null;
    };
    entry.anim = requestAnimationFrame(step);
  }

  buildIcon(uid, data, now) {
    const stale = Number.isFinite(data.ts) && now - data.ts > STALE_AFTER_MS;
    const classes = ['member-marker'];
    if (uid === this.selfUid) classes.push('self');
    if (stale) classes.push('stale');
    if (uid === this.speakerUid) classes.push('talking');
    if (uid === this.watchedUid) classes.push('watched');

    const root = document.createElement('div');
    root.className = classes.join(' ');
    if (Number.isFinite(data.heading) && (data.speed || 0) > 0.5) {
      const arrow = document.createElement('div');
      arrow.className = 'heading';
      arrow.style.transform = `rotate(${Math.round(data.heading)}deg)`;
      root.append(arrow);
    }
    const profile = this.profiles.get(uid);
    const pin = document.createElement('div');
    pin.className = 'pin';
    pin.style.background = colorFor(uid);
    if (profile && profile.color) {
      pin.style.boxShadow = `0 0 0 3px ${profile.color}, 0 2px 6px rgba(0,0,0,.5)`;
      root.dataset.role = profile.role || '';
    }
    pin.textContent = initials(data.name);
    const label = document.createElement('div');
    label.className = 'label';
    label.textContent = uid === this.selfUid ? 'You' : String(data.name || 'Member');
    root.append(pin, label);
    if (profile && (profile.roleShort || profile.badges.length)) {
      const badges = document.createElement('div');
      badges.className = 'gear-badges';
      if (profile.roleShort) {
        const role = document.createElement('span');
        role.className = 'gear-badge role';
        role.style.background = profile.color;
        role.textContent = profile.roleShort;
        badges.append(role);
      }
      for (const text of profile.badges.slice(0, 4)) {
        const b = document.createElement('span');
        b.className = `gear-badge${text === 'AED' ? ' aed' : ''}`;
        b.textContent = text;
        badges.append(b);
      }
      root.append(badges);
    }
    if (this.liveUids.has(uid)) {
      const live = document.createElement('span');
      live.className = 'live-badge';
      live.textContent = 'LIVE';
      root.append(live);
    }

    return L.divIcon({ html: root, className: '', iconSize: [40, 40], iconAnchor: [20, 20], popupAnchor: [0, -20] });
  }

  popupContent(uid) {
    const entry = this.markers.get(uid);
    const wrap = document.createElement('div');
    if (!entry) return wrap;
    const d = entry.data;
    const title = document.createElement('strong');
    title.textContent = uid === this.selfUid ? `${d.name} (you)` : d.name;
    const profile = this.profiles.get(uid);
    const lines = [
      profile && profile.description ? profile.description : null,
      `±${Math.round(d.acc || 0)} m accuracy`,
      Number.isFinite(d.speed) ? `${(d.speed * 3.6).toFixed(1)} km/h` : null,
      `Updated ${formatAgo(serverNow() - (d.ts || serverNow()))}`,
      `${d.lat.toFixed(5)}, ${d.lng.toFixed(5)}`
    ].filter(Boolean);
    wrap.append(title);
    for (const line of lines) {
      const p = document.createElement('div');
      p.textContent = line;
      wrap.append(p);
    }
    const actions = this.popupActions ? this.popupActions(uid) : [];
    if (actions.length) {
      const row = document.createElement('div');
      row.className = 'popup-actions';
      for (const action of actions) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = `btn small${action.primary ? ' primary' : ''}`;
        button.textContent = action.label;
        button.addEventListener('click', () => {
          this.map.closePopup();
          action.onClick();
        });
        row.append(button);
      }
      wrap.append(row);
    }
    return wrap;
  }

  clear() {
    for (const uid of [...this.markers.keys()]) this.remove(uid);
    this.setIncidents([]);
    this.overlayLayer.clearLayers();
    this.overlayKey = '';
    this.profiles = new Map();
    this.cancelPick();
    this.liveUids = new Set();
    this.watchedUid = null;
    this.followUid = null;
    this.hasCentered = false;
  }

  destroy() {
    clearInterval(this.staleTimer);
    this.clear();
    this.map.remove();
  }
}
