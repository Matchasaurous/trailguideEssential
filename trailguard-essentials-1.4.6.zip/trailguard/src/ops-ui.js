// Operations screens: broadcast announcements, course-map layers (GeoJSON / KML)
// and the after-action report (metrics, CSV / PDF download, PDF to Drive).
import { $, h, toast, openSheet, isSheetOpen, formatAgo } from './ui.js';
import { serverNow } from './clock.js';
import { AUDIENCES, LEVELS } from './announcements.js';
import { parseOverlayFile, OVERLAY_CATEGORIES } from './location.js';

// The analytics module (with the PDF library) loads on first use, keeping it out of the start-up bundle.
let analyticsModule = null;
function analytics() {
  if (!analyticsModule) analyticsModule = import('./analytics.js');
  return analyticsModule;
}
import { ROLES, FIELD_UNITS, caseTypeLabel, unitLabel, isDispatchRole } from './roles.js';

function download(blob, fileName) {
  const url = URL.createObjectURL(blob);
  const a = h('a', { href: url, download: fileName, style: 'display:none' });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

function slug(text) {
  return String(text || 'event').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'event';
}

/** datetime-local value for a timestamp (local time). */
function toLocalInput(ts) {
  const d = new Date(ts);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/* ============================== Announcements ============================== */

export class AnnouncementsUI {
  /**
   * @param {object} ctx  center (AnnouncementCenter), uid, isDispatcher(), getMembers(), onSent(a), openIncident(iid)
   */
  constructor(ctx) {
    this.ctx = ctx;
    this.ac = new AbortController();
  }

  start() {
    const sig = { signal: this.ac.signal };
    $('#announce-audience').replaceChildren(...Object.entries(AUDIENCES).map(([k, label]) => h('option', { value: k }, label)));
    $('#announce-form').addEventListener('submit', (e) => { e.preventDefault(); this.send(); }, sig);
    this.ctx.center.addEventListener('change', () => { if (isSheetOpen('announce-sheet')) this.render(); }, sig);
  }

  stop() {
    this.ac.abort();
  }

  open() {
    openSheet('announce-sheet');
    this.render();
  }

  render() {
    const dispatcher = this.ctx.isDispatcher();
    $('#announce-form').hidden = !dispatcher;
    const list = this.ctx.center.visibleToMe();
    const members = this.ctx.getMembers();
    $('#announce-empty').hidden = list.length > 0;
    $('#announce-list').replaceChildren(...list.map((a) => {
      const acked = Object.keys(a.acks || {}).length;
      const recipients = Object.entries(members).filter(([uid, m]) => uid !== a.by && (a.audience === 'all' || isDispatchRole(m.role) || (a.audience !== 'dispatch' && m.unit === a.audience))).length;
      const mine = a.by === this.ctx.uid;
      const needsAck = !mine && !this.ctx.center.acked(a);
      return h('li', { class: `announce-item level-${a.level}${a.kind === 'fire' ? ' fire' : ''}` },
        h('div', { class: 'grow' },
          h('div', { class: 'small muted' }, [a.kind === 'fire' ? 'FIRE ALERT' : LEVELS[a.level].label, a.name,
            a.audience !== 'all' ? `to ${AUDIENCES[a.audience]}` : 'to everyone', formatAgo(serverNow() - (a.ts || serverNow()))].join(' · ')),
          h('div', { class: 'title' }, a.text),
          dispatcher || mine ? h('div', { class: 'small muted' }, `Acknowledged by ${acked} of ${recipients}`) : null),
        a.caseId ? h('button', { class: 'btn small ghost', type: 'button', onClick: () => this.ctx.openIncident(a.caseId) }, 'Case') : null,
        needsAck ? h('button', { class: 'btn small primary', type: 'button', onClick: () => this.ctx.center.ack(a.id) }, 'Acknowledge') : null,
        dispatcher ? h('button', {
          class: 'btn small ghost',
          type: 'button',
          'aria-label': 'Delete announcement',
          onClick: async () => {
            if (!confirm('Delete this announcement for everyone?')) return;
            try { await this.ctx.center.remove(a.id); } catch (err) { toast(err.message, 'error'); }
          }
        }, 'Delete') : null);
    }));
  }

  async send() {
    const button = $('#announce-send');
    button.disabled = true;
    try {
      const level = $('#announce-level').value;
      if (level === 'critical' && !confirm('Send a CRITICAL announcement? It sounds the alarm on every receiving phone, even in silent mode.')) return;
      const a = await this.ctx.center.send({ text: $('#announce-text').value, level, audience: $('#announce-audience').value });
      $('#announce-text').value = '';
      this.ctx.onSent(a);
      toast('Announcement broadcast', 'ok');
    } catch (err) {
      toast(/permission/i.test(err.message) ? 'Only dispatchers can broadcast announcements.' : err.message, 'error');
    } finally {
      button.disabled = false;
    }
  }
}

/* ============================== Map layers ============================== */

export class LayersUI {
  /** @param {object} ctx  store (OverlayStore), isDispatcher() */
  constructor(ctx) {
    this.ctx = ctx;
    this.ac = new AbortController();
  }

  start() {
    const sig = { signal: this.ac.signal };
    $('#layer-file').addEventListener('change', (e) => this.upload(e.target.files && e.target.files[0]), sig);
    this.ctx.store.addEventListener('change', () => { if (isSheetOpen('layers-sheet')) this.render(); }, sig);
    $('#layer-legend').replaceChildren(...Object.values(OVERLAY_CATEGORIES).map((c) => h('span', { class: 'legend-item' },
      h('i', { style: `background:${c.color}` }), c.label)));
  }

  stop() {
    this.ac.abort();
  }

  open() {
    openSheet('layers-sheet');
    this.render();
  }

  render() {
    const list = this.ctx.store.overlays;
    $('#layer-empty').hidden = list.length > 0;
    $('#layer-list').replaceChildren(...list.map((o) => h('li', {},
      h('label', { class: 'grow switch-row' },
        h('span', {}, h('span', { class: 'title' }, o.name), h('span', { class: 'small muted' }, `${o.count} features`)),
        h('input', {
          type: 'checkbox',
          checked: o.visible,
          'aria-label': `Show ${o.name}`,
          onChange: (e) => this.ctx.store.setVisible(o.id, e.target.checked).catch((err) => toast(err.message, 'error'))
        })),
      h('button', {
        class: 'btn small ghost',
        type: 'button',
        onClick: async () => {
          if (!confirm(`Remove the layer "${o.name}" for everyone?`)) return;
          try { await this.ctx.store.remove(o.id); } catch (err) { toast(err.message, 'error'); }
        }
      }, 'Remove'))));
  }

  async upload(file) {
    $('#layer-file').value = '';
    if (!file) return;
    try {
      const parsed = await parseOverlayFile(file);
      await this.ctx.store.add(parsed);
      toast(`Layer "${parsed.name}" added (${parsed.count} features)`, 'ok');
    } catch (err) {
      toast(/permission/i.test(err.message) ? 'Only dispatchers can add map layers.' : err.message, 'error', 6000);
    }
  }
}

/* ============================== After-action report ============================== */

export class ReportsUI {
  /**
   * @param {object} ctx  dispatch, getMembers(), getEpcr(): raw epcr tree, getGroupName(), bodycam
   */
  constructor(ctx) {
    this.ctx = ctx;
    this.ac = new AbortController();
    this.report = null;
  }

  start() {
    const sig = { signal: this.ac.signal };
    const fail = (err) => toast(`Report failed: ${err.message}`, 'error');
    $('#report-run').addEventListener('click', () => this.run().catch(fail), sig);
    $('#report-csv').addEventListener('click', () => this.downloadCsv().catch(fail), sig);
    $('#report-pdf').addEventListener('click', () => this.downloadPdf().catch(fail), sig);
    $('#report-drive').addEventListener('click', () => this.saveToDrive(), sig);
  }

  stop() {
    this.ac.abort();
  }

  open() {
    const times = [...this.ctx.dispatch.incidents.values()].map((i) => i.createdAt).filter(Number.isFinite);
    const from = times.length ? Math.min(...times) : serverNow() - 12 * 3600 * 1000;
    $('#report-from').value = toLocalInput(from);
    $('#report-to').value = toLocalInput(serverNow() + 60_000);
    openSheet('reports-sheet');
    this.run().catch((err) => toast(`Report failed: ${err.message}`, 'error'));
  }

  range() {
    const from = Date.parse($('#report-from').value);
    const to = Date.parse($('#report-to').value);
    return { from: Number.isFinite(from) ? from : null, to: Number.isFinite(to) ? to : null };
  }

  async run() {
    const { from, to } = this.range();
    if (from !== null && to !== null && to <= from) {
      toast('The end of the period must be after the start.', 'error');
      return null;
    }
    const lib = await analytics();
    this.lib = lib;
    this.report = lib.computeAnalytics({
      incidents: this.ctx.dispatch.incidents,
      members: this.ctx.getMembers(),
      epcr: this.ctx.getEpcr(),
      from,
      to,
      now: serverNow()
    });
    this.render();
    return this.report;
  }

  render() {
    const r = this.report;
    if (!r || !this.lib) return;
    const { formatSeconds, INTERVALS } = this.lib;
    const t = r.totals;
    const tile = (label, value, sub) => h('div', { class: 'kpi' }, h('span', { class: 'kpi-label' }, label), h('strong', {}, value), sub ? h('span', { class: 'kpi-sub' }, sub) : null);
    $('#report-kpis').replaceChildren(
      tile('Cases', String(t.cases), `${t.closed} resolved · ${t.open} open`),
      tile('Reported → Accepted', formatSeconds(r.times.reportToAccept.avg), `median ${formatSeconds(r.times.reportToAccept.median)}`),
      tile('Accepted → On scene', formatSeconds(r.times.acceptToOnScene.avg), `median ${formatSeconds(r.times.acceptToOnScene.median)}`),
      tile('Reported → Resolved', formatSeconds(r.times.reportToResolved.avg), `90% within ${formatSeconds(r.times.reportToResolved.p90)}`),
      tile('Unit utilisation', `${Math.round(r.utilisation.avgUtilisationActive * 100)}%`, `${r.utilisation.activeUnits} of ${r.utilisation.unitsWithRole} units responded`),
      r.patients ? tile('Patients (ePCR)', String(r.patients.total), `${r.patients.byDisposition.transported || 0} transported`) : null
    );
    const table = (head, rows) => h('div', { class: 'table-wrap' }, h('table', { class: 'report-table' },
      h('thead', {}, h('tr', {}, ...head.map((c) => h('th', {}, c)))),
      h('tbody', {}, ...rows.map((row) => h('tr', {}, ...row.map((c) => h('td', {}, c == null ? '' : String(c))))))));
    const sevName = { 1: 'P1 Critical', 2: 'P2 Urgent', 3: 'P3 Routine' };
    // A simple bar per severity / role, scaled to the largest count.
    const bars = (entries) => {
      const max = Math.max(1, ...entries.map(([, n]) => n));
      return h('div', { class: 'bars' }, ...entries.map(([label, n, color]) => h('div', { class: 'bar-row' },
        h('span', { class: 'bar-label' }, label),
        h('span', { class: 'bar' }, h('i', { style: `width:${(n / max) * 100}%;${color ? `background:${color}` : ''}` })),
        h('span', { class: 'bar-value' }, String(n)))));
    };
    $('#report-body').replaceChildren(
      h('h4', {}, 'Response times'),
      table(['Interval', 'Cases', 'Average', 'Median', '90th pct'], Object.entries(INTERVALS).map(([k, label]) => {
        const s = r.times[k];
        return [label, s.n, formatSeconds(s.avg), formatSeconds(s.median), formatSeconds(s.p90)];
      })),
      h('h4', {}, 'By severity'),
      bars([1, 2, 3].map((s) => [sevName[s], r.bySeverity[s], s === 1 ? 'var(--danger)' : s === 2 ? 'var(--warn)' : 'var(--accent)'])),
      table(['Severity', 'Cases', 'To accept', 'To scene', 'To resolve'], [1, 2, 3].map((s) => [sevName[s], r.bySeverity[s],
        formatSeconds(r.timesBySeverity[s].reportToAccept.avg), formatSeconds(r.timesBySeverity[s].reportToOnScene.avg), formatSeconds(r.timesBySeverity[s].reportToResolved.avg)])),
      h('h4', {}, 'By responding role'),
      bars([...FIELD_UNITS.map((u) => [ROLES[u].label, r.byRole[u], ROLES[u].color]), ['No unit', r.byRole.none, '']]),
      table(['Role', 'Cases', 'To accept', 'Accept → scene', 'To resolve'], FIELD_UNITS.map((u) => [ROLES[u].label, r.byRole[u],
        formatSeconds(r.timesByRole[u].reportToAccept.avg), formatSeconds(r.timesByRole[u].acceptToOnScene.avg), formatSeconds(r.timesByRole[u].reportToResolved.avg)])),
      h('h4', {}, 'Case types'),
      bars(Object.entries(r.byType).sort((a, b) => b[1] - a[1]).map(([type, n]) => [caseTypeLabel(type), n, ''])),
      h('h4', {}, 'Unit utilisation'),
      table(['Unit', 'Role', 'Cases', 'Declined', 'Committed', 'Utilisation', 'Avg to scene'],
        r.units.map((u) => [u.name, u.role ? unitLabel(u.role) : '—', u.cases, u.declined, formatSeconds(u.busyS), `${Math.round(u.utilisation * 100)}%`, formatSeconds(u.avgResponseS)])),
      h('p', { class: 'small muted' }, `SOS ${t.sos} · field reports ${t.reports} · verified after review ${t.verified} · rejected ${t.rejected} · withdrawn ${t.withdrawn} · auto-assignments ${t.autoAssigned} (${t.autoLapsed} not answered in time).`)
    );
  }

  fileBase() {
    const stamp = new Date().toISOString().replace(/[-:]/g, '').slice(0, 13);
    return `after-action_${slug(this.ctx.getGroupName())}_${stamp}`;
  }

  async downloadCsv() {
    const r = await this.run();
    if (!r) return;
    download(new Blob([this.lib.toCsv(r, { groupName: this.ctx.getGroupName() })], { type: 'text/csv;charset=utf-8' }), `${this.fileBase()}.csv`);
  }

  async pdfBlob() {
    const r = await this.run();
    if (!r) return null;
    return this.lib.toPdf(r, { groupName: this.ctx.getGroupName() }).output('blob');
  }

  async downloadPdf() {
    const blob = await this.pdfBlob();
    if (blob) download(blob, `${this.fileBase()}.pdf`);
  }

  async saveToDrive() {
    let blob;
    try {
      blob = await this.pdfBlob();
    } catch (err) {
      toast(`Report failed: ${err.message}`, 'error');
      return;
    }
    if (!blob) return;
    const button = $('#report-drive');
    button.disabled = true;
    try {
      this.ctx.bodycam.groupName = this.ctx.getGroupName();
      await this.ctx.bodycam.sendReport(new Blob([blob], { type: 'application/pdf' }), `${this.fileBase()}.pdf`);
      toast('Report saved to Drive — Trailguard Essentials Archive › your group › Reports', 'ok', 5000);
    } catch (err) {
      toast(`Not saved to Drive: ${err.message}`, 'error', 6000);
    } finally {
      button.disabled = false;
    }
  }
}
