// WebRTC full-mesh between the online members of one group, signalled through
// Firebase Realtime Database. Every pair of members shares one RTCPeerConnection
// carrying one audio transceiver (push-to-talk) and one video transceiver (live
// bodycam). Tracks are swapped in and out with replaceTrack(), so pressing PTT or
// going live never needs SDP renegotiation and starts instantly.
//
// Glare-free by construction: the member with the lexicographically smaller uid
// always sends the offer. Every message carries the sender's and recipient's
// session ids (one per app load) and a connection generation, so stale messages
// from previous sessions are ignored.
import {
  ref, push, remove, serverTimestamp, onChildAdded, onChildChanged, onChildRemoved
} from 'firebase/database';
import { db, config } from './firebase.js';

const VIDEO_MAX_BITRATE = 600_000;      // per viewer; video is only sent to members watching
const AUDIO_MAX_BITRATE = 32_000;       // Opus voice; 14 peers × 32 kbps ≈ 450 kbps uplink while talking
const DISCONNECT_GRACE_MS = 6000;
const MAX_ICE_RESTARTS = 2;
// Presence can blink (a stale onDisconnect from a previous connection, a brief
// reconnect). Keep the media connection through such blips instead of tearing it down.
const PRESENCE_GRACE_MS = 10_000;

let audioSink = null;
function getAudioSink() {
  if (!audioSink) {
    audioSink = document.createElement('div');
    audioSink.id = 'rtc-audio-sink';
    audioSink.hidden = true;
    document.body.append(audioSink);
  }
  return audioSink;
}

class Peer {
  constructor(mesh, uid, sid, initiator, gen) {
    this.mesh = mesh;
    this.uid = uid;
    this.remoteSid = sid;
    this.initiator = initiator;
    this.gen = gen;
    this.closed = false;
    this.pendingRemoteCandidates = [];
    this.outgoingCandidates = [];
    this.descriptionSent = false;
    this.iceRestarts = 0;
    this.disconnectTimer = null;
    this.goneTimer = null;
    this.audioTx = null;
    this.videoTx = null;
    this.videoStream = null;

    this.audioEl = document.createElement('audio');
    this.audioEl.autoplay = true;
    this.audioEl.setAttribute('playsinline', '');
    this.audioEl.muted = !mesh.audibleUids.has(uid);
    this.audioEl.dataset.uid = uid;
    getAudioSink().append(this.audioEl);

    this.pc = new RTCPeerConnection({ iceServers: config.iceServers, bundlePolicy: 'max-bundle' });

    if (initiator) {
      this.audioTx = this.pc.addTransceiver('audio', { direction: 'sendrecv' });
      this.videoTx = this.pc.addTransceiver('video', { direction: 'sendrecv' });
    }

    this.pc.onicecandidate = (event) => {
      if (!event.candidate) return;
      const candidate = event.candidate.toJSON();
      if (this.descriptionSent) this.send('candidate', candidate);
      else this.outgoingCandidates.push(candidate);
    };
    this.pc.ontrack = (event) => this.attachTrack(event.track);
    this.pc.onconnectionstatechange = () => this.handleConnectionState();
  }

  get state() {
    return this.closed ? 'closed' : this.pc.connectionState;
  }

  send(type, payload) {
    return this.mesh.sendSignal(this.uid, this.remoteSid, this.gen, type, payload);
  }

  flushOutgoingCandidates() {
    this.descriptionSent = true;
    const queued = this.outgoingCandidates.splice(0);
    for (const candidate of queued) this.send('candidate', candidate);
  }

  async applyLocalTracks() {
    if (this.audioTx) {
      const audio = this.mesh.audioTrackFor(this.uid);
      await this.audioTx.sender.replaceTrack(audio);
      if (audio) await this.limitBitrate(this.audioTx.sender, AUDIO_MAX_BITRATE);
    }
    if (this.videoTx) {
      const video = this.mesh.videoTrackFor(this.uid);
      await this.videoTx.sender.replaceTrack(video);
      if (video) await this.limitBitrate(this.videoTx.sender, VIDEO_MAX_BITRATE);
    }
  }

  async limitBitrate(sender, maxBitrate) {
    try {
      const params = sender.getParameters();
      if (!params.encodings || params.encodings.length === 0) return; // not negotiated yet
      if (params.encodings[0].maxBitrate === maxBitrate) return;
      params.encodings[0].maxBitrate = maxBitrate;
      await sender.setParameters(params);
    } catch (err) {
      console.debug('setParameters not applied', err);
    }
  }

  async setAudio(track) {
    if (this.closed || !this.audioTx) return;
    if (this.audioTx.sender.track === (track || null)) return;
    await this.audioTx.sender.replaceTrack(track || null);
    if (track) await this.limitBitrate(this.audioTx.sender, AUDIO_MAX_BITRATE);
  }

  async setVideo(track) {
    if (this.closed || !this.videoTx) return;
    if (this.videoTx.sender.track === (track || null)) return;
    await this.videoTx.sender.replaceTrack(track || null);
    if (track) await this.limitBitrate(this.videoTx.sender, VIDEO_MAX_BITRATE);
  }

  async createOffer(iceRestart = false) {
    if (this.closed) return;
    await this.applyLocalTracks();
    const offer = await this.pc.createOffer({ iceRestart });
    await this.pc.setLocalDescription(offer);
    await this.send('offer', { type: offer.type, sdp: this.pc.localDescription.sdp });
    this.flushOutgoingCandidates();
  }

  async handleOffer(description) {
    if (this.closed) return;
    await this.pc.setRemoteDescription(description);
    if (!this.audioTx || !this.videoTx) {
      for (const transceiver of this.pc.getTransceivers()) {
        const kind = transceiver.receiver.track.kind;
        if (kind === 'audio' && !this.audioTx) this.audioTx = transceiver;
        else if (kind === 'video' && !this.videoTx) this.videoTx = transceiver;
        else continue;
        transceiver.direction = 'sendrecv';
      }
    }
    await this.applyLocalTracks();
    await this.drainRemoteCandidates();
    const answer = await this.pc.createAnswer();
    await this.pc.setLocalDescription(answer);
    await this.send('answer', { type: answer.type, sdp: this.pc.localDescription.sdp });
    this.flushOutgoingCandidates();
  }

  async handleAnswer(description) {
    if (this.closed || this.pc.signalingState !== 'have-local-offer') return;
    await this.pc.setRemoteDescription(description);
    await this.drainRemoteCandidates();
    await this.applyLocalTracks();
  }

  async handleCandidate(candidate) {
    if (this.closed) return;
    if (!this.pc.remoteDescription) {
      this.pendingRemoteCandidates.push(candidate);
      return;
    }
    try {
      await this.pc.addIceCandidate(candidate);
    } catch (err) {
      console.debug('Ignoring bad ICE candidate', err);
    }
  }

  async drainRemoteCandidates() {
    const queued = this.pendingRemoteCandidates.splice(0);
    for (const candidate of queued) {
      try { await this.pc.addIceCandidate(candidate); } catch (err) { console.debug('Ignoring bad ICE candidate', err); }
    }
  }

  attachTrack(track) {
    if (track.kind === 'audio') {
      this.audioEl.srcObject = new MediaStream([track]);
      this.playAudio();
    } else if (track.kind === 'video') {
      this.videoStream = new MediaStream([track]);
      this.mesh.dispatchEvent(new CustomEvent('remote-video', { detail: { uid: this.uid, stream: this.videoStream } }));
    }
  }

  playAudio() {
    const p = this.audioEl.play();
    if (p && typeof p.catch === 'function') {
      p.catch((err) => {
        if (err && err.name === 'NotAllowedError') this.mesh.dispatchEvent(new Event('autoplay-blocked'));
      });
    }
  }

  setAudible(audible) {
    this.audioEl.muted = !audible;
    if (audible && this.audioEl.paused && this.audioEl.srcObject) this.playAudio();
  }

  handleConnectionState() {
    if (this.closed) return;
    const state = this.pc.connectionState;
    this.mesh.dispatchEvent(new CustomEvent('peer-state', { detail: { uid: this.uid, state } }));

    if (state === 'connected') {
      clearTimeout(this.disconnectTimer);
      this.disconnectTimer = null;
      this.iceRestarts = 0;
      return;
    }
    if (!this.initiator) return; // the offerer owns recovery

    if (state === 'disconnected') {
      clearTimeout(this.disconnectTimer);
      this.disconnectTimer = setTimeout(() => {
        if (!this.closed && this.pc.connectionState === 'disconnected') this.recover();
      }, DISCONNECT_GRACE_MS);
    } else if (state === 'failed') {
      this.recover();
    }
  }

  recover() {
    if (this.closed) return;
    if (this.iceRestarts < MAX_ICE_RESTARTS && this.pc.signalingState === 'stable') {
      this.iceRestarts += 1;
      this.createOffer(true).catch((err) => console.warn('ICE restart failed', err));
    } else {
      this.mesh.rebuildPeer(this.uid);
    }
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    clearTimeout(this.disconnectTimer);
    clearTimeout(this.goneTimer);
    try { this.pc.close(); } catch { /* already closed */ }
    this.audioEl.srcObject = null;
    this.audioEl.remove();
    this.videoStream = null;
    this.mesh.dispatchEvent(new CustomEvent('peer-state', { detail: { uid: this.uid, state: 'closed' } }));
  }
}

export class RtcMesh extends EventTarget {
  /**
   * Events: 'peer-state' {uid, state}, 'remote-video' {uid, stream}, 'autoplay-blocked',
   *         'roster' {roster: Map<uid, presence>}
   */
  constructor({ gid, uid, sid }) {
    super();
    this.gid = gid;
    this.uid = uid;
    this.sid = sid;
    this.peers = new Map();
    this.roster = new Map();
    this.localAudioTrack = null;
    this.localVideoTrack = null;
    this.audibleUids = new Set();
    this.audioFilter = null;
    this.unsubs = [];
    this.signalChain = Promise.resolve();
    this.started = false;
  }

  async start() {
    if (this.started) return;
    this.started = true;
    const inbox = ref(db, `signals/${this.gid}/${this.uid}`);
    // Messages addressed to earlier sessions are useless; clear them before
    // anyone learns our new session id from presence.
    await remove(inbox).catch(() => {});

    this.unsubs.push(onChildAdded(inbox, (snap) => {
      const msg = snap.val();
      remove(snap.ref).catch(() => {});
      this.signalChain = this.signalChain
        .then(() => this.processSignal(msg))
        .catch((err) => console.warn('Signal handling failed', err));
    }, (err) => console.warn('Signal inbox error', err)));

    const presenceRef = ref(db, `presence/${this.gid}`);
    const onPresence = (snap) => this.handlePresence(snap.key, snap.val());
    this.unsubs.push(
      onChildAdded(presenceRef, onPresence),
      onChildChanged(presenceRef, onPresence),
      onChildRemoved(presenceRef, (snap) => this.handlePresenceGone(snap.key))
    );
  }

  handlePresence(uid, value) {
    if (!value) return;
    this.roster.set(uid, value);
    this.dispatchEvent(new CustomEvent('roster', { detail: { roster: this.roster } }));
    if (uid === this.uid) return;

    const existing = this.peers.get(uid);
    if (existing && existing.remoteSid === value.sid) {
      clearTimeout(existing.goneTimer);
      existing.goneTimer = null;
      // They may have started or stopped watching our live video.
      existing.setVideo(this.videoTrackFor(uid)).catch(() => {});
      return;
    }
    if (existing) {
      existing.close();
      this.peers.delete(uid);
    }
    if (this.uid < uid) this.createInitiator(uid, value.sid);
    // Otherwise the remote member is the offerer; we wait for its offer.
  }

  handlePresenceGone(uid) {
    this.roster.delete(uid);
    this.dispatchEvent(new CustomEvent('roster', { detail: { roster: this.roster } }));
    const peer = this.peers.get(uid);
    if (!peer) return;
    clearTimeout(peer.goneTimer);
    peer.goneTimer = setTimeout(() => {
      if (!this.roster.has(uid) && this.peers.get(uid) === peer) {
        peer.close();
        this.peers.delete(uid);
      }
    }, PRESENCE_GRACE_MS);
  }

  createInitiator(uid, sid) {
    const peer = new Peer(this, uid, sid, true, Date.now());
    this.peers.set(uid, peer);
    peer.createOffer().catch((err) => console.warn('Offer failed', err));
    return peer;
  }

  rebuildPeer(uid) {
    const presence = this.roster.get(uid);
    const old = this.peers.get(uid);
    if (old) old.close();
    this.peers.delete(uid);
    if (presence && this.uid < uid) this.createInitiator(uid, presence.sid);
  }

  async processSignal(msg) {
    if (!msg || msg.toSid !== this.sid || msg.from === this.uid) return;
    let payload;
    try { payload = JSON.parse(msg.data); } catch { return; }

    let peer = this.peers.get(msg.from);
    if (msg.type === 'offer') {
      if (!(msg.from < this.uid)) return; // only the smaller uid may offer
      if (!peer || peer.remoteSid !== msg.fromSid || peer.gen !== msg.gen) {
        if (peer) peer.close();
        peer = new Peer(this, msg.from, msg.fromSid, false, msg.gen);
        this.peers.set(msg.from, peer);
      }
      await peer.handleOffer(payload);
      return;
    }

    if (!peer || peer.remoteSid !== msg.fromSid || peer.gen !== msg.gen) return;
    if (msg.type === 'answer') await peer.handleAnswer(payload);
    else if (msg.type === 'candidate') await peer.handleCandidate(payload);
  }

  sendSignal(toUid, toSid, gen, type, payload) {
    return push(ref(db, `signals/${this.gid}/${toUid}`), {
      from: this.uid,
      fromSid: this.sid,
      toSid,
      gen,
      type,
      data: JSON.stringify(payload),
      ts: serverTimestamp()
    }).catch((err) => console.warn(`Could not send ${type} to ${toUid}`, err));
  }

  /**
   * Transmit (or stop transmitting) the microphone. canHear(uid) limits who gets
   * it — e.g. the medical channel goes only to medical responders and dispatchers;
   * everyone else's sender stays empty. Applies to peers that connect mid-transmission too.
   */
  async setLocalAudioTrack(track, canHear = null) {
    this.localAudioTrack = track || null;
    this.audioFilter = track && typeof canHear === 'function' ? canHear : null;
    await Promise.all([...this.peers.values()].map((p) => p.setAudio(this.audioTrackFor(p.uid)).catch(() => {})));
  }

  audioTrackFor(uid) {
    if (!this.localAudioTrack) return null;
    if (this.audioFilter) {
      try {
        if (!this.audioFilter(uid)) return null;
      } catch {
        return null;
      }
    }
    return this.localAudioTrack;
  }

  async setLocalVideoTrack(track) {
    this.localVideoTrack = track || null;
    await Promise.all([...this.peers.values()].map((p) => p.setVideo(this.videoTrackFor(p.uid)).catch(() => {})));
  }

  /** Live video goes only to members whose presence says they are watching us. */
  videoTrackFor(uid) {
    if (!this.localVideoTrack) return null;
    const presence = this.roster.get(uid);
    return presence && presence.watching === this.uid ? this.localVideoTrack : null;
  }

  /** Number of members currently watching our live video. */
  viewerCount() {
    let n = 0;
    for (const [uid, p] of this.roster) if (uid !== this.uid && p.watching === this.uid) n += 1;
    return n;
  }

  /** Only current floor holders on the channels I listen to are audible; everyone else is muted locally. */
  setAudible(uids) {
    const list = uids instanceof Set ? [...uids] : Array.isArray(uids) ? uids : uids ? [uids] : [];
    this.audibleUids = new Set(list);
    for (const peer of this.peers.values()) peer.setAudible(this.audibleUids.has(peer.uid));
  }

  /** Call from a user gesture to satisfy autoplay policies. */
  unlockAudio() {
    for (const peer of this.peers.values()) {
      if (peer.audioEl.srcObject) peer.playAudio();
    }
  }

  getRemoteVideo(uid) {
    const peer = this.peers.get(uid);
    return peer ? peer.videoStream : null;
  }

  connectionSummary() {
    let connected = 0;
    let total = 0;
    for (const [uid] of this.roster) {
      if (uid === this.uid) continue;
      total += 1;
      const peer = this.peers.get(uid);
      if (peer && peer.state === 'connected') connected += 1;
    }
    return { connected, total };
  }

  async stop() {
    for (const unsub of this.unsubs) unsub();
    this.unsubs = [];
    for (const peer of this.peers.values()) peer.close();
    this.peers.clear();
    this.roster.clear();
    this.localAudioTrack = null;
    this.localVideoTrack = null;
    this.started = false;
    await remove(ref(db, `signals/${this.gid}/${this.uid}`)).catch(() => {});
  }
}
