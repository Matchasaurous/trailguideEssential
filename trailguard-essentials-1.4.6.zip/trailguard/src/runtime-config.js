// Site configuration read at runtime from /trailguard-config.js (window.TRAILGUARD_CONFIG),
// so a hosted copy can be configured by editing one file on the server — no rebuild.
// A value set there wins; anything missing or empty falls back to the build-time
// VITE_* value from .env (which is how the Android app and local dev are configured).
// No dependencies, so any module (and the unit tests) can import it.

function readConfig() {
  try {
    const c = typeof window !== 'undefined' ? window.TRAILGUARD_CONFIG : undefined;
    return c && typeof c === 'object' ? c : {};
  } catch {
    return {};
  }
}

const runtime = readConfig();

/** True when /trailguard-config.js was loaded (even if some values are empty). */
export const hasRuntimeConfig = Object.keys(runtime).length > 0;

/**
 * A configuration value: runtime[path] when set (non-empty string, or any
 * non-string value such as an array), else the build-time fallback.
 * path may be dotted, e.g. 'firebase.apiKey'.
 */
export function setting(path, fallback) {
  let v = runtime;
  for (const key of String(path).split('.')) {
    v = v && typeof v === 'object' ? v[key] : undefined;
  }
  if (typeof v === 'string') return v.trim() ? v.trim() : fallback;
  if (v === undefined || v === null) return fallback;
  return v;
}
