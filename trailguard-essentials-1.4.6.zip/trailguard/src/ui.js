// Small DOM helpers. User-supplied text is only ever inserted via textContent,
// never innerHTML, so names and group titles cannot inject markup.

export const $ = (selector, root = document) => root.querySelector(selector);
export const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

/**
 * Create an element. attrs: plain attributes, plus `class`, `dataset`, `on<Event>` handlers.
 * Children may be strings (inserted as text), nodes, or null/false (skipped).
 */
export function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value === null || value === undefined || value === false) continue;
    if (key === 'class') el.className = value;
    else if (key === 'dataset') Object.assign(el.dataset, value);
    else if (key.startsWith('on') && typeof value === 'function') el.addEventListener(key.slice(2).toLowerCase(), value);
    else if (value === true) el.setAttribute(key, '');
    else el.setAttribute(key, String(value));
  }
  for (const child of children.flat()) {
    if (child === null || child === undefined || child === false) continue;
    el.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return el;
}

let toastTimer = null;
export function toast(message, kind = 'info', ms = 3200) {
  const el = $('#toast');
  if (!el) return;
  el.textContent = message;
  el.dataset.kind = kind;
  el.hidden = false;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => { el.hidden = true; }, 250);
  }, ms);
}

export function showScreen(id) {
  for (const screen of $$('.screen')) screen.hidden = screen.id !== id;
}

export function setBusy(button, busy, busyLabel) {
  if (!button) return;
  if (busy) {
    button.dataset.label = button.textContent;
    if (busyLabel) button.textContent = busyLabel;
    button.disabled = true;
  } else {
    if (button.dataset.label) button.textContent = button.dataset.label;
    button.disabled = false;
  }
}

export function initials(name) {
  const parts = String(name || '?').trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  const letters = parts.length === 1 ? parts[0].slice(0, 2) : parts[0][0] + parts[parts.length - 1][0];
  return letters.toUpperCase();
}

/** Deterministic, readable marker colour per user id. */
export function colorFor(uid) {
  let hash = 0;
  for (let i = 0; i < uid.length; i++) hash = (hash * 31 + uid.charCodeAt(i)) >>> 0;
  return `hsl(${hash % 360} 70% 45%)`;
}

export function formatAgo(ms) {
  if (!Number.isFinite(ms) || ms < 0) return 'just now';
  const s = Math.round(ms / 1000);
  if (s < 10) return 'just now';
  if (s < 60) return `${s}s ago`;
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  const hrs = Math.round(m / 60);
  if (hrs < 48) return `${hrs} h ago`;
  return `${Math.round(hrs / 24)} d ago`;
}

export function formatDuration(totalSeconds) {
  const s = Math.max(0, Math.floor(totalSeconds));
  const mm = String(Math.floor(s / 60)).padStart(2, '0');
  const ss = String(s % 60).padStart(2, '0');
  return `${mm}:${ss}`;
}

export function formatBytes(bytes) {
  if (!Number.isFinite(bytes)) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

/** Map Firebase error codes to messages a field user can act on. */
export function friendlyError(err) {
  const code = err && (err.code || err.message) ? String(err.code || err.message) : '';
  const table = {
    'auth/invalid-email': 'That email address is not valid.',
    'auth/missing-password': 'Enter your password.',
    'auth/weak-password': 'Use a password of at least 8 characters.',
    'auth/email-already-in-use': 'An account already exists for that email. Sign in instead.',
    'auth/invalid-credential': 'Email or password is incorrect.',
    'auth/wrong-password': 'Email or password is incorrect.',
    'auth/user-not-found': 'Email or password is incorrect.',
    'auth/too-many-requests': 'Too many attempts. Wait a minute and try again.',
    'auth/network-request-failed': 'No network connection.',
    'auth/operation-not-allowed': 'Google sign-in isn’t switched on for this app yet. Use email and password for now.',
    'auth/unauthorized-domain': 'Google sign-in isn’t allowed on this address yet (add it under Firebase Authentication → Settings → Authorized domains).',
    'auth/popup-blocked': 'Your browser blocked the Google sign-in window. Allow pop-ups for this site and try again.',
    'auth/account-exists-with-different-credential': 'That email already has an account. Sign in with your email and password.',
    'auth/web-storage-unsupported': 'This browser blocks the storage Google sign-in needs. Use email and password, or another browser.',
    PERMISSION_DENIED: 'Permission denied. You may no longer be a member of this group.'
  };
  for (const [key, message] of Object.entries(table)) {
    if (code.includes(key)) return message;
  }
  return (err && err.message) || 'Something went wrong.';
}

export function vibrate(pattern) {
  try { if (navigator.vibrate) navigator.vibrate(pattern); } catch { /* unsupported */ }
}

/* ---------------- Bottom sheets (one open at a time) ---------------- */

const sheetCloseHandlers = new Map();

/** Open a sheet by id, closing any other. onClose runs when it is closed. */
const DOCK_MIN_WIDTH = 1100;

/** On wide screens, the board and case panels dock beside the map with no backdrop. */
export function isDockedLayout() {
  return typeof window !== 'undefined' && window.innerWidth >= DOCK_MIN_WIDTH;
}

export function openSheet(id, onClose) {
  closeSheets(id);
  const el = document.getElementById(id);
  if (!el) return;
  const docked = el.classList.contains('dockable') && isDockedLayout();
  el.classList.toggle('docked', docked);
  el.hidden = false;
  el.scrollTop = 0;
  document.getElementById('sheet-backdrop').hidden = docked;
  for (const sel of ['.status-tools', '.live-strip', '.sos-btn', '.fire-btn']) {
    const tool = document.querySelector(sel);
    if (tool) tool.classList.toggle('shifted', docked);
  }
  if (onClose) sheetCloseHandlers.set(id, onClose);
}

/** Close every open sheet (except `keep`). */
export function closeSheets(keep) {
  for (const el of document.querySelectorAll('.sheet')) {
    if (el.id === keep || el.hidden) continue;
    el.hidden = true;
    const handler = sheetCloseHandlers.get(el.id);
    sheetCloseHandlers.delete(el.id);
    if (handler) { try { handler(); } catch (err) { console.warn(err); } }
  }
  if (!keep) {
    document.getElementById('sheet-backdrop').hidden = true;
    for (const sel of ['.status-tools', '.live-strip', '.sos-btn', '.fire-btn']) {
      const tool = document.querySelector(sel);
      if (tool) tool.classList.remove('shifted');
    }
  }
}

export function isSheetOpen(id) {
  const el = document.getElementById(id);
  return !!el && !el.hidden;
}

export function formatDistance(m) {
  if (!Number.isFinite(m)) return '';
  return m < 1000 ? `${Math.round(m / 10) * 10} m` : `${(m / 1000).toFixed(m < 10000 ? 1 : 0)} km`;
}

/**
 * Resize a camera / gallery image to a JPEG data URL (longest side ≤ maxSide).
 * Returns { dataUrl, width, height, bytes } — bytes is the decoded JPEG size.
 */
export async function resizeImage(file, maxSide = 1280, quality = 0.72) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('That file is not an image this device can read.'));
      el.src = url;
    });
    const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const width = Math.max(1, Math.round(img.naturalWidth * scale));
    const height = Math.max(1, Math.round(img.naturalHeight * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, width, height);
    ctx.drawImage(img, 0, 0, width, height);
    const dataUrl = canvas.toDataURL('image/jpeg', quality);
    const bytes = Math.floor((dataUrl.length - dataUrl.indexOf(',') - 1) * 3 / 4);
    return { dataUrl, width, height, bytes };
  } finally {
    URL.revokeObjectURL(url);
  }
}
