// Zello-style push-to-talk over the WebRTC mesh, driven by the on-screen button
// (touch, mouse or trackpad click-and-hold), a keyboard key (laptops, Bluetooth
// PTT buttons that act as keyboards) and hardware side buttons on Android:
// Samsung XCover key (1015), KEYCODE_STEM_PRIMARY (264), KEYCODE_STEM_1 (265),
// plus any button the user adds, and Knox PTT intents on managed devices
// (com.samsung.android.knox.intent.action.PTT_PRESS / PTT_RELEASE by default).
// The Samsung Top key (1079) is SOS.
//
// Channels:
//   main    — everyone hears it; everyone except Ushers / Marshals can talk.
//   medical — only medical responders and dispatchers hear it or talk on it.
// Each channel has its own floor, so a medical handover can run while the main
// channel is busy. Members on both channels hear both.
//
// Floor control: the talker writes ptt/{gid}/{channel}. Database rules only accept
// that write when the floor is free (or stale) and the talker may use the
// channel, so the server arbitrates two people pressing at the same instant —
// the loser gets PERMISSION_DENIED and a busy tone.
// Audio: on floor grant the microphone track is swapped into the audio sender of
// every peer who may hear the channel (no renegotiation) and swapped out on
// release. Receivers only unmute current floor holders on their channels.
import { ref, set, remove, onValue, onDisconnect, serverTimestamp } from 'firebase/database';
import { db } from './firebase.js';
import { serverNow } from './clock.js';
import { vibrate } from './ui.js';
import {
  onHardwareKey, isForeground, notify, setNativeKeys, learnNativeKey, cancelLearnNativeKey, hasNativeKeys,
  setKnoxPttActions, DEFAULT_NATIVE_PTT_KEYS, DEFAULT_NATIVE_SOS_KEYS, NATIVE_KEY_NAMES,
  DEFAULT_KNOX_PTT_PRESS, DEFAULT_KNOX_PTT_RELEASE
} from './native.js';

export const MAX_TALK_MS = 60_000;     // hard cap per transmission
export const CHANNELS = {
  main: { label: 'Main', short: 'MAIN' },
  medical: { label: 'Medical', short: 'MED' }
};
const STALE_FLOOR_MS = 65_000;         // matches database.rules.json
const MIC_IDLE_RELEASE_MS = 20_000;    // close the mic (and its OS indicator) when idle

class Tones {
  constructor() { this.ctx = null; }

  unlock() {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    if (!this.ctx) this.ctx = new Ctx();
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
  }

  beep(freq, startOffset, duration, gain = 0.12) {
    if (!this.ctx) return;
    const t0 = this.ctx.currentTime + startOffset;
    const osc = this.ctx.createOscillator();
    const amp = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, t0);
    amp.gain.setValueAtTime(0, t0);
    amp.gain.linearRampToValueAtTime(gain, t0 + 0.01);
    amp.gain.setValueAtTime(gain, t0 + duration - 0.02);
    amp.gain.linearRampToValueAtTime(0, t0 + duration);
    osc.connect(amp).connect(this.ctx.destination);
    osc.start(t0);
    osc.stop(t0 + duration + 0.02);
  }

  permit() { this.beep(880, 0, 0.07); this.beep(1320, 0.09, 0.09); }
  end() { this.beep(660, 0, 0.12, 0.09); }
  busy() { this.beep(330, 0, 0.12); this.beep(330, 0.18, 0.12); this.beep(330, 0.36, 0.12); }
  incoming() { this.beep(1046, 0, 0.05, 0.06); }
  incomingEnd() { this.beep(523, 0, 0.08, 0.06); }
}

export class PushToTalk extends EventTarget {
  /**
   * Events: 'state' {state: idle|requesting|talking|busy|denied}, 'speaker' {speaker|null, self, speakers},
   *         'channel' {channel}, 'error' {message}
   * @param {object} opts
   *   gid, uid, sid, name, mesh,
   *   channels(): {listen: string[], talk: string[]} — my channels (from my role),
   *   canHear(uid, channel): boolean — may that member hear this channel?
   */
  constructor({ gid, uid, sid, name, mesh, channels, canHear }) {
    super();
    this.gid = gid;
    this.uid = uid;
    this.sid = sid;
    this.name = name;
    this.mesh = mesh;
    this.channels = channels || (() => ({ listen: ['main'], talk: ['main'] }));
    this.canHear = canHear || (() => true);
    this.rootRef = ref(db, `ptt/${gid}`);
    this.floors = { main: null, medical: null };
    this.txChannel = 'main';
    this.talkingOn = null;
    this.tones = new Tones();
    this.micStream = null;
    this.micIdleTimer = null;
    this.talkTimer = null;
    this.disconnectOp = null;
    this.speaker = null;
    this.phase = 'idle';      // idle | requesting | talking
    this.pressed = false;
    this.pressToken = 0;
    this.holders = new Set();  // 'button' | 'keyboard' | 'xcover' — talk while any is held
    this.unsub = null;
    this.onVisibility = () => { if (document.visibilityState === 'hidden') this.releaseAll(); };
  }

  start() {
    this.unsub = onValue(this.rootRef, (snap) => this.handleFloors(snap.val()),
      (err) => this.emitError(`Channel unavailable: ${err.message}`));
    document.addEventListener('visibilitychange', this.onVisibility);
    this.refreshChannels();
  }

  floorRef(channel) {
    return ref(db, `ptt/${this.gid}/${channel}`);
  }

  /** My role changed (or on start): keep the selected talk channel valid. */
  refreshChannels() {
    const { talk } = this.channels();
    if (!talk.includes(this.txChannel) && talk.length) this.setChannel(talk[0]);
    else this.emitState();
    this.handleFloors(this.lastValue || null);
  }

  /** Choose the channel the PTT button talks on. */
  setChannel(channel) {
    if (!CHANNELS[channel] || channel === this.txChannel) return;
    if (!this.channels().talk.includes(channel)) {
      this.emitError(`You can't talk on the ${CHANNELS[channel].label} channel.`);
      return;
    }
    if (this.phase === 'talking' || this.phase === 'requesting') return;
    this.txChannel = channel;
    this.speaker = this.floors[channel];
    this.dispatchEvent(new CustomEvent('channel', { detail: { channel } }));
    this.emitState();
  }

  get canTalk() {
    return this.channels().talk.includes(this.txChannel);
  }

  get state() {
    if (this.phase === 'talking' || this.phase === 'requesting') return this.phase;
    if (!this.canTalk) return 'denied';
    const floor = this.floors[this.txChannel];
    if (floor && !this.isSelf(floor)) return 'busy';
    return 'idle';
  }

  isSelf(floor) {
    return !!floor && floor.uid === this.uid && floor.sid === this.sid;
  }

  handleFloors(value) {
    this.lastValue = value;
    const { listen } = this.channels();
    const prevFloors = this.floors;
    const next = {};
    for (const ch of Object.keys(CHANNELS)) {
      const f = value && value[ch];
      next[ch] = f && Number.isFinite(f.since) && serverNow() - f.since <= STALE_FLOOR_MS ? { ...f, channel: ch } : null;
    }
    this.floors = next;

    const remote = Object.keys(CHANNELS)
      .filter((ch) => listen.includes(ch) && next[ch] && !this.isSelf(next[ch]))
      .map((ch) => next[ch]);
    this.mesh.setAudible(remote.map((f) => f.uid));

    for (const ch of Object.keys(CHANNELS)) {
      if (!listen.includes(ch)) continue;
      const before = prevFloors[ch];
      const now = next[ch];
      const remoteNow = now && !this.isSelf(now);
      if (remoteNow && (!before || before.uid !== now.uid || before.since !== now.since)) this.tones.incoming();
      else if (!now && before && !this.isSelf(before)) this.tones.incomingEnd();
    }

    // Floor was taken away from us (dispatcher cleared it, or it went stale).
    if (this.phase === 'talking' && this.talkingOn && !this.isSelf(next[this.talkingOn])) this.stopTransmitting(false);

    const mine = this.talkingOn ? next[this.talkingOn] : null;
    const self = this.isSelf(mine);
    const speakers = self ? [mine, ...remote] : remote;
    this.speaker = speakers[0] || null;
    this.dispatchEvent(new CustomEvent('speaker', { detail: { speaker: this.speaker, self: this.speaker ? this.isSelf(this.speaker) : false, speakers } }));
    this.emitState();
  }

  emitState() {
    this.dispatchEvent(new CustomEvent('state', { detail: { state: this.state } }));
  }

  emitError(message) {
    this.dispatchEvent(new CustomEvent('error', { detail: { message } }));
  }

  /** Must run inside the user's press gesture (unlocks audio playback). */
  unlockAudio() {
    this.tones.unlock();
    this.mesh.unlockAudio();
  }

  async ensureMic() {
    clearTimeout(this.micIdleTimer);
    const live = this.micStream && this.micStream.getAudioTracks().find((t) => t.readyState === 'live');
    if (live) return live;
    if (!window.isSecureContext) throw Object.assign(new Error('Open Trailguard over HTTPS to use the microphone.'), { name: 'SecurityError' });
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error('Microphone access is not available in this browser.');
    }
    if (!this.micRequest) {
      // One request at a time: a press while the permission prompt is open waits for it.
      this.micRequest = navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
        video: false
      }).catch((err) => {
        if (err && err.name === 'OverconstrainedError') return navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        throw err;
      }).finally(() => { this.micRequest = null; });
    }
    const stream = await this.micRequest;
    const already = this.micStream && this.micStream.getAudioTracks().find((t) => t.readyState === 'live');
    if (already) {
      if (stream !== this.micStream) for (const t of stream.getTracks()) t.stop();
      return already;
    }
    this.micStream = stream;
    const track = this.micStream.getAudioTracks()[0];
    track.enabled = false;
    track.addEventListener('ended', () => {
      // The OS took the microphone (phone call, another app): stop and reopen on the next press.
      if (this.phase === 'talking') this.releaseAll();
      this.micStream = null;
    });
    return track;
  }

  /**
   * Ask for microphone permission ahead of the first press (call from a tap):
   * the prompt — or Android's runtime permission dialog — otherwise swallows the
   * first press. The mic is kept muted and closed again after the idle time.
   */
  async primeMicrophone() {
    if (this.phase !== 'idle' || (this.micStream && this.micStream.active)) return;
    try {
      await this.ensureMic();
      if (this.phase === 'idle') this.scheduleMicRelease();
    } catch (err) {
      this.emitError(micErrorMessage(err));
    }
  }

  scheduleMicRelease() {
    clearTimeout(this.micIdleTimer);
    this.micIdleTimer = setTimeout(() => this.closeMic(), MIC_IDLE_RELEASE_MS);
  }

  closeMic() {
    clearTimeout(this.micIdleTimer);
    if (this.phase === 'talking' || this.phase === 'requesting') return;
    if (this.micStream) for (const t of this.micStream.getTracks()) t.stop();
    this.micStream = null;
  }

  /** Start talking. source names what is held, so two inputs don't cut each other off. */
  async press(source = 'button') {
    this.holders.add(source);
    if (this.pressed) return;
    this.pressed = true;
    const token = ++this.pressToken;
    this.unlockAudio();

    if (!this.canTalk) {
      this.tones.busy();
      this.emitError('Push-to-talk is not available for your role. You will still hear announcements.');
      return;
    }
    const channel = this.txChannel;
    const holder = this.floors[channel];
    if (holder && !this.isSelf(holder)) {
      this.tones.busy();
      vibrate([40, 60, 40]);
      this.emitError(`${holder.name} is talking on ${CHANNELS[channel].label}`);
      return;
    }

    this.phase = 'requesting';
    this.talkingOn = channel;
    this.emitState();

    let track;
    try {
      track = await this.ensureMic();
    } catch (err) {
      this.phase = 'idle';
      this.talkingOn = null;
      this.emitState();
      this.emitError(micErrorMessage(err));
      return;
    }
    if (!this.pressed || token !== this.pressToken) {
      this.phase = 'idle';
      this.talkingOn = null;
      this.emitState();
      this.scheduleMicRelease();
      return;
    }

    const floorRef = this.floorRef(channel);
    try {
      await set(floorRef, { uid: this.uid, name: this.name.slice(0, 40), sid: this.sid, since: serverTimestamp() });
    } catch (err) {
      this.phase = 'idle';
      this.talkingOn = null;
      this.tones.busy();
      vibrate([40, 60, 40]);
      this.emitState();
      const other = this.floors[channel];
      if (other && !this.isSelf(other)) {
        this.emitError(`${other.name} is talking on ${CHANNELS[channel].label}`);
      } else {
        // The floor looked free, so the database refused us for another reason.
        console.warn('PTT floor write refused', err);
        this.emitError('Push-to-talk was refused by the database. If Trailguard was just updated, deploy the new rules (npm run deploy:rules); otherwise check your role.');
      }
      this.scheduleMicRelease();
      return;
    }

    if (!this.pressed || token !== this.pressToken) {
      // Released while the floor request was in flight: give the floor back.
      await remove(floorRef).catch(() => {});
      this.phase = 'idle';
      this.talkingOn = null;
      this.emitState();
      this.scheduleMicRelease();
      return;
    }

    try {
      this.disconnectOp = onDisconnect(floorRef);
      await this.disconnectOp.remove();
    } catch { /* best effort; the rules also expire the floor after 65 s */ }

    track.enabled = true;
    await this.mesh.setLocalAudioTrack(track, (peerUid) => this.canHear(peerUid, channel));
    this.phase = 'talking';
    this.tones.permit();
    vibrate(30);
    this.emitState();

    clearTimeout(this.talkTimer);
    this.talkTimer = setTimeout(() => {
      this.emitError('Transmission limit reached (60 s)');
      this.releaseAll();
    }, MAX_TALK_MS);
  }

  async release(source = 'button') {
    this.holders.delete(source);
    if (this.holders.size > 0) return;
    this.pressed = false;
    if (this.phase === 'requesting') {
      // press() notices `pressed === false` and cleans up after its await.
      return;
    }
    if (this.phase === 'talking') await this.stopTransmitting(true);
  }

  /** A member's role changed while I talk: re-check who may hear the channel. */
  refreshAudience() {
    if (this.phase !== 'talking' || !this.talkingOn) return;
    const channel = this.talkingOn;
    const track = this.micStream && this.micStream.getAudioTracks()[0];
    if (track) this.mesh.setLocalAudioTrack(track, (peerUid) => this.canHear(peerUid, channel));
  }

  releaseAll() {
    this.holders.clear();
    return this.release('all');
  }

  async stopTransmitting(giveBackFloor) {
    if (this.phase !== 'talking') return;
    this.phase = 'idle';
    clearTimeout(this.talkTimer);
    const track = this.micStream && this.micStream.getAudioTracks()[0];
    if (track) track.enabled = false;
    await this.mesh.setLocalAudioTrack(null);
    const channel = this.talkingOn;
    this.talkingOn = null;
    if (giveBackFloor && channel) {
      await remove(this.floorRef(channel)).catch(() => {});
    }
    if (this.disconnectOp) {
      this.disconnectOp.cancel().catch(() => {});
      this.disconnectOp = null;
    }
    this.tones.end();
    this.emitState();
    this.scheduleMicRelease();
  }

  /** Bind press-and-hold to a button (pointer + keyboard). */
  bindButton(button) {
    const down = (e) => {
      if (e.type === 'pointerdown') {
        if (e.button !== 0) return;
        e.preventDefault();
        try { button.setPointerCapture(e.pointerId); } catch { /* not supported */ }
      }
      this.press();
    };
    const up = (e) => { if (e) e.preventDefault(); this.release(); };
    // Enter on the focused button; Space is handled by the global key binding.
    const keyDown = (e) => {
      if (e.key === 'Enter' && !e.repeat) { e.preventDefault(); this.press(); }
    };
    const keyUp = (e) => { if (e.key === 'Enter') { e.preventDefault(); this.release(); } };
    const block = (e) => e.preventDefault();

    button.addEventListener('pointerdown', down);
    button.addEventListener('pointerup', up);
    button.addEventListener('pointercancel', up);
    button.addEventListener('lostpointercapture', up);
    button.addEventListener('keydown', keyDown);
    button.addEventListener('keyup', keyUp);
    button.addEventListener('contextmenu', block);

    return () => {
      button.removeEventListener('pointerdown', down);
      button.removeEventListener('pointerup', up);
      button.removeEventListener('pointercancel', up);
      button.removeEventListener('lostpointercapture', up);
      button.removeEventListener('keydown', keyDown);
      button.removeEventListener('keyup', keyUp);
      button.removeEventListener('contextmenu', block);
    };
  }

  async stop() {
    this.pressed = false;
    this.holders.clear();
    await this.stopTransmitting(true);
    if (this.unsub) this.unsub();
    this.unsub = null;
    document.removeEventListener('visibilitychange', this.onVisibility);
    this.phase = 'idle';
    this.closeMic();
    if (this.tones.ctx) this.tones.ctx.close().catch(() => {});
    this.tones.ctx = null;
  }
}

/* ======================= Keyboard and hardware keys ======================= */

const LS_PTT_KEY = 'trailguard.pttKey';
const LS_NATIVE_KEYS = 'trailguard.nativePttKeys';
const LS_KNOX = 'trailguard.knoxPtt';

/** Knox PTT intent settings: { enabled, press, release }. */
export function loadKnoxPtt() {
  try {
    const saved = JSON.parse(localStorage.getItem(LS_KNOX) || 'null');
    if (saved && typeof saved.press === 'string') {
      return { enabled: saved.enabled !== false, press: saved.press, release: typeof saved.release === 'string' ? saved.release : '' };
    }
  } catch { /* ignore */ }
  return { enabled: true, press: DEFAULT_KNOX_PTT_PRESS, release: DEFAULT_KNOX_PTT_RELEASE };
}

function saveKnoxPtt(value) {
  try { localStorage.setItem(LS_KNOX, JSON.stringify(value)); } catch { /* ignore */ }
}

export function loadNativePttKeys() {
  try {
    const saved = JSON.parse(localStorage.getItem(LS_NATIVE_KEYS) || 'null');
    if (Array.isArray(saved) && saved.every((k) => Number.isInteger(k) && k > 0)) return saved;
  } catch { /* ignore */ }
  return DEFAULT_NATIVE_PTT_KEYS.slice();
}

function saveNativePttKeys(keys) {
  try { localStorage.setItem(LS_NATIVE_KEYS, JSON.stringify(keys)); } catch { /* ignore */ }
}
export const DEFAULT_PTT_KEY = { code: 'Space', key: ' ', keyCode: 32 };

export function loadPttKey() {
  try {
    const saved = JSON.parse(localStorage.getItem(LS_PTT_KEY) || 'null');
    if (saved && (saved.code || saved.keyCode)) return saved;
  } catch { /* corrupt or unavailable storage */ }
  return { ...DEFAULT_PTT_KEY };
}

export function savePttKey(binding) {
  try { localStorage.setItem(LS_PTT_KEY, JSON.stringify(binding)); } catch { /* ignore */ }
}

export function describeKey(binding) {
  if (!binding) return 'None';
  if (binding.code === 'Space') return 'Space bar';
  if (binding.code && /^Key[A-Z]$/.test(binding.code)) return binding.code.slice(3);
  if (binding.code && /^Digit\d$/.test(binding.code)) return binding.code.slice(5);
  if (binding.code) return binding.code.replace(/([a-z])([A-Z])/g, '$1 $2');
  return `Key ${binding.keyCode}`;
}

function isTypingTarget(el) {
  if (!el) return false;
  const tag = el.tagName;
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || el.isContentEditable;
}

function matches(binding, e) {
  if (binding.code && e.code) return e.code === binding.code;
  if (binding.keyCode && e.keyCode) return e.keyCode === binding.keyCode;
  // Some rugged-phone and Bluetooth PTT buttons report only a key name.
  return !!binding.key && binding.key !== 'Unidentified' && e.key === binding.key;
}

/** A readable reason for a getUserMedia failure. */
function micErrorMessage(err) {
  switch (err && err.name) {
    case 'NotAllowedError':
    case 'PermissionDeniedError':
      return 'Microphone permission is off. Allow it for Trailguard in your browser or phone settings to talk.';
    case 'SecurityError':
      return err.message || 'The microphone needs a secure (HTTPS) connection.';
    case 'NotFoundError':
    case 'DevicesNotFoundError':
      return 'No microphone found on this device.';
    case 'NotReadableError':
    case 'TrackStartError':
      return 'The microphone is in use by another app (e.g. a phone call). Close it and try again.';
    default:
      return `Microphone unavailable: ${(err && err.message) || 'unknown error'}`;
  }
}

/**
 * Global push-to-talk key (default: Space bar) plus the Samsung XCover key for
 * PTT and the Top key for SOS. Keys are ignored while typing in a field.
 */
export class PttKeys {
  /**
   * @param {PushToTalk} ptt
   * @param {{onTopKey?: (down: boolean) => void}} opts
   */
  constructor(ptt, { onTopKey } = {}) {
    this.ptt = ptt;
    this.onTopKey = onTopKey;
    this.binding = loadPttKey();
    this.nativePtt = loadNativePttKeys();
    this.nativeSos = DEFAULT_NATIVE_SOS_KEYS.slice();
    this.knox = loadKnoxPtt();
    this.hardwareHeld = new Set();
    this.learning = null;
    this.held = false;
    this.unsubHardware = null;
    this.onKeyDown = (e) => this.handleKeyDown(e);
    this.onKeyUp = (e) => this.handleKeyUp(e);
    this.onBlur = () => this.releaseKeyboard();
  }

  start() {
    window.addEventListener('keydown', this.onKeyDown, true);
    window.addEventListener('keyup', this.onKeyUp, true);
    window.addEventListener('blur', this.onBlur);
    this.unsubHardware = onHardwareKey((event) => this.handleHardware(event));
    setNativeKeys(this.nativePtt, this.nativeSos).catch((err) => console.warn('Hardware keys not registered', err));
    setKnoxPttActions(this.knox.press, this.knox.release).catch((err) => console.warn('Knox PTT actions not registered', err));
  }

  /** Knox PTT intents on managed Samsung devices: on/off and the broadcast action names. */
  async setKnox({ enabled, press, release }) {
    const next = {
      enabled: enabled !== false,
      press: String(press || DEFAULT_KNOX_PTT_PRESS).trim(),
      release: String(release === undefined ? DEFAULT_KNOX_PTT_RELEASE : release).trim()
    };
    if (!/^[A-Za-z0-9_.]{3,200}$/.test(next.press) || (next.release && !/^[A-Za-z0-9_.]{3,200}$/.test(next.release))) {
      throw new Error('Action names may only contain letters, digits, dots and underscores.');
    }
    await setKnoxPttActions(next.press, next.release);
    this.knox = next;
    saveKnoxPtt(next);
    if (!next.enabled) this.releaseIntent();
    return next;
  }

  releaseIntent() {
    for (const code of [...this.hardwareHeld]) {
      if (String(code).startsWith('intent')) {
        this.hardwareHeld.delete(code);
        this.ptt.release(code);
      }
    }
  }

  describeNativeKeys() {
    return this.nativePtt.map((k) => `${NATIVE_KEY_NAMES[k] || 'Key'} (${k})`).join(', ');
  }

  /** Add the next hardware button pressed as a push-to-talk key (Android app). */
  async learnNative() {
    if (!hasNativeKeys) throw new Error('Hardware buttons need the Android app.');
    const code = await learnNativeKey();
    if (this.nativeSos.includes(code)) throw new Error('That button is the SOS key.');
    if (!this.nativePtt.includes(code)) this.nativePtt = [...this.nativePtt, code];
    saveNativePttKeys(this.nativePtt);
    await setNativeKeys(this.nativePtt, this.nativeSos);
    return code;
  }

  resetNativeKeys() {
    this.nativePtt = DEFAULT_NATIVE_PTT_KEYS.slice();
    saveNativePttKeys(this.nativePtt);
    return setNativeKeys(this.nativePtt, this.nativeSos);
  }

  stop() {
    window.removeEventListener('keydown', this.onKeyDown, true);
    window.removeEventListener('keyup', this.onKeyUp, true);
    window.removeEventListener('blur', this.onBlur);
    if (this.unsubHardware) this.unsubHardware();
    this.unsubHardware = null;
    this.releaseKeyboard();
    if (this.learning) this.learning.reject(new Error('cancelled'));
    this.learning = null;
    cancelLearnNativeKey();
    for (const source of this.hardwareHeld) this.ptt.release(source);
    this.hardwareHeld.clear();
  }

  /** Resolves with the next key pressed (Escape cancels) and saves it as the PTT key. */
  learn() {
    if (this.learning) this.learning.reject(new Error('cancelled'));
    return new Promise((resolve, reject) => { this.learning = { resolve, reject }; });
  }

  resetToDefault() {
    this.binding = { ...DEFAULT_PTT_KEY };
    savePttKey(this.binding);
    return this.binding;
  }

  handleKeyDown(e) {
    if (this.learning) {
      e.preventDefault();
      e.stopPropagation();
      const pending = this.learning;
      this.learning = null;
      if (e.key === 'Escape') {
        pending.reject(new Error('cancelled'));
        return;
      }
      this.binding = { code: e.code || '', key: e.key || '', keyCode: e.keyCode || 0 };
      savePttKey(this.binding);
      pending.resolve(this.binding);
      return;
    }
    if (!matches(this.binding, e) || isTypingTarget(e.target)) return;
    e.preventDefault();
    if (e.repeat || this.held) return;
    this.held = true;
    this.ptt.press('keyboard');
  }

  handleKeyUp(e) {
    if (!this.held || !matches(this.binding, e)) return;
    e.preventDefault();
    this.releaseKeyboard();
  }

  releaseKeyboard() {
    if (!this.held) return;
    this.held = false;
    this.ptt.release('keyboard');
  }

  handleHardware({ keyCode, down, source: origin, ptt }) {
    const fromIntent = origin === 'intent';
    if (fromIntent && !this.knox.enabled) return;
    if ((fromIntent && ptt) || this.nativePtt.includes(keyCode)) {
      const source = fromIntent ? 'intent' : `hw${keyCode}`;
      if (down) {
        if (!isForeground()) {
          // Android does not let a backgrounded app open the microphone.
          notify({ key: 'ptt-background', title: 'Trailguard Essentials', body: 'Unlock and open Trailguard to talk.' });
          return;
        }
        if (this.hardwareHeld.has(source)) return;
        this.hardwareHeld.add(source);
        this.ptt.unlockAudio();
        this.ptt.press(source);
      } else {
        this.hardwareHeld.delete(source);
        this.ptt.release(source);
      }
    } else if (this.nativeSos.includes(keyCode) && this.onTopKey) {
      this.onTopKey(!!down);
    }
  }

}
