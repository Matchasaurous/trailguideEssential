// Web push: alerts that reach a browser while Trailguard is closed or its tab is asleep.
//
// Browsers suspend hidden tabs, so the in-page alert centre (alerts.js) stops
// hearing the database. With web push on, the browser hands this device's
// Firebase Cloud Messaging token to the Apps Script server (pushRegister). After
// an SOS, an assignment, a report waiting for review or an announcement, the
// app that made it asks the server to push it (push); the server reads the case
// from the database, works out who needs the alert (the same rules as
// alerts.js) and sends it through FCM. The service worker (sw-background.js)
// shows it with the same tag the app uses, so the app's own notification and the
// push replace each other instead of doubling up.
//
// Limits: browsers never ring through silent mode or Do Not Disturb, there is no
// background GPS, and on iPhone / iPad push only works once Trailguard is added
// to the Home Screen (iOS 16.4+). The Android app has its own background service
// and does not use this.
import { config, firebaseApp } from './firebase.js';
import { isNative } from './native.js';
import { callGas } from './bodycam.js';

const LS_PUSH = 'tg.push';               // {token, uid, gid, at}
const REFRESH_MS = 3 * 24 * 3600 * 1000;  // re-register at least every 3 days (keeps the server's list fresh)

function load() {
  try { return JSON.parse(localStorage.getItem(LS_PUSH) || 'null'); } catch { return null; }
}
function save(value) {
  try {
    if (value) localStorage.setItem(LS_PUSH, JSON.stringify(value));
    else localStorage.removeItem(LS_PUSH);
  } catch { /* storage blocked */ }
}

export function isIos() {
  const ua = navigator.userAgent || '';
  return /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
}

function isStandalone() {
  return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
}

/** Can this browser receive background alerts? {supported, reason: native | no-server | ios-home-screen | browser} */
export function pushEnvironment() {
  if (isNative) return { supported: false, reason: 'native' };
  if (!config.gasEndpoint || !firebaseApp) return { supported: false, reason: 'no-server' };
  const apis = 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
  if (!apis) return { supported: false, reason: isIos() && !isStandalone() ? 'ios-home-screen' : 'browser' };
  return { supported: true, reason: '' };
}

export function deviceLabel() {
  const ua = navigator.userAgent || '';
  const browser = /Edg\//.test(ua) ? 'Edge' : /SamsungBrowser/.test(ua) ? 'Samsung Internet' : /Firefox\//.test(ua) ? 'Firefox'
    : /(Chrome|CriOS)\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  const os = /Android/.test(ua) ? 'Android' : /iPad/.test(ua) ? 'iPad' : /iPhone|iPod/.test(ua) ? 'iPhone'
    : /Windows/.test(ua) ? 'Windows' : /Macintosh/.test(ua) ? (navigator.maxTouchPoints > 1 ? 'iPad' : 'Mac') : /Linux/.test(ua) ? 'Linux' : '';
  return os ? `${browser} on ${os}` : browser;
}

let messagingPromise = null;
function messaging() {
  if (!messagingPromise) {
    messagingPromise = (async () => {
      const sdk = await import('firebase/messaging');
      if (!(await sdk.isSupported())) throw new Error('This browser cannot receive background alerts. Use Chrome, Edge, Firefox or Safari, or the Android app.');
      return { sdk, messaging: sdk.getMessaging(firebaseApp) };
    })();
    messagingPromise.catch(() => { messagingPromise = null; });
  }
  return messagingPromise;
}

function serviceWorker() {
  return Promise.race([
    navigator.serviceWorker.ready,
    new Promise((_, reject) => setTimeout(() => reject(new Error('The app is still installing its offline files. Reload the page and try again.')), 10000))
  ]);
}

async function currentToken() {
  const { sdk, messaging: m } = await messaging();
  const options = { serviceWorkerRegistration: await serviceWorker() };
  if (config.pushVapidKey) options.vapidKey = config.pushVapidKey;
  try {
    return await sdk.getToken(m, options);
  } catch (err) {
    const code = String((err && err.code) || '');
    if (code.includes('permission-blocked') || code.includes('permission-default')) throw new Error('Allow notifications for this site, then try again.');
    if (code.includes('token-subscribe-failed') || code.includes('installations')) {
      throw new Error('Firebase refused to register this device. In Google Cloud → APIs → Credentials, allow the Firebase Installations API and FCM Registration API for the web API key.');
    }
    throw err;
  }
}

export class WebPush {
  /** @param {{gid: string, uid: string, getIdToken: () => Promise<string>}} opts */
  constructor({ gid, uid, getIdToken }) {
    this.gid = gid;
    this.uid = uid;
    this.getIdToken = getIdToken;
  }

  /** {supported, reason, permission, on} for the settings row. */
  status() {
    const env = pushEnvironment();
    const permission = 'Notification' in window ? Notification.permission : 'default';
    const record = load();
    const on = env.supported && permission === 'granted' && !!record && record.uid === this.uid;
    return { ...env, permission, on };
  }

  /** Turn background alerts on for this browser. Call from a click (the permission prompt needs one). */
  async enable() {
    const env = pushEnvironment();
    if (!env.supported) throw new Error(explainUnsupported(env.reason));
    let permission = Notification.permission;
    if (permission === 'default') permission = await Notification.requestPermission();
    if (permission !== 'granted') {
      throw new Error(permission === 'denied'
        ? 'Notifications are blocked for this site. Allow them in the browser\'s site settings, then try again.'
        : 'Allow notifications to turn on background alerts.');
    }
    const token = await currentToken();
    await this.register(token);
  }

  async register(token) {
    await callGas({ action: 'pushRegister', idToken: await this.getIdToken(), groupId: this.gid, token, device: deviceLabel() });
    save({ token, uid: this.uid, gid: this.gid, at: Date.now() });
  }

  /** On opening a group: keep the server's copy of this browser's token current (tokens rotate). */
  async refresh() {
    const record = load();
    if (!record || record.uid !== this.uid) return;
    const env = pushEnvironment();
    if (!env.supported || Notification.permission !== 'granted') {
      if (env.supported && Notification.permission === 'denied') save(null);
      return;
    }
    try {
      const token = await currentToken();
      if (token !== record.token || record.gid !== this.gid || Date.now() - (record.at || 0) > REFRESH_MS) await this.register(token);
    } catch (err) {
      console.debug('Background alert refresh failed', err);
    }
  }

  /** Turn background alerts off for this browser. */
  async disable() {
    await unregisterPush(this.getIdToken);
  }

  /** Ask the server for a test alert on every device I have registered. */
  async test() {
    return callGas({ action: 'pushTest', idToken: await this.getIdToken(), groupId: this.gid });
  }
}

/**
 * Remove this browser from the server (sign-out, or the switch). Best effort: the
 * local record is cleared even if the server cannot be reached.
 */
export async function unregisterPush(getIdToken) {
  const record = load();
  save(null);
  if (!record || !record.token) return;
  try {
    await callGas({ action: 'pushUnregister', idToken: await getIdToken(), groupId: record.gid, token: record.token });
  } catch (err) {
    console.debug('Background alert unregister failed', err);
  }
  try {
    const { sdk, messaging: m } = await messaging();
    await sdk.deleteToken(m);
  } catch { /* nothing to delete */ }
}

/**
 * After this device raised an alert-worthy event, ask the server to push it to
 * whoever needs it. Runs from every device (the Android app too), fire and forget.
 * kind: case | announcement.
 */
export function triggerPush({ getIdToken, gid, kind, id }) {
  if (!config.gasEndpoint || !id) return;
  (async () => {
    try {
      await callGas({ action: 'push', idToken: await getIdToken(), groupId: gid, kind, id });
    } catch (err) {
      console.debug('Background alert not sent:', err.message);
    }
  })();
}

export function explainUnsupported(reason) {
  switch (reason) {
    case 'native': return 'The Android app keeps alerts running in the background by itself.';
    case 'no-server': return 'Background alerts need the Apps Script server (gasEndpoint in trailguard-config.js).';
    case 'ios-home-screen': return 'On iPhone and iPad, add Trailguard to the Home Screen first (Share → Add to Home Screen), open it from there, then turn this on.';
    default: return 'This browser cannot receive background alerts. Use Chrome, Edge, Firefox or Safari 16.4+, or the Android app.';
  }
}
