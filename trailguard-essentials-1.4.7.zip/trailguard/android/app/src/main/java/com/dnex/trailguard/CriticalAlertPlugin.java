package com.dnex.trailguard;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Alarms: every alert that sounds (SOS, assignments, nearby cases, urgent and
 * critical announcements, P1 reports) rings like an alarm clock — the app's own
 * siren looping on the ALARM stream until it is handled — and opens the alert
 * screen full screen instead of only showing a drop-down notification.
 * Critical (red) alerts additionally get through Do Not Disturb.
 *
 * Two parts, both needed:
 *  1. Notification on a dedicated channel: importance HIGH, alarm sound
 *     (AudioAttributes.USAGE_ALARM), category ALARM, lock-screen visible, and a
 *     full-screen intent that lights the screen and opens the alert. When the user
 *     has granted "Do Not Disturb access" to Trailguard, the channel is created
 *     with setBypassDnd(true). Android only honours that flag when the channel is
 *     created, so the channel is re-created under a new id once access is granted.
 *  2. A looping alarm sound played through the ALARM stream with MediaPlayer.
 *     The sound is Trailguard's own siren (res/raw/tg_siren.wav, rendered from
 *     the web app's alarm by scripts/make-siren.py), so the app and the website
 *     sound the same; the phone's alarm tone is the fallback.
 *     The alarm stream is not muted by the ringer switch (silent / vibrate) and is
 *     allowed in the default DND "Alarms" exception. Optionally the alarm volume is
 *     raised to at least 80 % for the duration of the alarm and restored after.
 *
 * When the user allows "Display over other apps", an alarm also brings the app to
 * the front while the phone is in use (otherwise Android shows the full-screen
 * alert only when the screen is off or locked, and a heads-up banner otherwise).
 *
 * Tapping the notification opens the app and emits "tap" { incidentId } to JS.
 */
@CapacitorPlugin(name = "CriticalAlert")
public class CriticalAlertPlugin extends Plugin {

    // A channel's sound is fixed when it is created. Since 1.4.7 the channels are
    // silent: the looping siren (startAlarm) is the sound, so it never plays twice.
    static final String CHANNEL_STANDARD = "tg_critical_std_v3";
    static final String CHANNEL_BYPASS_DND = "tg_critical_dnd_v3";
    static final String CHANNEL_ALARM = "tg_alarm_v3";
    private static final String[] OLD_CHANNELS = { "tg_critical_std", "tg_critical_dnd", "tg_critical_std_v2", "tg_critical_dnd_v2" };
    static final String EXTRA_INCIDENT = "com.dnex.trailguard.extra.INCIDENT_ID";
    static final String EXTRA_ALERT_KEY = "com.dnex.trailguard.extra.ALERT_KEY";
    private static final long[] VIBRATION = new long[] { 0, 700, 300, 700, 300, 1200 };

    private static CriticalAlertPlugin instance;

    private MediaPlayer player;
    private String playerSound;
    private int restoreVolume = -1;

    @Override
    public void load() {
        instance = this;
        ensureChannel();
        if (getActivity() != null) handleIntent(getActivity().getIntent());
    }

    @Override
    protected void handleOnDestroy() {
        stopAlarmInternal();
        if (instance == this) instance = null;
        super.handleOnDestroy();
    }

    /** Called by MainActivity for new intents (notification taps while running). */
    static void deliverIntent(Intent intent) {
        CriticalAlertPlugin plugin = instance;
        if (plugin != null) plugin.handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null || !intent.hasExtra(EXTRA_INCIDENT)) return;
        JSObject data = new JSObject();
        data.put("incidentId", intent.getStringExtra(EXTRA_INCIDENT));
        data.put("key", intent.getStringExtra(EXTRA_ALERT_KEY));
        intent.removeExtra(EXTRA_INCIDENT);
        notifyListeners("tap", data, true);
    }

    private NotificationManager systemManager() {
        return (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
    }

    private boolean policyAccess() {
        NotificationManager nm = systemManager();
        return nm != null && Build.VERSION.SDK_INT >= 23 && nm.isNotificationPolicyAccessGranted();
    }

    /** Trailguard's urgent siren; the phone's alarm tone if the sound file is missing. */
    private Uri alarmSound() {
        return alarmSound("urgent");
    }

    /** sound: "urgent" (wail) | "normal" (hi-lo two-tone), as in the web app. */
    private Uri alarmSound(String sound) {
        Context ctx = getContext();
        int siren = "normal".equals(sound) ? R.raw.tg_siren_normal : R.raw.tg_siren;
        if (siren != 0) return Uri.parse("android.resource://" + ctx.getPackageName() + "/" + siren);
        Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        return uri;
    }

    private AudioAttributes alarmAttributes() {
        return new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();
    }

    /** The channel id in use: the DND-bypassing one once access has been granted. */
    private String ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return CHANNEL_STANDARD;
        NotificationManager nm = systemManager();
        if (nm == null) return CHANNEL_STANDARD;
        boolean bypass = policyAccess();
        String id = bypass ? CHANNEL_BYPASS_DND : CHANNEL_STANDARD;
        String other = bypass ? CHANNEL_STANDARD : CHANNEL_BYPASS_DND;
        if (nm.getNotificationChannel(other) != null) nm.deleteNotificationChannel(other);
        for (String old : OLD_CHANNELS) {
            if (nm.getNotificationChannel(old) != null) nm.deleteNotificationChannel(old);
        }
        if (nm.getNotificationChannel(id) == null) {
            NotificationChannel channel = new NotificationChannel(id, "Critical emergency alerts", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("SOS, critical (P1) cases, fire alerts and critical announcements. The Trailguard siren rings even in silent mode.");
            channel.setSound(null, null);
            channel.enableVibration(false);
            channel.enableLights(true);
            channel.setLightColor(0xFFFF0000);
            channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
            channel.setBypassDnd(bypass);
            nm.createNotificationChannel(channel);
        }
        return id;
    }

    /** Channel for alarms that are not critical (assignments, nearby cases, urgent announcements). */
    private String ensureAlarmChannel() {
        if (Build.VERSION.SDK_INT < 26) return CHANNEL_STANDARD;
        NotificationManager nm = systemManager();
        if (nm == null) return CHANNEL_STANDARD;
        if (nm.getNotificationChannel(CHANNEL_ALARM) == null) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ALARM, "Dispatch alarms", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Assignments, nearby cases and urgent announcements. The Trailguard siren rings until you answer.");
            channel.setSound(null, null);
            channel.enableVibration(false);
            channel.enableLights(true);
            channel.setLightColor(0xFFFFA000);
            channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(channel);
        }
        return CHANNEL_ALARM;
    }

    private boolean canDrawOverlays() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(getContext());
    }

    private boolean ignoresBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < 23) return true;
        PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getContext().getPackageName());
    }

    private boolean canUseFullScreen() {
        if (Build.VERSION.SDK_INT < 34) return true;
        NotificationManager nm = systemManager();
        return nm != null && nm.canUseFullScreenIntent();
    }

    @PluginMethod
    public void status(PluginCall call) {
        String id = ensureChannel();
        JSObject result = new JSObject();
        result.put("notificationsEnabled", NotificationManagerCompat.from(getContext()).areNotificationsEnabled());
        result.put("dndAccess", policyAccess());
        result.put("fullScreen", canUseFullScreen());
        result.put("channel", id);
        boolean bypassing = false;
        if (Build.VERSION.SDK_INT >= 26 && systemManager() != null && systemManager().getNotificationChannel(id) != null) {
            bypassing = systemManager().getNotificationChannel(id).canBypassDnd();
        }
        result.put("channelBypassesDnd", bypassing);
        result.put("overlay", canDrawOverlays());
        result.put("batteryUnrestricted", ignoresBatteryOptimizations());
        call.resolve(result);
    }

    /** Opens Settings > Do Not Disturb access, where the user allows Trailguard. */
    @PluginMethod
    public void openDndSettings(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (RuntimeException e) {
            call.reject("Do Not Disturb settings are not available on this device.");
        }
    }

    /** Settings > Display over other apps: lets an alarm bring Trailguard to the front while the phone is in use. */
    @PluginMethod
    public void openOverlaySettings(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getContext().getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (RuntimeException e) {
            call.reject("This setting is not available on this device.");
        }
    }

    /** Asks Android to stop putting Trailguard to sleep (battery: Unrestricted), so alarms arrive in the background. */
    @PluginMethod
    public void requestBatteryExemption(PluginCall call) {
        Context ctx = getContext();
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
            call.resolve();
        } catch (RuntimeException e) {
            try {
                Intent list = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                list.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(list);
                call.resolve();
            } catch (RuntimeException e2) {
                call.reject("Battery settings are not available on this device.");
            }
        }
    }

    /** Android 14+: Settings > Special app access > Full-screen notifications. */
    @PluginMethod
    public void openFullScreenSettings(PluginCall call) {
        try {
            Intent intent;
            if (Build.VERSION.SDK_INT >= 34) {
                intent = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + getContext().getPackageName()));
            } else {
                intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                intent.putExtra(Settings.EXTRA_APP_PACKAGE, getContext().getPackageName());
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (RuntimeException e) {
            call.reject("Notification settings are not available on this device.");
        }
    }

    /** show({ id: number, key: string, title, body, incidentId?, fullScreen?: boolean, critical?: boolean }) */
    @PluginMethod
    public void show(PluginCall call) {
        Integer id = call.getInt("id");
        String title = call.getString("title", "Trailguard alert");
        String body = call.getString("body", "");
        if (id == null) {
            call.reject("id is required");
            return;
        }
        boolean critical = call.getBoolean("critical", true);
        String channel = critical ? ensureChannel() : ensureAlarmChannel();
        Context ctx = getContext();
        Intent open = new Intent(ctx, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        String incidentId = call.getString("incidentId");
        open.putExtra(EXTRA_INCIDENT, incidentId == null ? "" : incidentId);
        open.putExtra(EXTRA_ALERT_KEY, call.getString("key", ""));
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent content = PendingIntent.getActivity(ctx, id, open, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(ctx.getApplicationInfo().icon)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setColor(critical ? 0xFFE5262B : 0xFFFFA000)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setContentIntent(content)
            .setSilent(true); // the looping siren (startAlarm) is the sound
        boolean fullScreen = call.getBoolean("fullScreen", true);
        if (fullScreen && canUseFullScreen()) builder.setFullScreenIntent(content, true);
        try {
            NotificationManagerCompat.from(ctx).notify(id, builder.build());
            // With "Display over other apps" allowed, Android lets the app come to the
            // front even while the phone is in use, so the alert screen pops up.
            if (fullScreen && canDrawOverlays()) {
                open.putExtra(HardKeyReceiver.EXTRA_TOP_KEY, false);
                try {
                    ctx.startActivity(open);
                } catch (RuntimeException ignored) {
                    // Not allowed right now: the notification is still there.
                }
            }
            call.resolve();
        } catch (SecurityException e) {
            call.reject("Notification permission is off.");
        }
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        Integer id = call.getInt("id");
        if (id != null) NotificationManagerCompat.from(getContext()).cancel(id);
        call.resolve();
    }

    /** startAlarm({ forceVolume?: boolean, sound?: "urgent" | "normal" }) — loops the siren until stopAlarm(). */
    @PluginMethod
    public void startAlarm(PluginCall call) {
        boolean force = call.getBoolean("forceVolume", true);
        String sound = "normal".equals(call.getString("sound", "urgent")) ? "normal" : "urgent";
        getBridge().executeOnMainThread(() -> {
            try {
                startAlarmInternal(force, sound);
                call.resolve();
            } catch (Exception e) {
                call.reject("Alarm sound unavailable: " + e.getMessage());
            }
        });
    }

    @PluginMethod
    public void stopAlarm(PluginCall call) {
        getBridge().executeOnMainThread(() -> {
            stopAlarmInternal();
            call.resolve();
        });
    }

    private void startAlarmInternal(boolean forceVolume, String sound) throws Exception {
        if (player != null && sound.equals(playerSound)) return;
        if (player != null) {
            // Switching between the normal and the urgent siren: swap the sound, keep volume and vibration.
            try { player.stop(); } catch (IllegalStateException ignored) { /* never started */ }
            player.release();
            player = null;
        }
        Context ctx = getContext();
        AudioManager audio = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        if (forceVolume && audio != null) {
            int max = audio.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            int current = audio.getStreamVolume(AudioManager.STREAM_ALARM);
            int wanted = (int) Math.ceil(max * 0.8);
            if (current < wanted) {
                if (restoreVolume < 0) restoreVolume = current;
                try {
                    audio.setStreamVolume(AudioManager.STREAM_ALARM, wanted, 0);
                } catch (SecurityException e) {
                    restoreVolume = -1; // DND policy forbids volume changes: play at the current level
                }
            }
        }
        boolean vibrating = playerSound != null;
        MediaPlayer mp = new MediaPlayer();
        mp.setAudioAttributes(alarmAttributes());
        mp.setDataSource(ctx, alarmSound(sound));
        mp.setLooping(true);
        mp.prepare();
        mp.start();
        player = mp;
        playerSound = sound;
        if (vibrating) return;

        Vibrator vibrator = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createWaveform(VIBRATION, 1), alarmAttributes());
            else vibrator.vibrate(VIBRATION, 1);
        }
    }

    private void stopAlarmInternal() {
        if (player != null) {
            try {
                player.stop();
            } catch (IllegalStateException ignored) {
                // never started
            }
            player.release();
            player = null;
        }
        playerSound = null;
        Context ctx = getContext();
        if (ctx == null) return;
        Vibrator vibrator = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null) vibrator.cancel();
        if (restoreVolume >= 0) {
            AudioManager audio = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (audio != null) {
                try {
                    audio.setStreamVolume(AudioManager.STREAM_ALARM, restoreVolume, 0);
                } catch (SecurityException ignored) {
                    // leave as is
                }
            }
            restoreVolume = -1;
        }
    }
}
