package com.dnex.trailguard;

import android.os.CancellationSignal;

import androidx.core.content.ContextCompat;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.NoCredentialException;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

/**
 * "Continue with Google" in the Android app. Google does not allow sign-in inside
 * an app's web view, so the app shows Android's own Google account sheet
 * (Credential Manager) and returns a Google ID token; the web app then signs in to
 * Firebase with it (signInWithCredential), so the account is the same one the
 * website uses.
 *
 * Needs, in Firebase: the Android app com.dnex.trailguard with the SHA-1 of the
 * key the APK is signed with, Google enabled under Authentication, and the
 * project's Web client ID passed in as webClientId.
 *
 * signIn({ webClientId }) → { idToken, email, name }; errors: cancelled,
 * no_account, not_configured, failed.
 */
@CapacitorPlugin(name = "GoogleSignIn")
public class GoogleSignInPlugin extends Plugin {

    @PluginMethod
    public void signIn(PluginCall call) {
        String clientId = call.getString("webClientId", "");
        if (clientId == null || clientId.trim().isEmpty()) {
            call.reject("Google sign-in is not set up in this app (googleWebClientId).", "not_configured");
            return;
        }
        if (getActivity() == null) {
            call.reject("The app is not on screen.", "failed");
            return;
        }
        GetSignInWithGoogleOption option = new GetSignInWithGoogleOption.Builder(clientId.trim()).build();
        GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(option).build();
        CredentialManager manager = CredentialManager.create(getContext());
        manager.getCredentialAsync(
            getActivity(),
            request,
            new CancellationSignal(),
            ContextCompat.getMainExecutor(getContext()),
            new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                @Override
                public void onResult(GetCredentialResponse response) {
                    Credential credential = response.getCredential();
                    if (credential instanceof CustomCredential
                            && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                        try {
                            GoogleIdTokenCredential google = GoogleIdTokenCredential.createFrom(((CustomCredential) credential).getData());
                            JSObject result = new JSObject();
                            result.put("idToken", google.getIdToken());
                            result.put("email", google.getId());
                            result.put("name", google.getDisplayName());
                            call.resolve(result);
                        } catch (Exception e) { // GoogleIdTokenParsingException
                            call.reject("Google returned an unreadable sign-in.", "failed");
                        }
                    } else {
                        call.reject("Google returned an unexpected kind of sign-in.", "failed");
                    }
                }

                @Override
                public void onError(GetCredentialException e) {
                    String message = e.getMessage() == null ? "" : e.getMessage();
                    if (e instanceof GetCredentialCancellationException) {
                        call.reject("Sign-in cancelled.", "cancelled");
                    } else if (e instanceof NoCredentialException) {
                        call.reject("No Google account is available on this phone. Add one in Settings → Accounts, or sign in with email.", "no_account");
                    } else if (message.contains("28444") || message.toLowerCase().contains("developer console")) {
                        call.reject("Google sign-in is not set up for this copy of the app: its signing key (SHA-1) must be added to the Android app in Firebase.", "not_configured");
                    } else {
                        call.reject(message.isEmpty() ? "Google sign-in failed." : message, "failed");
                    }
                }
            }
        );
    }
}
