#!/usr/bin/env python3
"""Render the app's two alarm sounds (src/background-service.js, Alarm.cycle) to
WAVs for the Android app, so its alarms sound exactly like the web app.

    python3 scripts/make-siren.py   →  android/app/src/main/res/raw/tg_siren.wav
                                       android/app/src/main/res/raw/tg_siren_normal.wav

Urgent (SOS, P1, critical, fire): one 1.6 s cycle, a band-limited sawtooth (like
the Web Audio 'sawtooth' oscillator) sweeping 650 → 1350 → 650 Hz over 0.9 s.
Normal (assignments, nearby cases, urgent announcements): one 2.4 s cycle, a
hi-lo two-tone of 960 Hz then 770 Hz, 0.45 s each. Both fade in over 30 ms and
out over 50 ms, then stay silent until the cycle ends. Android loops them.
Needs numpy.
"""
import wave
from pathlib import Path

import numpy as np

RATE = 44100
TONE = 0.9
LEVEL = 0.55          # peak of the harmonic sum; Android's alarm volume scales it
OUT = Path(__file__).resolve().parent.parent / 'android/app/src/main/res/raw'


def render(name, cycle, freq_at):
    t = np.arange(int(RATE * cycle)) / RATE
    freq = freq_at(t)
    phase = 2 * np.pi * np.cumsum(freq) / RATE
    saw = np.zeros_like(t)
    for k in range(1, 40):                   # harmonics up to Nyquist only (no aliasing hiss)
        saw += np.where(k * freq < RATE / 2, np.sin(k * phase) / k, 0.0)
    saw *= 2 / np.pi
    env = np.interp(t, [0, 0.03, 0.85, TONE, cycle], [0, 1, 1, 0, 0])
    signal = saw * env
    signal *= LEVEL / np.max(np.abs(signal))
    pcm = (signal * 32767).astype('<i2')
    out = OUT / name
    out.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm.tobytes())
    print(f'Wrote {out} ({out.stat().st_size // 1024} KB, {cycle} s)')


render('tg_siren.wav', 1.6, lambda t: np.where(t < 0.45, 650 + (1350 - 650) * t / 0.45,
                                               np.where(t < TONE, 1350 - (1350 - 650) * (t - 0.45) / 0.45, 0.0)))
render('tg_siren_normal.wav', 2.4, lambda t: np.where(t < 0.45, 960.0, np.where(t < TONE, 770.0, 0.0)))
