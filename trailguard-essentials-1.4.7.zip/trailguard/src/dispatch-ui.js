// Dispatch screens: SOS button and banner, Fire & Safety rapid alert button,
// full-screen SOS alarm, drop-down alert banner (assignments incl. auto-assign,
// proximity alarms, announcements, reports to review), dispatcher board with the
// Pending Review queue, case detail (accept / progress / resolve, review, required
// equipment, assignment with role + equipment matching and ETAs, ePCR and
// transport shortcuts), report form (pin or GPS, photos, required equipment),
// role / equipment / travel-mode picker, dispatch settings (proximity master
// switch, 100–2000 m radius, auto-assign), responder status pill with the
// single-task lock, and case markers.
// One instance per group session; every DOM listener is bound to an
// AbortController and removed in stop().
import {
  $, h, toast, openSheet, closeSheets, isSheetOpen, formatAgo, formatDistance, colorFor, initials, vibrate, resizeImage
} from './ui.js';
import { serverNow } from './clock.js';
import { haversine, estimateEta, formatEta, clampRadius } from './location.js';
import {
  PRIORITIES, STATUSES, ASSIGNMENT_STATES, NEXT_STATES, CASE_STATUSES,
  isDispatcherRole, isActive, isActiveAssignment, activeAssignees, canOpenDirect, isStaleAuto
} from './dispatch.js';
import {
  ROLES, FIELD_UNITS, GEAR, MODES, REPORTABLE_TYPES, CASE_TYPES, DEFAULT_CASE_GEAR, MIN_PROXIMITY_M, MAX_PROXIMITY_M,
  caseTypeLabel, unitLabel, unitsFor, memberRoleLabel, gearFor, profileOf, responderFit, requiredGear, markerBadges
} from './roles.js';
import { AUDIENCES } from './announcements.js';
import { setting } from './runtime-config.js';
import { isNative } from './native.js';
import { isLoud } from './alerts.js';

const SOS_HOLD_MS = 1500;
const FIRE_HOLD_MS = 1500;
const MAX_PHOTOS = 3;
const ETA_FRESH_MS = 3 * 60 * 1000;
const ACTION_LABELS = {
  accepted: 'Accept',
  declined: 'Decline',
  enroute: 'En route',
  onscene: 'On scene',
  cleared: 'Resolved — done'
};
const STATE_TAG = { pending: 'pending', open: 'verified', monitoring: 'verified', closed: 'closed', rejected: 'rejected' };

const hasPoint = (p) => p && Number.isFinite(p.lat) && Number.isFinite(p.lng);

export class DispatchUI {
  /**
   * @param {object} ctx
   *   uid, name, map (MapView), dispatch (Dispatch), alerts (AlertCenter), bodycam (Bodycam),
   *   getRole(), getMembers(), getPositions(): Map<uid,{lat,lng}>, getMyFix(),
   *   getRoster(): Map<uid, presence>, getGroupName(), features(): Set<string>,
   *   setProfile(uid, {unit, gear, mode}), announcements (AnnouncementCenter),
   *   onAnnouncementSent(a), patientCount(iid), openEpcr(iid), openLayers(), openReports(),
   *   onDutyChange(onDuty), onFollowOff(), unlockAudio()
   */
  constructor(ctx) {
    this.ctx = ctx;
    this.dispatch = ctx.dispatch;
    this.alerts = ctx.alerts;
    this.ac = new AbortController();
    this.openIncidentId = null;
    this.logUnsub = null;
    this.photoUnsub = null;
    this.logItems = [];
    this.photoItems = [];
    this.form = null;          // { point, source, photos: [{full, small}] }
    this.sosTimer = null;
    this.sosHolding = false;
    this.tick = null;
    this.rolePrompted = false;
    this.roleTarget = null;    // uid whose role sheet is open
    this.roleDraft = null;     // { unit, gear: Set, mode }
    this.fireTimer = null;
    this.fireHolding = false;
  }

  on(selector, event, handler) {
    const el = typeof selector === 'string' ? $(selector) : selector;
    el.addEventListener(event, handler, { signal: this.ac.signal });
  }

  start() {
    const sig = { signal: this.ac.signal };
    this.dispatch.addEventListener('incidents', () => this.renderAll(), sig);
    this.dispatch.addEventListener('status', () => this.renderAll(), sig);
    this.dispatch.addEventListener('settings', () => this.renderAll(), sig);
    this.alerts.addEventListener('pending', () => this.renderAlerts(), sig);
    this.alerts.alarm.addEventListener('muted', () => this.renderMute(), sig);

    const emergency = String(setting('emergencyNumber', import.meta.env.VITE_EMERGENCY_NUMBER || '995') || '995').replace(/[^\d+]/g, '') || '995';
    for (const el of [$('#sos-call'), $('#alert-call')]) {
      el.href = `tel:${emergency}`;
      el.textContent = `Call ${emergency}`;
    }

    this.on('#btn-dispatch', 'click', () => this.openBoard());
    this.on('#btn-new-incident', 'click', () => this.openForm(null));
    this.on('#btn-dispatch-settings', 'click', () => this.openSettings());
    this.on('#btn-role', 'click', () => this.openRolePicker(this.ctx.uid));
    this.on('#role-skip', 'click', () => closeSheets());
    this.on('#role-save', 'click', () => this.saveRole());
    this.on('#btn-report-big', 'click', () => this.openForm(null));
    this.on('#btn-report-dock', 'click', () => this.openForm(null));
    this.on('#btn-layers', 'click', () => this.ctx.openLayers());
    this.on('#btn-reports', 'click', () => this.ctx.openReports());
    this.on('#inc-epcr', 'click', () => { if (this.openIncidentId) this.ctx.openEpcr(this.openIncidentId); });
    this.on('#inc-transport', 'click', () => { if (this.openIncidentId) this.requestTransport(this.openIncidentId); });
    this.on('#set-radius', 'input', () => { $('#set-radius-label').textContent = `${$('#set-radius').value} m`; });
    this.on('#review-gear', 'change', () => this.renderReviewUnits());
    this.on('#inc-gear', 'change', () => this.saveCaseGear());
    this.on('#status-select', 'change', (e) => this.changeStatus(e.target.value));
    this.on('#btn-sos-cancel', 'click', () => this.cancelMySos());
    this.on('#incident-create-form', 'submit', (e) => { e.preventDefault(); this.submitForm(); });
    this.on('#new-type', 'change', () => {
      const type = $('#new-type').value;
      this.setFormGear(DEFAULT_CASE_GEAR[type] || []);
      if (type === 'cardiac') $('#new-priority').value = '1'; // a cardiac arrest is always critical
      this.renderTypeHint();
    });
    this.on('#new-use-gps', 'click', () => this.useGps());
    this.on('#new-rapid', 'change', () => this.renderSubmitLabel());
    this.on('#new-drop-pin', 'click', () => this.togglePinMode(true));
    this.on('#new-photos', 'change', (e) => this.addFormPhotos(e.target.files));
    this.on('#inc-note-form', 'submit', (e) => { e.preventDefault(); this.submitNote(); });
    this.on('#inc-priority', 'change', (e) => this.changePriority(e.target.value));
    this.on('#inc-status', 'change', (e) => this.changeCaseStatus(e.target.value));
    this.on('#inc-need', 'change', (e) => this.run(() => this.dispatch.setNeed(this.openIncidentId, Number(e.target.value)), 'Updated'));
    this.on('#inc-close', 'click', () => this.closeIncident());
    this.on('#inc-reopen', 'click', () => this.run(() => this.dispatch.reopenIncident(this.openIncidentId), 'Case reopened'));
    this.on('#inc-show', 'click', () => this.showOnMap(this.openIncidentId));
    this.on('#inc-photo', 'change', (e) => this.addCasePhoto(e.target.files));
    this.on('#review-approve', 'click', () => this.approveReport());
    this.on('#review-reject', 'click', () => this.rejectReport());
    this.on('#review-type', 'change', () => this.renderReviewUnits());
    this.on('#btn-pin', 'click', () => this.togglePinMode());
    this.on('#pin-cancel', 'click', () => this.togglePinMode(false));
    this.on('#set-save', 'click', () => this.saveSettings());
    this.on('#banner-mute', 'click', () => this.alerts.alarm.toggleMuted());
    this.on('#alert-mute', 'click', () => this.alerts.alarm.toggleMuted());
    this.bindSosButton($('#btn-sos'));
    this.bindFireButton($('#btn-fire'));

    $('#new-type').replaceChildren(...REPORTABLE_TYPES.map((t) => h('option', { value: t }, CASE_TYPES[t].label)));
    $('#review-type').replaceChildren(...REPORTABLE_TYPES.map((t) => h('option', { value: t }, CASE_TYPES[t].label)));

    this.tick = setInterval(() => this.renderAll(), 15000);
    // Keep the auto-assign countdown in the banner current.
    this.bannerTick = setInterval(() => {
      if (this.alerts.pending.some((a) => a.kind === 'assignment' && a.auto)) this.renderAlerts();
    }, 5000);
    this.renderAll();
    this.renderAlerts();
    this.renderMute();
  }

  stop() {
    this.ac.abort();
    clearInterval(this.tick);
    clearInterval(this.bannerTick);
    clearTimeout(this.sosTimer);
    clearTimeout(this.fireTimer);
    if (this.logUnsub) this.logUnsub();
    if (this.photoUnsub) this.photoUnsub();
    this.logUnsub = null;
    this.photoUnsub = null;
    this.ctx.map.cancelPick();
    $('#btn-pin').setAttribute('aria-pressed', 'false');
    $('#pin-hint').hidden = true;
    $('#alert-overlay').hidden = true;
    $('#alert-banner').hidden = true;
    $('#sos-banner').hidden = true;
    $('#dispatch-count').hidden = true;
    $('#role-tag').hidden = true;
    closeSheets();
  }

  get isDispatcher() {
    return isDispatcherRole(this.ctx.getRole());
  }

  /* ---------------- helpers ---------------- */

  me() {
    return this.ctx.getMembers()[this.ctx.uid] || null;
  }

  distanceFromMe(point) {
    const me = this.ctx.getMyFix();
    return hasPoint(me) && hasPoint(point) ? haversine(me, point) : NaN;
  }

  memberPosition(uid) {
    if (uid === this.ctx.uid) return this.ctx.getMyFix();
    return this.ctx.getPositions().get(uid) || null;
  }

  /** Live ETA for a responder: their routed ETA if fresh, else a straight-line estimate. */
  etaFor(inc, uid) {
    const reported = inc.eta && inc.eta[uid];
    if (reported && serverNow() - reported.ts < ETA_FRESH_MS) {
      const age = (serverNow() - reported.ts) / 1000;
      return { seconds: Math.max(0, reported.s - age), meters: reported.m, src: reported.src };
    }
    const pos = this.memberPosition(uid);
    if (!hasPoint(pos) || !hasPoint(inc)) return null;
    return estimateEta(haversine(pos, inc), this.modeOf(uid));
  }

  modeOf(uid) {
    return profileOf(this.ctx.getMembers()[uid]).mode;
  }

  has(feature) {
    return this.ctx.features().has(feature);
  }

  /** Clickable equipment chips (checkboxes) for a list of gear ids. */
  gearChips(container, ids, selected, { disabled = false } = {}) {
    container.replaceChildren(...ids.map((g) => h('label', { class: 'gear-chip' },
      h('input', { type: 'checkbox', value: g, checked: selected.includes(g), disabled }),
      h('span', {}, GEAR[g].label.replace(/^[A-Za-z&]+ - /, '')),
      h('b', {}, GEAR[g].short))));
  }

  checkedGear(container) {
    return [...container.querySelectorAll('input[type="checkbox"]:checked')].map((i) => i.value);
  }

  /** Equipment chips for a case: gear of the roles that respond to it first, then the rest. */
  caseGearIds(type) {
    const roles = unitsFor(type, this.dispatch.settings);
    const first = Object.keys(GEAR).filter((g) => roles.includes(GEAR[g].role));
    return [...first, ...Object.keys(GEAR).filter((g) => !first.includes(g))];
  }

  etaText(eta) {
    if (!eta) return '';
    return `ETA ${eta.src === 'route' ? '' : '~'}${formatEta(eta.seconds)}`;
  }

  async run(fn, okMessage) {
    try {
      await fn();
      if (okMessage) toast(okMessage, 'ok');
      return true;
    } catch (err) {
      toast(err && /permission/i.test(err.message) ? 'Not allowed — your role, equipment or task lock may have changed.' : err.message, 'error', 4500);
      return false;
    }
  }

  badge(inc) {
    const cls = ['inc-badge'];
    if (inc.type === 'sos') cls.push('sos');
    else if (inc.state === 'pending') cls.push('pending');
    else cls.push(`p${inc.priority}`);
    if (inc.state === 'closed' || inc.state === 'rejected') cls.push('closed');
    if (inc.state === 'monitoring') cls.push('monitoring');
    return h('span', { class: cls.join(' '), title: caseTypeLabel(inc.type) },
      inc.type === 'sos' ? 'SOS' : `${PRIORITIES[inc.priority].short}`);
  }

  dispatcherOnline() {
    const members = this.ctx.getMembers();
    for (const [uid] of this.ctx.getRoster()) {
      if (uid !== this.ctx.uid && members[uid] && isDispatcherRole(members[uid].role)) return true;
    }
    return false;
  }

  /* ---------------- top-level render ---------------- */

  renderAll() {
    const { pending, open } = this.dispatch.board();
    const count = $('#dispatch-count');
    const attention = this.isDispatcher ? pending.length + open.length : open.length;
    count.textContent = String(attention);
    count.hidden = attention === 0;

    this.ctx.map.setIncidents([...open, ...pending]);
    this.renderStatusPill();
    this.renderRoleChip();
    this.renderSosBanner();
    $('#btn-dispatch-settings').hidden = !this.isDispatcher;
    $('#btn-layers').hidden = !this.isDispatcher;
    $('#btn-reports').hidden = !this.isDispatcher;
    $('#btn-new-incident').textContent = this.isDispatcher ? 'New case' : 'Report case';
    const settings = this.dispatch.settings;
    $('#auto-mode-label').textContent = !settings.proximityOn ? '· proximity alerts OFF'
      : settings.autoAssign ? `· auto-assign ON · ${settings.proximityM} m` : `· alerts within ${settings.proximityM} m`;

    if (isSheetOpen('dispatch-sheet')) this.renderBoard();
    if (isSheetOpen('incident-sheet') && this.openIncidentId) this.renderIncident();
    this.maybePromptRole();
  }

  renderStatusPill() {
    const pill = $('#status-pill');
    const eff = this.dispatch.effectiveStatus(this.ctx.uid);
    pill.dataset.state = eff.state;
    pill.classList.toggle('locked', eff.locked);
    const lockLabel = $('#status-lock');
    lockLabel.hidden = !eff.locked;
    if (eff.locked) {
      const inc = this.dispatch.incidents.get(eff.incidentId);
      lockLabel.textContent = `${eff.state === 'onscene' ? 'ON SCENE' : eff.state === 'enroute' ? 'EN ROUTE' : 'BUSY'} · ${inc ? inc.title : 'case'}`;
      return;
    }
    const select = $('#status-select');
    if (document.activeElement !== select) select.value = eff.state;
  }

  renderRoleChip() {
    const me = this.me();
    const chip = $('#btn-role');
    const { unit, legacy } = profileOf(me);
    const badges = markerBadges(me);
    chip.textContent = unit && !legacy
      ? `${ROLES[unit].label}${badges.length ? ` · ${badges.join(' ')}` : ''}`
      : (this.isDispatcher ? 'Dispatch' : 'Choose role');
    chip.style.setProperty('--chip', unit ? ROLES[unit].color : '');
    chip.classList.toggle('missing', (!unit || legacy) && !this.isDispatcher);
    $('#role-tag').hidden = !this.isDispatcher;
    $('#role-tag').textContent = this.ctx.getRole() === 'owner' ? 'Owner · Dispatch' : 'Dispatcher';
  }

  async changeStatus(value) {
    const ok = await this.run(() => this.dispatch.setStatus(value), `Status: ${STATUSES[value]}`);
    if (ok) this.ctx.onDutyChange(value !== 'offduty');
    this.renderStatusPill();
  }

  /* ---------------- Role, equipment and travel mode ---------------- */

  maybePromptRole() {
    if (this.rolePrompted) return;
    const me = this.me();
    if (!me) return;
    this.rolePrompted = true;
    const { unit, legacy } = profileOf(me);
    if ((!unit || legacy) && !this.isDispatcher) this.openRolePicker(this.ctx.uid);
    else if (legacy && this.isDispatcher) toast('Roles changed in 1.4 — tap your role chip to pick Security, Medical, Fire & Safety or Usher.', 'info', 6000);
  }

  /** Open the role sheet for me, or (dispatchers) for another member. */
  openRolePicker(targetUid = this.ctx.uid) {
    const member = this.ctx.getMembers()[targetUid];
    if (!member) return;
    if (targetUid !== this.ctx.uid && !this.isDispatcher) return;
    const profile = profileOf(member);
    this.roleTarget = targetUid;
    this.roleDraft = { unit: profile.unit, gear: new Set(profile.legacy ? [] : profile.gear), mode: profile.mode };
    const self = targetUid === this.ctx.uid;
    $('#role-heading').textContent = self ? 'What is your role today?' : `Role for ${member.name}`;
    $('#role-skip').hidden = !(self && this.isDispatcher);
    this.renderRoleSheet();
    openSheet('role-sheet', () => { this.roleTarget = null; this.roleDraft = null; });
  }

  typesForUnit(unit) {
    return REPORTABLE_TYPES.filter((t) => unitsFor(t, this.dispatch.settings).includes(unit)).map((t) => caseTypeLabel(t));
  }

  renderRoleSheet() {
    const draft = this.roleDraft;
    if (!draft) return;
    $('#role-options').replaceChildren(...FIELD_UNITS.map((unit) => h('li', { 'aria-current': unit === draft.unit ? 'true' : 'false' },
      h('button', {
        class: 'row',
        type: 'button',
        role: 'radio',
        'aria-checked': String(unit === draft.unit),
        dataset: { unit },
        onClick: () => {
          if (draft.unit !== unit) draft.gear = new Set();
          draft.unit = unit;
          this.renderRoleSheet();
        }
      },
      h('span', { class: 'unit-badge', style: `background:${ROLES[unit].color}` }, ROLES[unit].short),
      h('div', { class: 'grow' },
        h('div', { class: 'title' }, ROLES[unit].label),
        h('div', { class: 'small muted' }, `${ROLES[unit].description} Alerts: ${this.typesForUnit(unit).join(', ') || 'none'}.`))),
      unit === draft.unit ? h('span', { class: 'tag match' }, 'Selected') : null)));
    const ids = draft.unit ? gearFor(draft.unit) : [];
    const gearBox = $('#role-gear');
    this.gearChips(gearBox, ids, [...draft.gear]);
    for (const box of gearBox.querySelectorAll('input')) {
      box.addEventListener('change', () => {
        if (box.checked) draft.gear.add(box.value);
        else draft.gear.delete(box.value);
      });
    }
    $('#role-gear-empty').hidden = ids.length > 0 || !draft.unit;
    $('#role-mode').replaceChildren(...Object.entries(MODES).map(([mode, m]) => h('button', {
      type: 'button',
      role: 'radio',
      class: mode === draft.mode ? 'active' : '',
      'aria-checked': String(mode === draft.mode),
      dataset: { mode },
      onClick: () => { draft.mode = mode; this.renderRoleSheet(); }
    }, m.label)));
    $('#role-save').disabled = !draft.unit;
  }

  async saveRole() {
    const draft = this.roleDraft;
    const target = this.roleTarget;
    if (!draft || !target || !draft.unit) return;
    const name = (this.ctx.getMembers()[target] || {}).name || 'Member';
    const ok = await this.run(() => this.ctx.setProfile(target, { unit: draft.unit, gear: [...draft.gear], mode: draft.mode }),
      target === this.ctx.uid ? `You are now: ${ROLES[draft.unit].label}` : `${name} is now ${ROLES[draft.unit].label}`);
    if (ok) closeSheets();
  }

  /* ---------------- SOS ---------------- */

  bindSosButton(button) {
    this.sosButton = button;
    this.on(button, 'pointerdown', (e) => {
      e.preventDefault();
      try { button.setPointerCapture(e.pointerId); } catch { /* unsupported */ }
      this.startSosHold();
    });
    this.on(button, 'pointerup', () => this.endSosHold('Hold the SOS button for 1.5 seconds to send.'));
    this.on(button, 'pointercancel', () => this.endSosHold(null));
    this.on(button, 'contextmenu', (e) => e.preventDefault());
    this.on(button, 'keydown', (e) => {
      if (e.key === 'Enter' && !e.repeat && confirm('Send SOS to everyone in this group?')) this.raiseSos();
    });
  }

  /** Begin a 1.5 s hold (on-screen button or the rugged-device SOS key). */
  startSosHold() {
    this.ctx.unlockAudio();
    if (this.dispatch.myActiveSos()) {
      toast('Your SOS is already active.');
      return;
    }
    if (this.sosHolding) return;
    this.sosHolding = true;
    this.sosButton.classList.add('holding');
    vibrate(30);
    clearTimeout(this.sosTimer);
    this.sosTimer = setTimeout(() => {
      this.sosHolding = false;
      this.sosButton.classList.remove('holding');
      this.raiseSos();
    }, SOS_HOLD_MS);
  }

  endSosHold(hint) {
    if (!this.sosHolding) return;
    this.sosHolding = false;
    clearTimeout(this.sosTimer);
    this.sosButton.classList.remove('holding');
    if (hint) toast(hint);
  }

  /** Hardware SOS key (Samsung Top key): hold 1.5 s, same as the button. */
  topKey(down) {
    if (down) this.startSosHold();
    else this.endSosHold('Hold the SOS key for 1.5 seconds to send SOS.');
  }

  async raiseSos() {
    vibrate([200, 100, 200, 100, 400]);
    await this.run(() => this.dispatch.raiseSos(this.ctx.getMyFix()), 'SOS sent to your team');
  }

  /* ---------------- Fire & Safety: rapid fire alert ---------------- */

  bindFireButton(button) {
    this.on(button, 'pointerdown', (e) => {
      e.preventDefault();
      try { button.setPointerCapture(e.pointerId); } catch { /* unsupported */ }
      this.ctx.unlockAudio();
      if (this.fireHolding) return;
      this.fireHolding = true;
      button.classList.add('holding');
      vibrate(30);
      clearTimeout(this.fireTimer);
      this.fireTimer = setTimeout(() => {
        this.fireHolding = false;
        button.classList.remove('holding');
        this.raiseFireAlert();
      }, FIRE_HOLD_MS);
    });
    const cancel = (hint) => {
      if (!this.fireHolding) return;
      this.fireHolding = false;
      clearTimeout(this.fireTimer);
      button.classList.remove('holding');
      if (hint) toast(hint);
    };
    this.on(button, 'pointerup', () => cancel('Hold FIRE for 1.5 seconds to raise a rapid fire alert at your position.'));
    this.on(button, 'pointercancel', () => cancel(null));
    this.on(button, 'contextmenu', (e) => e.preventDefault());
    this.on(button, 'keydown', (e) => {
      if (e.key === 'Enter' && !e.repeat && confirm('Raise a rapid fire alert at your position?')) this.raiseFireAlert();
    });
  }

  /**
   * One hold: a P1 fire case opens at my GPS position without review (fire units
   * may do this), and a critical fire announcement goes to everyone.
   */
  async raiseFireAlert() {
    const fix = this.ctx.getMyFix();
    if (!fix) {
      toast('No GPS position yet — use Report case and drop a pin for the fire.', 'error', 5000);
      this.openForm(null);
      return;
    }
    vibrate([200, 100, 200, 100, 400]);
    await this.run(async () => {
      const { iid, direct } = await this.dispatch.reportCase({
        type: 'fire',
        title: `FIRE — reported by ${this.ctx.name}`,
        notes: 'Rapid fire alert from the field.',
        priority: 1,
        lat: fix.lat,
        lng: fix.lng,
        source: 'gps',
        isDispatcher: this.isDispatcher,
        openDirect: true,
        requires: [],
        rapid: true
      });
      if (direct) await this.announceFire(iid, `FIRE reported by ${this.ctx.name}. Keep clear and follow marshals' directions.`, fix);
      this.openIncidentWhenReady(iid);
      toast(direct ? 'Fire alert raised — everyone alerted, fire units dispatched' : 'Fire reported — sent to dispatch for review', direct ? 'ok' : 'info');
    });
  }

  /** Critical fire announcement for a fire case opened at once. Never fails the case itself. */
  async announceFire(iid, text, point) {
    try {
      const a = await this.ctx.announcements.send({
        text, level: 'critical', audience: 'all', kind: 'fire', caseId: iid, lat: point.lat, lng: point.lng
      });
      if (this.ctx.onAnnouncementSent) this.ctx.onAnnouncementSent(a);
    } catch (err) {
      toast(`Case opened, but the fire announcement was not sent: ${err.message}`, 'error', 5000);
    }
  }

  /** Open a case just created: its listener may deliver it a moment after the write resolves. */
  openIncidentWhenReady(iid, waitMs = 4000) {
    if (this.dispatch.incidents.has(iid)) {
      this.openIncident(iid);
      return;
    }
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), waitMs);
    this.dispatch.addEventListener('incidents', () => {
      if (!this.dispatch.incidents.has(iid)) return;
      clearTimeout(timer);
      ac.abort();
      this.openIncident(iid);
    }, { signal: ac.signal });
  }

  /** Medical: request patient transport from this case (opens directly; vehicle crews are alerted). */
  async requestTransport(iid) {
    const inc = this.dispatch.incidents.get(iid);
    if (!inc || !hasPoint(inc)) {
      toast('This case has no location.', 'error');
      return;
    }
    const where = prompt('Transport to (and any notes for the crew):', 'Medical tent / hospital');
    if (where === null) return;
    const priority = inc.priority === 1 ? 1 : 2;
    await this.run(async () => {
      const { iid: tid } = await this.dispatch.reportCase({
        type: 'transport',
        title: `Transport: ${inc.title}`.slice(0, 80),
        notes: `Patient transport requested from case "${inc.title}". ${String(where).trim()}`.slice(0, 1000),
        priority,
        lat: inc.lat,
        lng: inc.lng,
        source: 'map',
        isDispatcher: this.isDispatcher,
        openDirect: canOpenDirect('transport', this.me()),
        linkedCase: iid
      });
      this.dispatch.log(iid, `Patient transport requested (case ${tid})`);
    }, 'Transport requested — vehicle crews are alerted');
  }

  renderSosBanner() {
    const sos = this.dispatch.myActiveSos();
    const banner = $('#sos-banner');
    banner.hidden = !sos;
    if (!sos) return;
    const acks = Object.keys(sos.acks || {}).length;
    const responding = activeAssignees(sos).map(([uid, a]) => {
      const eta = this.etaFor(sos, uid);
      return eta ? `${a.name} (${formatEta(eta.seconds)})` : a.name;
    });
    $('#sos-banner-detail').textContent = responding.length
      ? `${responding.join(', ')} responding · ${acks} acknowledged`
      : `${acks} acknowledged · waiting for a responder`;
  }

  async cancelMySos() {
    const sos = this.dispatch.myActiveSos();
    if (!sos) return;
    if (!confirm('Cancel your SOS? Your team will see it is resolved.')) return;
    await this.run(() => this.dispatch.withdraw(sos.id), 'SOS cancelled');
  }

  /* ---------------- Alerts: full-screen SOS + drop-down banner ---------------- */

  renderAlerts() {
    const alerts = this.alerts.pending;
    // SOS always takes the whole screen. In the Android app every alert that sounds
    // does too (an alarm, not a drop-down), so it can be answered from the lock screen.
    // "View" on a full-screen alert shrinks it to the banner for a minute so the case can be read.
    const peeking = (a) => this.peek && this.peek.key === a.key && Date.now() < this.peek.until;
    const full = alerts.filter((a) => a.kind === 'sos' || (isNative && isLoud(a) && !peeking(a)));
    this.renderOverlay(full);
    this.renderBanner(alerts.filter((a) => !full.includes(a)));
    const unread = this.ctx.announcements ? this.ctx.announcements.pendingForMe().length : 0;
    $('#announce-count').hidden = unread === 0;
    $('#announce-count').textContent = String(unread);
  }

  renderMute() {
    const muted = this.alerts.alarm.muted;
    $('#banner-mute').setAttribute('aria-pressed', String(muted));
    $('#banner-mute').setAttribute('aria-label', muted ? 'Alarm sound off — tap to turn on' : 'Alarm sound on — tap to mute');
    $('#alert-mute').textContent = muted ? 'Turn alarm sound on' : 'Mute alarm sound';
    const toggle = $('#alarm-sound');
    if (toggle) toggle.checked = !muted;
  }

  /** Full-screen alert: SOS first, then (Android app) assignments, nearby cases, announcements. */
  renderOverlay(list) {
    const overlay = $('#alert-overlay');
    if (!list.length) {
      overlay.hidden = true;
      this.sosShown = null;
      return;
    }
    const first = list[0];
    overlay.hidden = false;
    if (this.sosShown !== first.key) {
      this.sosShown = first.key;
      vibrate([400, 200, 400]);
    }
    $('#alert-more').textContent = list.length > 1 ? `+${list.length - 1} more alert${list.length > 2 ? 's' : ''}` : '';
    if (first.kind !== 'sos') {
      const card = this.alertCard(first);
      for (const button of card.actions) {
        if (!/^(View|Review|View case|Map)$/.test(button.textContent.trim())) continue;
        button.addEventListener('click', () => {
          this.peek = { key: first.key, until: Date.now() + 60_000 };
          clearTimeout(this.peekTimer);
          this.peekTimer = setTimeout(() => this.renderAlerts(), 60_500);
          this.renderAlerts();
        });
      }
      overlay.classList.toggle('assignment', !first.critical);
      $('#alert-kind').textContent = card.kind;
      $('#alert-title').textContent = card.title;
      $('#alert-detail').textContent = '';
      $('#alert-distance').textContent = card.meta;
      $('#alert-actions').replaceChildren(...card.actions);
      return;
    }
    const inc = first.incident;
    overlay.classList.remove('assignment');
    $('#alert-kind').textContent = 'SOS · Emergency';
    $('#alert-title').textContent = `${inc.createdByName} needs help`;
    $('#alert-detail').textContent = [inc.notes, `Raised ${formatAgo(serverNow() - (inc.createdAt || serverNow()))}`].filter(Boolean).join('\n');
    const d = this.distanceFromMe(inc);
    const eta = Number.isFinite(d) ? estimateEta(d, this.modeOf(this.ctx.uid)) : null;
    $('#alert-distance').textContent = Number.isFinite(d) ? `${formatDistance(d)} from you · ETA ~${formatEta(eta.seconds)}` : (hasPoint(inc) ? '' : 'No location shared');
    const sosCount = list.filter((a) => a.kind === 'sos').length;
    if (sosCount > 1) $('#alert-more').textContent = `+${sosCount - 1} more SOS`;
    $('#alert-actions').replaceChildren(...[
      h('button', { class: 'btn primary', type: 'button', onClick: () => this.run(() => this.dispatch.respondToSos(inc.id), 'You are responding. Status: en route') }, "I'm responding"),
      h('button', { class: 'btn ghost', type: 'button', onClick: () => this.run(() => this.dispatch.acknowledge(inc.id)) }, 'Acknowledge'),
      hasPoint(inc) ? h('button', { class: 'btn ghost', type: 'button', onClick: () => { this.alerts.snooze(30_000); this.showOnMap(inc.id); } }, 'Show on map (30 s)') : null
    ].filter(Boolean));
  }

  renderBanner(list) {
    const banner = $('#alert-banner');
    if (!list.length) {
      banner.hidden = true;
      this.bannerShown = null;
      return;
    }
    const alert = list[0];
    banner.dataset.kind = alert.kind;
    banner.classList.toggle('critical', !!alert.critical);
    if (this.bannerShown !== alert.key) {
      // Re-run the drop-down animation for a new alert.
      banner.hidden = true;
      void banner.offsetWidth;
      this.bannerShown = alert.key;
      vibrate([300, 150, 300]);
    }
    banner.hidden = false;
    $('#banner-more').textContent = list.length > 1 ? `+${list.length - 1} more alert${list.length > 2 ? 's' : ''} — see the dispatch board` : '';
    const card = this.alertCard(alert);
    $('#banner-kind').textContent = card.kind;
    $('#banner-title').textContent = card.title;
    $('#banner-meta').textContent = card.meta;
    $('#banner-actions').replaceChildren(...card.actions);
  }

  /** What an alert says and the buttons that answer it: {kind, title, meta, actions}. */
  alertCard(alert) {
    if (alert.kind === 'announcement') {
      const a = alert.announcement;
      const fire = a.kind === 'fire';
      const level = a.level === 'critical' ? 'CRITICAL' : a.level === 'urgent' ? 'Urgent' : 'Announcement';
      const d = this.distanceFromMe(a);
      return {
        kind: `${fire ? '🔥 Fire alert' : level} · ${a.name}${a.audience !== 'all' ? ` → ${AUDIENCES[a.audience]}` : ''}`,
        title: a.text,
        meta: [formatAgo(serverNow() - (a.ts || serverNow())), Number.isFinite(d) ? `${formatDistance(d)} from you` : null].filter(Boolean).join(' · '),
        actions: [
          h('button', { class: 'btn primary', type: 'button', onClick: () => this.ctx.announcements.ack(a.id) }, 'Acknowledge'),
          a.caseId && this.dispatch.incidents.has(a.caseId)
            ? h('button', { class: 'btn ghost', type: 'button', onClick: () => this.openIncident(a.caseId) }, 'View case')
            : null,
          hasPoint(a) ? h('button', { class: 'btn ghost', type: 'button', onClick: () => { closeSheets(); this.ctx.onFollowOff(); this.ctx.map.focusPoint(a.lat, a.lng); } }, 'Map') : null
        ].filter(Boolean)
      };
    }

    const inc = alert.incident;
    const needs = requiredGear(inc);
    const typeText = `${PRIORITIES[inc.priority].short} · ${caseTypeLabel(inc.type)}${needs.length ? ` · ${needs.map((g) => GEAR[g].short).join('+')} requested` : ''}`;
    const d = Number.isFinite(alert.distance) ? alert.distance : this.distanceFromMe(inc);
    const eta = alert.eta || (Number.isFinite(d) ? estimateEta(d, this.modeOf(this.ctx.uid)) : null);
    const where = [Number.isFinite(d) ? `${formatDistance(d)} away` : null, eta ? this.etaText(eta) : null];
    let kind;
    let meta;
    let actions;
    if (alert.kind === 'assignment') {
      kind = `${alert.auto ? 'Auto-assigned — closest unit' : 'Assigned to you'} · ${typeText}`;
      const mine = inc.assigned && inc.assigned[this.ctx.uid];
      const since = mine ? ((mine.t && mine.t.assigned) || mine.ts || serverNow()) : serverNow();
      const left = Math.max(0, Math.round((this.dispatch.settings.autoTimeoutS * 1000 - (serverNow() - since)) / 1000));
      meta = [...where, alert.auto ? `confirm within ${left} s or it passes to the next unit` : 'by dispatch'].filter(Boolean).join(' · ');
      actions = [
        h('button', { class: 'btn primary', type: 'button', onClick: () => this.run(() => this.dispatch.setAssignmentState(inc.id, 'accepted'), 'Accepted — you are locked to this case until it is resolved') }, 'Accept case'),
        h('button', { class: 'btn ghost', type: 'button', onClick: () => this.run(() => this.dispatch.setAssignmentState(inc.id, 'declined'), 'Declined') }, 'Decline'),
        h('button', { class: 'btn ghost', type: 'button', onClick: () => this.openIncident(inc.id) }, 'View')
      ];
    } else if (alert.kind === 'proximity') {
      kind = `Nearby case · ${typeText}`;
      meta = [...where, `within ${this.alerts.radiusM()} m`].filter(Boolean).join(' · ');
      actions = [
        h('button', { class: 'btn primary', type: 'button', onClick: () => this.acceptCase(inc.id) }, 'Accept case'),
        h('button', { class: 'btn ghost', type: 'button', onClick: () => this.dismissCase(inc.id) }, 'Dismiss'),
        h('button', { class: 'btn ghost', type: 'button', onClick: () => this.openIncident(inc.id) }, 'View')
      ];
    } else {
      kind = `Pending review · from ${inc.createdByName}`;
      meta = [typeText, formatAgo(serverNow() - (inc.createdAt || serverNow())), Number.isFinite(d) ? `${formatDistance(d)} from you` : null].filter(Boolean).join(' · ');
      actions = [
        h('button', { class: 'btn primary', type: 'button', onClick: () => this.openIncident(inc.id) }, 'Review'),
        h('button', { class: 'btn ghost', type: 'button', onClick: () => this.run(() => this.dispatch.verifyReport(inc.id), 'Verified — matching units alerted') }, 'Verify now')
      ];
    }
    return { kind, title: inc.title, meta, actions };
  }

  async acceptCase(iid) {
    await this.run(() => this.dispatch.acceptCase(iid, this.me()), 'Case accepted — you are locked to it until it is resolved');
  }

  async dismissCase(iid) {
    this.alerts.dismissLocally(iid);
    await this.run(() => this.dispatch.dismiss(iid));
  }

  /* ---------------- Board ---------------- */

  openBoard() {
    openSheet('dispatch-sheet');
    this.renderBoard();
  }

  renderBoard() {
    const { pending, open, closed } = this.dispatch.board();
    $('#pending-block').hidden = pending.length === 0;
    $('#pending-count').textContent = String(pending.length);
    $('#pending-list').replaceChildren(...pending.map((inc) => this.pendingRow(inc)));
    $('#incident-empty').hidden = open.length > 0;
    $('#incident-list').replaceChildren(...open.map((inc) => this.incidentRow(inc)));
    $('#closed-block').hidden = closed.length === 0;
    $('#closed-list').replaceChildren(...closed.map((inc) => this.incidentRow(inc)));
    $('#responder-list').replaceChildren(...this.unitRows());
  }

  pendingRow(inc) {
    const d = this.distanceFromMe(inc);
    const sub = [caseTypeLabel(inc.type), `by ${inc.createdByName}`, formatAgo(serverNow() - (inc.createdAt || serverNow())),
      Number.isFinite(d) ? formatDistance(d) : null].filter(Boolean).join(' · ');
    return h('li', { class: 'incident-row' },
      h('button', { class: 'row', type: 'button', onClick: () => this.openIncident(inc.id) },
        this.badge(inc),
        h('div', { class: 'grow' }, h('div', { class: 'title' }, inc.title), h('div', { class: 'small muted' }, sub))),
      this.isDispatcher
        ? h('button', { class: 'btn small primary', type: 'button', onClick: () => this.run(() => this.dispatch.verifyReport(inc.id), 'Verified — matching units alerted') }, 'Verify')
        : h('span', { class: 'tag pending' }, 'In review'));
  }

  incidentRow(inc) {
    const assignees = activeAssignees(inc);
    const d = this.distanceFromMe(inc);
    const firstEta = assignees.map(([uid]) => this.etaFor(inc, uid)).filter(Boolean).sort((a, b) => a.seconds - b.seconds)[0];
    const sub = [
      caseTypeLabel(inc.type),
      formatAgo(serverNow() - (inc.createdAt || serverNow())),
      inc.state === 'monitoring' ? 'Monitoring' : null,
      inc.state === 'rejected' ? 'Rejected' : null,
      isActive(inc) ? `${assignees.length}/${inc.need || 1} units` : (inc.state === 'closed' ? 'Resolved' : null),
      firstEta && isActive(inc) ? `first ${this.etaText(firstEta)}` : null,
      Number.isFinite(d) ? formatDistance(d) : null
    ].filter(Boolean).join(' · ');
    return h('li', { class: 'incident-row' },
      h('button', { class: 'row', type: 'button', onClick: () => this.openIncident(inc.id) },
        this.badge(inc),
        h('div', { class: 'grow' }, h('div', { class: 'title' }, inc.title), h('div', { class: 'small muted' }, sub))));
  }

  unitRows() {
    const order = { available: 0, busy: 1, enroute: 2, onscene: 3, offduty: 4 };
    const rows = Object.entries(this.ctx.getMembers()).map(([uid, m]) => {
      const eff = this.dispatch.effectiveStatus(uid);
      return { uid, m, eff, dist: this.distanceFromMe(this.memberPosition(uid)) };
    }).sort((a, b) => order[a.eff.state] - order[b.eff.state] || (a.dist || 0) - (b.dist || 0));
    return rows.map(({ uid, m, eff, dist }) => {
      const lockInc = eff.locked ? this.dispatch.incidents.get(eff.incidentId) : null;
      const online = this.ctx.getRoster().has(uid);
      return h('li', { class: 'responder-row' },
        h('div', { class: 'avatar', style: `background:${colorFor(uid)}` }, initials(m.name),
          h('span', { class: `presence ${online ? 'on' : ''}` })),
        h('div', { class: 'grow' },
          h('div', { class: 'title' }, uid === this.ctx.uid ? `${m.name} (you)` : m.name),
          h('div', { class: 'small muted' }, [memberRoleLabel(m), lockInc ? `on "${lockInc.title}"` : null,
            Number.isFinite(dist) && uid !== this.ctx.uid ? `${formatDistance(dist)} away` : null].filter(Boolean).join(' · '))),
        this.isDispatcher ? h('button', { class: 'btn small ghost', type: 'button', onClick: () => this.openRolePicker(uid) }, 'Role') : null,
        h('span', { class: `tag status-${eff.state}${eff.locked ? ' locked' : ''}` }, eff.locked ? `LOCKED · ${STATUSES[eff.state]}` : STATUSES[eff.state]),
        this.isDispatcher && eff.locked && uid !== this.ctx.uid
          ? h('button', { class: 'btn small ghost', type: 'button', onClick: () => this.releaseUnit(uid, m.name, lockInc) }, 'Release')
          : null);
    });
  }

  async releaseUnit(uid, name, inc) {
    if (!confirm(`Release ${name} from "${inc ? inc.title : 'their case'}"? Their assignment stays on the case record.`)) return;
    await this.run(async () => {
      if (inc) await this.dispatch.unassign(inc.id, { uid, name });
      else await this.dispatch.releaseUnit(uid, name);
    }, `${name} released`);
  }

  /* ---------------- Case detail ---------------- */

  openIncident(iid) {
    if (!this.dispatch.incidents.has(iid)) {
      toast('That case is no longer available.');
      return;
    }
    if (this.openIncidentId !== iid) {
      if (this.logUnsub) this.logUnsub();
      if (this.photoUnsub) this.photoUnsub();
      this.logItems = [];
      this.photoItems = [];
      this.openIncidentId = iid;
      this.logUnsub = this.dispatch.listenLog(iid, (items) => {
        this.logItems = items;
        if (this.openIncidentId === iid) this.renderLog();
      });
      this.photoUnsub = this.dispatch.listenPhotos(iid, (items) => {
        this.photoItems = items;
        if (this.openIncidentId === iid) this.renderPhotos();
      });
      const inc = this.dispatch.incidents.get(iid);
      $('#review-type').value = REPORTABLE_TYPES.includes(inc.type) ? inc.type : 'other';
      $('#review-priority').value = String(inc.priority);
      delete $('#review-gear').dataset.type;
    }
    openSheet('incident-sheet', () => {
      if (this.logUnsub) this.logUnsub();
      if (this.photoUnsub) this.photoUnsub();
      this.logUnsub = null;
      this.photoUnsub = null;
      this.openIncidentId = null;
    });
    this.renderIncident();
  }

  renderIncident() {
    const inc = this.dispatch.incidents.get(this.openIncidentId);
    if (!inc) {
      closeSheets();
      return;
    }
    const uid = this.ctx.uid;
    const active = isActive(inc);
    const mine = inc.assigned && inc.assigned[uid];
    const me = this.me();
    $('#inc-badge').replaceWith(Object.assign(this.badge(inc), { id: 'inc-badge' }));
    $('#inc-title').textContent = inc.title;
    const d = this.distanceFromMe(inc);
    $('#inc-meta').textContent = [
      caseTypeLabel(inc.type),
      `reported by ${inc.createdByName}`,
      formatAgo(serverNow() - (inc.createdAt || serverNow())),
      inc.verifiedByName && inc.verifiedByName !== inc.createdByName ? `verified by ${inc.verifiedByName}` : null,
      Number.isFinite(d) ? `${formatDistance(d)} from you` : null,
      inc.state === 'closed' && inc.closedByName ? `closed by ${inc.closedByName}` : null
    ].filter(Boolean).join(' · ');
    const stateTag = $('#inc-state');
    stateTag.className = `tag ${STATE_TAG[inc.state] || ''}`;
    stateTag.textContent = CASE_STATUSES[inc.state] || inc.state;
    $('#inc-notes').textContent = [inc.notes, inc.rejectReason ? `Rejected: ${inc.rejectReason}` : null].filter(Boolean).join('\n');

    $('#inc-show').hidden = !hasPoint(inc);
    const nav = $('#inc-nav');
    nav.hidden = !hasPoint(inc);
    if (hasPoint(inc)) {
      const mode = { foot: 'walking', bike: 'bicycling', vehicle: 'driving' }[profileOf(me).mode] || 'walking';
      nav.href = `https://www.google.com/maps/dir/?api=1&destination=${inc.lat},${inc.lng}&travelmode=${mode}`;
    }
    const canAddPhoto = inc.state !== 'closed' && inc.state !== 'rejected' && (inc.createdBy === uid || this.isDispatcher || !!mine);
    $('#inc-photo-label').hidden = !canAddPhoto || this.photoItems.length >= 6;
    const verified = inc.state !== 'pending' && inc.state !== 'rejected';
    $('#inc-epcr').hidden = !this.has('epcr') || !verified;
    const patients = this.ctx.patientCount ? this.ctx.patientCount(inc.id) : 0;
    $('#inc-epcr-count').textContent = patients ? `(${patients})` : '';
    $('#inc-transport').hidden = !this.has('transport') || !isActive(inc) || inc.type === 'transport' || !hasPoint(inc);
    const needs = requiredGear(inc);
    $('#inc-requires').hidden = needs.length === 0;
    $('#inc-requires').textContent = needs.length ? `Equipment requested: ${needs.map((g) => GEAR[g].label).join(', ')}` : '';

    $('#inc-my-actions').replaceChildren(...this.myActions(inc, mine, me));

    // Review (pending reports).
    const reviewing = this.isDispatcher && inc.state === 'pending';
    $('#inc-review').hidden = !reviewing;
    if (reviewing) this.renderReviewUnits();

    // Dispatcher tools for verified cases.
    const managing = this.isDispatcher && inc.state !== 'pending';
    $('#inc-dispatcher').hidden = !managing;
    if (managing) {
      const prio = $('#inc-priority');
      if (document.activeElement !== prio) prio.value = String(inc.priority);
      prio.disabled = !active;
      const status = $('#inc-status');
      if (document.activeElement !== status) status.value = inc.state === 'monitoring' ? 'monitoring' : 'open';
      status.disabled = !active || inc.type === 'sos';
      const need = $('#inc-need');
      if (document.activeElement !== need) need.value = String(inc.need || 1);
      need.disabled = !active;
      const gearBox = $('#inc-gear');
      if (!gearBox.contains(document.activeElement)) this.gearChips(gearBox, this.caseGearIds(inc.type), requiredGear(inc), { disabled: !active || inc.type === 'sos' });
      $('#inc-close').hidden = !active;
      $('#inc-reopen').hidden = active || inc.state === 'rejected';
      $('#inc-assign-list').replaceChildren(...(active ? this.assignRows(inc) : []));
    }

    // Responding units with live ETA.
    const assigned = Object.entries(inc.assigned || {});
    $('#inc-assigned').replaceChildren(...(assigned.length ? assigned.map(([aUid, a]) => {
      const eta = isActiveAssignment(a) && a.state !== 'onscene' ? this.etaFor(inc, aUid) : null;
      const pos = this.memberPosition(aUid);
      const dist = hasPoint(pos) && hasPoint(inc) ? haversine(pos, inc) : NaN;
      return h('li', {},
        h('div', { class: 'avatar', style: `background:${colorFor(aUid)}` }, initials(a.name)),
        h('div', { class: 'grow' },
          h('div', { class: 'title' }, `${aUid === uid ? `${a.name} (you)` : a.name}${ROLES[a.unit] ? ` · ${unitLabel(a.unit)}` : ''}`),
          h('div', { class: 'small muted' }, [
            Number.isFinite(dist) ? `${formatDistance(dist)} from scene` : null,
            a.by === 'self' ? 'self-dispatched' : a.by === 'auto' ? 'auto-assigned' : null,
            a.reason === 'timeout' ? 'did not answer in time' : null,
            isStaleAuto(a, this.dispatch.settings) ? 'not answering' : null,
            formatAgo(serverNow() - (a.ts || serverNow()))
          ].filter(Boolean).join(' · '))),
        eta ? h('span', { class: 'eta' }, this.etaText(eta)) : null,
        h('span', { class: `tag assign-${a.state}` }, ASSIGNMENT_STATES[a.state]));
    }) : [h('li', { class: 'muted small' }, inc.state === 'pending' ? 'Units are alerted once dispatch verifies this report.' : 'Nobody responding yet.')]));

    this.renderPhotos();
    this.renderLog();
  }

  myActions(inc, mine, me) {
    const uid = this.ctx.uid;
    const actions = [];
    const lock = this.dispatch.myLock();
    if (inc.state === 'pending' && inc.createdBy === uid) {
      actions.push(h('button', { class: 'btn', type: 'button', onClick: () => this.withdrawReport(inc) }, 'Withdraw report'));
    }
    if (inc.type === 'sos' && inc.state === 'open') {
      if (inc.createdBy === uid) {
        actions.push(h('button', { class: 'btn danger', type: 'button', onClick: () => this.cancelMySos() }, 'Cancel my SOS'));
      } else if (!mine) {
        actions.push(h('button', { class: 'btn primary', type: 'button', onClick: () => this.run(() => this.dispatch.respondToSos(inc.id), 'You are responding') }, "I'm responding"));
        if (!(inc.acks && inc.acks[uid])) {
          actions.push(h('button', { class: 'btn', type: 'button', onClick: () => this.run(() => this.dispatch.acknowledge(inc.id)) }, 'Acknowledge'));
        }
      }
    }
    if (mine && isActive(inc)) {
      for (const next of NEXT_STATES[mine.state] || []) {
        actions.push(h('button', {
          class: `btn ${next === 'accepted' || next === 'onscene' || next === 'cleared' ? 'primary' : ''}`,
          type: 'button',
          onClick: () => this.run(() => this.dispatch.setAssignmentState(inc.id, next),
            next === 'cleared' ? 'Resolved — you are available for new cases' : ASSIGNMENT_STATES[next])
        }, ACTION_LABELS[next]));
      }
    } else if (inc.type !== 'sos' && inc.state === 'open' && !mine) {
      const fit = responderFit(inc, me, this.dispatch.settings);
      const matches = fit.ok;
      const myRole = profileOf(me).unit;
      if (!matches && myRole && unitsFor(inc.type, this.dispatch.settings).includes(myRole)) {
        actions.push(h('p', { class: 'small muted' }, `You can't take this case: ${fit.reason}.`));
      }
      if (matches && !lock && this.dispatch.stillNeeded(inc) > 0) {
        actions.push(h('button', { class: 'btn primary', type: 'button', onClick: () => this.acceptCase(inc.id) }, 'Accept case'));
        if (this.alerts.pending.some((a) => a.kind === 'proximity' && a.incident.id === inc.id)) {
          actions.push(h('button', { class: 'btn', type: 'button', onClick: () => this.dismissCase(inc.id) }, 'Dismiss'));
        }
      } else if (matches && lock) {
        actions.push(h('p', { class: 'small muted' }, `You're on "${lock.incident.title}". Resolve it to take another case.`));
      }
    }
    return actions;
  }

  async withdrawReport(inc) {
    if (!confirm('Withdraw this report? Dispatch will see it was withdrawn.')) return;
    await this.run(() => this.dispatch.withdraw(inc.id), 'Report withdrawn');
  }

  renderReviewUnits() {
    const type = $('#review-type').value;
    const gearBox = $('#review-gear');
    if (gearBox.dataset.type !== type) {
      // First render for this report: its own equipment; after a type change: that type's default.
      const inc = this.dispatch.incidents.get(this.openIncidentId);
      const initial = !gearBox.dataset.type && inc ? requiredGear(inc) : (DEFAULT_CASE_GEAR[type] || []);
      this.gearChips(gearBox, this.caseGearIds(type), initial.length || gearBox.dataset.type ? initial : (DEFAULT_CASE_GEAR[type] || []));
      gearBox.dataset.type = type;
    }
    const gear = this.checkedGear(gearBox);
    const units = unitsFor(type, this.dispatch.settings).map((u) => unitLabel(u));
    const s = this.dispatch.settings;
    $('#review-units').textContent = !units.length
      ? 'No role responds to this case type — assign units by hand after verifying.'
      : !s.proximityOn
        ? 'Proximity alerts are off for this group — assign units by hand after verifying.'
        : `On verify, free ${units.join(', ')} units${gear.length ? ` carrying ${gear.map((g) => GEAR[g].short).join(' + ')}` : ''} within ${s.proximityM} m are alerted${s.autoAssign ? ', and the closest is auto-assigned' : ''}.`;
  }

  async approveReport() {
    const iid = this.openIncidentId;
    if (!iid) return;
    await this.run(() => this.dispatch.verifyReport(iid, {
      type: $('#review-type').value,
      priority: Number($('#review-priority').value),
      requires: this.checkedGear($('#review-gear'))
    }), 'Verified — matching units alerted');
  }

  async saveCaseGear() {
    const iid = this.openIncidentId;
    if (!iid || !this.isDispatcher) return;
    await this.run(() => this.dispatch.setRequires(iid, this.checkedGear($('#inc-gear'))), 'Required equipment updated');
  }

  async rejectReport() {
    const iid = this.openIncidentId;
    if (!iid) return;
    const reason = prompt('Reason for rejecting (the reporter sees this):', 'Duplicate / not actionable');
    if (reason === null) return;
    await this.run(() => this.dispatch.rejectReport(iid, reason), 'Report rejected');
  }

  assignRows(inc) {
    const members = Object.entries(this.ctx.getMembers());
    const order = { available: 0, busy: 1, enroute: 2, onscene: 3, offduty: 4 };
    return members.map(([uid, m]) => {
      const eff = this.dispatch.effectiveStatus(uid);
      const pos = this.memberPosition(uid);
      const dist = hasPoint(pos) && hasPoint(inc) ? haversine(pos, inc) : Infinity;
      const lock = eff.locked && eff.incidentId !== inc.id ? this.dispatch.incidents.get(eff.incidentId) : null;
      const profile = profileOf(m);
      const fit = responderFit(inc, m, this.dispatch.settings);
      return {
        uid,
        name: m.name,
        member: m,
        unit: profile.unit,
        mode: profile.mode,
        badges: markerBadges(m),
        eff,
        dist,
        lock,
        matched: fit.ok,
        reason: fit.reason,
        missing: fit.missing,
        assignment: inc.assigned && inc.assigned[uid]
      };
    }).filter((r) => r.unit || r.assignment)
      .sort((a, b) => (a.matched ? 0 : 1) - (b.matched ? 0 : 1) || (a.missing.length ? 1 : 0) - (b.missing.length ? 1 : 0) || (a.lock ? 1 : 0) - (b.lock ? 1 : 0)
        || order[a.eff.state] - order[b.eff.state] || a.dist - b.dist)
      .map((r) => {
        const active = isActiveAssignment(r.assignment);
        const eta = Number.isFinite(r.dist) ? estimateEta(r.dist, r.mode) : null;
        let button;
        if (active) {
          button = h('button', { class: 'btn small ghost', type: 'button', onClick: () => this.run(() => this.dispatch.unassign(inc.id, r), `${r.name} unassigned`) }, 'Unassign');
        } else if (r.lock) {
          button = h('span', { class: 'tag locked' }, 'Busy');
        } else {
          button = h('button', {
            class: `btn small ${r.matched ? 'primary' : ''}`,
            type: 'button',
            onClick: () => {
              if (!r.matched && !confirm(`${r.name} (${unitLabel(r.unit)}) doesn't fit this case: ${r.reason}. Assign anyway?`)) return;
              if (r.eff.state === 'offduty' && !confirm(`${r.name} is off duty. Assign anyway?`)) return;
              this.run(() => this.dispatch.assign(inc.id, { ...r.member, uid: r.uid, name: r.name }), `${r.name} assigned`);
            }
          }, r.assignment ? 'Reassign' : 'Assign');
        }
        return h('li', { class: `assign-row${r.lock ? ' disabled' : ''}` },
          h('div', { class: 'grow' },
            h('div', { class: 'title' }, r.uid === this.ctx.uid ? `${r.name} (you)` : r.name),
            h('div', { class: 'small muted' }, [
              `${unitLabel(r.unit)}${r.badges.length ? ` ${r.badges.join(' ')}` : ''}`,
              r.lock ? `on "${r.lock.title}"` : STATUSES[r.eff.state],
              Number.isFinite(r.dist) ? formatDistance(r.dist) : 'no position',
              eta ? this.etaText(eta) : null
            ].filter(Boolean).join(' · '))),
          h('span', { class: `tag ${r.matched ? 'match' : 'nomatch'}`, title: r.reason }, r.matched ? (r.missing.length ? `Match · no ${r.missing.map((g) => GEAR[g].short).join('/')}` : 'Match') : 'Other role'),
          button);
      });
  }

  renderPhotos() {
    const grid = $('#inc-photos');
    grid.hidden = this.photoItems.length === 0;
    grid.replaceChildren(...this.photoItems.map((p) => {
      const img = h('img', { src: p.data, alt: `Photo by ${p.name}`, loading: 'lazy' });
      return p.driveUrl && /^https:\/\//.test(p.driveUrl)
        ? h('a', { href: p.driveUrl, target: '_blank', rel: 'noopener noreferrer', title: 'Open full size in Drive' }, img)
        : img;
    }));
  }

  renderLog() {
    $('#inc-log').replaceChildren(...this.logItems.map((e) => h('li', { class: e.kind === 'note' ? 'note' : 'event' },
      h('div', {}, h('strong', {}, e.name), ` ${e.kind === 'note' ? '— ' : ''}${e.text}`),
      h('div', { class: 'when' }, new Date(e.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })))));
  }

  async submitNote() {
    const input = $('#inc-note');
    const iid = this.openIncidentId;
    if (!iid) return;
    await this.run(async () => {
      await this.dispatch.addNote(iid, input.value);
      input.value = '';
    });
  }

  async changeCaseStatus(value) {
    if (!this.openIncidentId) return;
    await this.run(() => this.dispatch.setCaseStatus(this.openIncidentId, value), `Status: ${CASE_STATUSES[value]}`);
  }

  async changePriority(value) {
    if (!this.openIncidentId) return;
    await this.run(() => this.dispatch.setPriority(this.openIncidentId, Number(value)), `Severity ${PRIORITIES[value].short}`);
  }

  async closeIncident() {
    const inc = this.dispatch.incidents.get(this.openIncidentId);
    if (!inc || !confirm(`Resolve and close "${inc.title}"? Units on it are released.`)) return;
    await this.run(() => this.dispatch.closeIncident(inc.id), 'Case resolved and closed');
  }

  showOnMap(iid) {
    const inc = this.dispatch.incidents.get(iid);
    if (!inc || !hasPoint(inc)) return;
    closeSheets();
    this.ctx.onFollowOff();
    this.ctx.map.focusPoint(inc.lat, inc.lng);
  }

  async addCasePhoto(files) {
    const iid = this.openIncidentId;
    const file = files && files[0];
    $('#inc-photo').value = '';
    if (!iid || !file) return;
    await this.run(async () => {
      const prepared = await this.preparePhoto(file);
      await this.storePhoto(iid, prepared, 0);
    }, 'Photo added');
  }

  /* ---------------- Report / new case form ---------------- */

  togglePinMode(force) {
    const on = typeof force === 'boolean' ? force : !this.ctx.map.picking;
    $('#btn-pin').setAttribute('aria-pressed', String(on));
    $('#pin-hint').hidden = !on;
    if (on) {
      // Start picking before closing the form so its draft is kept.
      this.ctx.map.startPick((point) => {
        $('#btn-pin').setAttribute('aria-pressed', 'false');
        $('#pin-hint').hidden = true;
        this.openForm(point, 'pin');
      });
      closeSheets();
    } else {
      this.ctx.map.cancelPick();
    }
  }

  /**
   * Open the report form. point: {lat,lng} from a dropped pin / long-press, or
   * null to start from my GPS position (falling back to the map centre).
   * A form already being filled in keeps its fields (e.g. after dropping a pin).
   */
  openForm(point, source = 'pin') {
    if (this.ctx.map.picking) this.togglePinMode(false);
    if (!this.form) {
      this.form = { point: null, source: null, photos: [] };
      $('#new-title').value = '';
      $('#new-notes').value = '';
      $('#new-status').value = 'open';
      $('#new-priority').value = '2';
      $('#new-type').value = REPORTABLE_TYPES[0];
      $('#new-rapid').checked = true;
      this.setFormGear(DEFAULT_CASE_GEAR[REPORTABLE_TYPES[0]] || []);
      this.renderFormPhotos();
    }
    if (point) this.setFormLocation(point, source);
    else if (!this.form.point) {
      const fix = this.ctx.getMyFix();
      if (fix) this.setFormLocation(fix, 'gps');
      else this.setFormLocation(this.ctx.map.center(), 'map');
    }
    const dispatcher = this.isDispatcher;
    $('#report-heading').textContent = dispatcher ? 'New case' : 'Report a case';
    $('#new-status-field').hidden = !dispatcher;
    if (!dispatcher && !this.dispatcherOnline()) {
      $('#new-review-note').textContent = 'No dispatcher is online right now, so this report may wait. For anything urgent, hold SOS — and call 995 for life-threatening emergencies.';
    } else {
      $('#new-review-note').textContent = 'Reports go to dispatch for review before units are alerted. For a life-threatening emergency call 995 first, or hold SOS.';
    }
    this.renderTypeHint();
    this.renderSubmitLabel();
    openSheet('incident-form-sheet', () => {
      // Keep the draft while a pin is being dropped; otherwise discard it.
      if (!this.ctx.map.picking) this.form = null;
    });
  }

  setFormLocation(point, source) {
    if (!this.form) this.form = { point: null, source: null, photos: [] };
    this.form.point = { lat: point.lat, lng: point.lng };
    this.form.source = source;
    const label = { gps: 'Your GPS position', pin: 'The pin you dropped', map: 'Centre of the map (drop a pin to be exact)' }[source];
    $('#new-location').textContent = `${label}: ${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}${source === 'gps' && point.acc ? ` (±${Math.round(point.acc)} m)` : ''}`;
  }

  useGps() {
    const fix = this.ctx.getMyFix();
    if (!fix) {
      toast('No GPS position yet. Turn GPS on or drop a pin.', 'error');
      return;
    }
    this.setFormLocation(fix, 'gps');
  }

  renderTypeHint() {
    const type = $('#new-type').value;
    const units = unitsFor(type, this.dispatch.settings).map((u) => unitLabel(u));
    $('#new-type-hint').textContent = `${CASE_TYPES[type].hint} Responds: ${units.join(', ') || 'assigned by dispatch'}.`;
    $('#new-rapid-row').hidden = !(type === 'fire' && !this.isDispatcher && profileOf(this.me()).unit === 'fire');
    this.renderSubmitLabel();
  }

  setFormGear(ids) {
    const type = $('#new-type').value || REPORTABLE_TYPES[0];
    this.gearChips($('#new-gear'), this.caseGearIds(type), ids);
  }

  /** Does this report open at once (dispatcher, fire unit's rapid alert, medical transport) or go to review? */
  formOpensDirect() {
    const type = $('#new-type').value;
    if (this.isDispatcher) return true;
    if (!canOpenDirect(type, this.me())) return false;
    return type !== 'fire' || $('#new-rapid').checked;
  }

  renderSubmitLabel() {
    const direct = this.formOpensDirect();
    $('#new-submit').textContent = this.isDispatcher ? 'Create verified case' : direct ? 'Open case now — alert units' : 'Send for review';
    $('#new-review-note').hidden = direct;
  }

  /** Two JPEGs per photo: ≤1600 px for the Drive archive, ≤800 px for instant review in the app. */
  async preparePhoto(file) {
    const full = await resizeImage(file, 1600, 0.8);
    if (full.bytes > 5 * 1024 * 1024) throw new Error('That photo is too large.');
    let small = await resizeImage(file, 800, 0.6);
    if (small.dataUrl.length > 390000) small = await resizeImage(file, 600, 0.5);
    return { full, small, name: file.name };
  }

  async addFormPhotos(fileList) {
    const files = Array.from(fileList || []);
    $('#new-photos').value = '';
    if (!this.form) return;
    for (const file of files) {
      if (this.form.photos.length >= MAX_PHOTOS) {
        toast(`Up to ${MAX_PHOTOS} photos per report.`);
        break;
      }
      try {
        this.form.photos.push(await this.preparePhoto(file));
      } catch (err) {
        toast(err.message, 'error');
      }
    }
    this.renderFormPhotos();
  }

  renderFormPhotos() {
    const photos = this.form ? this.form.photos : [];
    $('#new-photo-preview').replaceChildren(...photos.map((p, i) => h('button', {
      type: 'button',
      class: 'photo-thumb',
      title: 'Remove photo',
      onClick: () => { this.form.photos.splice(i, 1); this.renderFormPhotos(); }
    }, h('img', { src: p.small.dataUrl, alt: `Photo ${i + 1}` }))));
  }

  /** Save the review copy in the database, then archive the full photo to Drive. */
  async storePhoto(iid, photo, index) {
    const pid = await this.dispatch.addPhoto(iid, { dataUrl: photo.small.dataUrl, width: photo.small.width, height: photo.small.height });
    const stamp = new Date().toISOString().replace(/[-:]/g, '').slice(0, 15);
    this.ctx.bodycam.groupName = this.ctx.getGroupName();
    this.ctx.bodycam.sendPhoto(iid, photo.full.dataUrl, `case_${stamp}_${index + 1}.jpg`)
      .then((file) => file && file.url ? this.dispatch.setPhotoDriveUrl(iid, pid, file.url) : null)
      .catch((err) => console.warn('Photo kept in the app; Drive archive failed:', err.message));
    return pid;
  }

  async submitForm() {
    const button = $('#new-submit');
    if (!this.form) this.form = { point: null, source: null, photos: [] };
    const form = this.form;
    if (!form.point) {
      // No pin yet: use my GPS position, else the centre of the map.
      const fix = this.ctx.getMyFix();
      this.setFormLocation(fix || this.ctx.map.center(), fix ? 'gps' : 'map');
    }
    if (button.disabled) return;
    button.disabled = true;
    try {
      const dispatcher = this.isDispatcher;
      const type = $('#new-type').value || 'other';
      const wantDirect = this.formOpensDirect();
      const rapid = type === 'fire' && !dispatcher && wantDirect;
      const { iid, direct } = await this.dispatch.reportCase({
        type,
        openDirect: wantDirect,
        rapid,
        requires: this.checkedGear($('#new-gear')),
        title: $('#new-title').value,
        notes: $('#new-notes').value,
        priority: Number($('#new-priority').value) || 2,
        status: $('#new-status').value || 'open',
        lat: form.point.lat,
        lng: form.point.lng,
        source: form.source,
        isDispatcher: dispatcher
      });
      const photos = form.photos.slice();
      this.form = null;
      for (let i = 0; i < photos.length; i++) {
        try { await this.storePhoto(iid, photos[i], i); } catch (err) { toast(`Photo ${i + 1} not saved: ${err.message}`, 'error'); }
      }
      if (rapid && direct) {
        await this.announceFire(iid, `FIRE: ${String($('#new-title').value || 'fire reported').trim().slice(0, 200)} — reported by ${this.ctx.name}. Keep clear.`, form.point);
      }
      toast(direct ? 'Case opened — matching units nearby are alerted' : 'Report sent to dispatch for review', 'ok');
      this.openIncidentWhenReady(iid);
    } catch (err) {
      toast(err && err.message ? err.message : 'The case could not be sent. Check your connection and try again.', 'error', 6000);
    } finally {
      button.disabled = false;
    }
  }

  /* ---------------- Dispatch settings ---------------- */

  openSettings() {
    if (!this.isDispatcher) return;
    const settings = this.dispatch.settings;
    $('#set-prox-on').checked = settings.proximityOn;
    $('#set-radius').value = String(settings.proximityM);
    $('#set-radius-label').textContent = `${settings.proximityM} m`;
    $('#set-auto').checked = settings.autoAssign;
    $('#set-timeout').value = String(settings.autoTimeoutS);
    const header = h('tr', {}, h('th', {}, 'Case type'), ...FIELD_UNITS.map((u) => h('th', { title: ROLES[u].label }, ROLES[u].short)));
    const rows = REPORTABLE_TYPES.map((type) => h('tr', {},
      h('td', {}, caseTypeLabel(type), DEFAULT_CASE_GEAR[type] ? h('span', { class: 'small muted' }, ` · ${DEFAULT_CASE_GEAR[type].map((g) => GEAR[g].short).join('+')} requested`) : null),
      ...FIELD_UNITS.map((unit) => h('td', {}, h('input', {
        type: 'checkbox',
        'aria-label': `${ROLES[unit].label} responds to ${caseTypeLabel(type)}`,
        dataset: { type, unit },
        checked: unitsFor(type, settings).includes(unit)
      })))));
    $('#set-matrix').replaceChildren(h('thead', {}, header), h('tbody', {}, ...rows));
    openSheet('settings-sheet');
  }

  async saveSettings() {
    const caseUnits = {};
    for (const box of document.querySelectorAll('#set-matrix input[type="checkbox"]')) {
      caseUnits[box.dataset.type] = caseUnits[box.dataset.type] || {};
      if (box.checked) caseUnits[box.dataset.type][box.dataset.unit] = true;
    }
    const radius = clampRadius($('#set-radius').value) || this.dispatch.settings.proximityM;
    const ok = await this.run(() => this.dispatch.saveSettings({
      proximityM: Math.min(MAX_PROXIMITY_M, Math.max(MIN_PROXIMITY_M, radius)),
      proximityOn: $('#set-prox-on').checked,
      autoAssign: $('#set-auto').checked,
      autoTimeoutS: Number($('#set-timeout').value),
      caseUnits
    }), 'Dispatch settings saved');
    if (ok) closeSheets();
  }
}
