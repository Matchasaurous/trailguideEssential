// Firebase bootstrap and runtime configuration shared by every module.
// If required settings are missing, `configError` explains what to fix and the
// SDK is not initialised (app.js shows the message instead of crashing).
import { initializeApp } from 'firebase/app';
import {
  initializeAuth,
  indexedDBLocalPersistence,
  browserLocalPersistence,
  connectAuthEmulator,
  browserPopupRedirectResolver
} from 'firebase/auth';
import { getDatabase, connectDatabaseEmulator } from 'firebase/database';
import { setting, hasRuntimeConfig } from './runtime-config.js';

const env = import.meta.env;

function parseIceServers(raw) {
  const fallback = [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }];
  if (Array.isArray(raw)) return raw; // set as a list in trailguard-config.js
  if (!raw) return fallback;
  try {
    const parsed = JSON.parse(raw);
    // An explicit empty list is allowed (LAN-only deployments with host candidates).
    return Array.isArray(parsed) ? parsed : fallback;
  } catch (err) {
    console.warn('VITE_ICE_SERVERS is not valid JSON; using public STUN only.', err);
    return fallback;
  }
}

const clean = (v) => (typeof v === 'string' ? v.trim() : '');
// trailguard-config.js value first, then the build-time .env value.
const pick = (path, envValue) => clean(setting(path, clean(envValue)));

export const config = Object.freeze({
  firebase: {
    apiKey: pick('firebase.apiKey', env.VITE_FIREBASE_API_KEY),
    authDomain: pick('firebase.authDomain', env.VITE_FIREBASE_AUTH_DOMAIN),
    databaseURL: pick('firebase.databaseURL', env.VITE_FIREBASE_DATABASE_URL),
    projectId: pick('firebase.projectId', env.VITE_FIREBASE_PROJECT_ID),
    appId: pick('firebase.appId', env.VITE_FIREBASE_APP_ID) || undefined,
    // Needed only for background alerts (web push). It is the project number — the
    // middle part of the app ID (1:<number>:web:…) — so it rarely needs setting.
    messagingSenderId: pick('firebase.messagingSenderId', env.VITE_FIREBASE_MESSAGING_SENDER_ID)
      || (/^1:(\d+):/.exec(pick('firebase.appId', env.VITE_FIREBASE_APP_ID)) || [])[1] || undefined
  },
  gasEndpoint: pick('gasEndpoint', env.VITE_GAS_ENDPOINT),
  // Optional: your own Web Push key pair (Firebase → Project settings → Cloud Messaging →
  // Web Push certificates). Blank uses Firebase's default key, which works.
  pushVapidKey: pick('pushVapidKey', env.VITE_PUSH_VAPID_KEY),
  iceServers: parseIceServers(setting('iceServers', env.VITE_ICE_SERVERS)),
  tileUrl: pick('tileUrl', env.VITE_TILE_URL) || 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
  tileAttribution: pick('tileAttribution', env.VITE_TILE_ATTRIBUTION) || '&copy; OpenStreetMap contributors',
  useEmulators: env.VITE_USE_EMULATORS === '1',
  // "Continue with Google" on the sign-in screen (web only). Set googleSignIn: false
  // in trailguard-config.js to hide it.
  googleSignIn: ![false, '0', 'false'].includes(setting('googleSignIn', env.VITE_GOOGLE_SIGNIN)),
  // Android app only: the project's Web client ID (Firebase → Authentication →
  // Sign-in method → Google → Web SDK configuration). Needed for the account sheet.
  googleWebClientId: pick('googleWebClientId', env.VITE_GOOGLE_WEB_CLIENT_ID)
});

/** Running inside the Capacitor Android app (Google sign-in pop-ups are blocked in app WebViews). */
const inNativeApp = typeof window !== 'undefined' && !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
// Web: Google's pop-up. Android app: Android's own Google account sheet (GoogleSignIn
// plugin), which needs the Web client ID — Google blocks sign-in inside app web views.
export const googleSignInAvailable = config.googleSignIn && (!inNativeApp || !!config.googleWebClientId);
const googlePopupAvailable = config.googleSignIn && !inNativeApp;

const missing = [
  ['VITE_FIREBASE_API_KEY', config.firebase.apiKey],
  ['VITE_FIREBASE_AUTH_DOMAIN', config.firebase.authDomain],
  ['VITE_FIREBASE_DATABASE_URL', config.firebase.databaseURL],
  ['VITE_FIREBASE_PROJECT_ID', config.firebase.projectId]
].filter(([, value]) => !value).map(([name]) => name);

export const configError = missing.length
  ? (hasRuntimeConfig || typeof location === 'undefined' || !/^https?:$/.test(location.protocol) || /^(localhost|127\.|192\.168\.|10\.)/.test(location.hostname)
      ? `Missing configuration: ${missing.join(', ').replace(/VITE_FIREBASE_/g, 'firebase ')}. Fill in the firebase section of trailguard-config.js on the website (or .env, then rebuild).`
      : 'This site is not configured yet. On the web server, rename trailguard-config.example.js to trailguard-config.js and fill in your Firebase settings.')
  : null;

export let firebaseApp = null;
export let auth = null;
export let db = null;

if (!configError) {
  firebaseApp = initializeApp(config.firebase);
  // initializeAuth (rather than getAuth) so the popup/redirect resolver — needed only
  // for Google sign-in — is loaded on the web and never inside the Android app's
  // WebView, where it can hang.
  auth = initializeAuth(firebaseApp, {
    persistence: [indexedDBLocalPersistence, browserLocalPersistence],
    ...(googlePopupAvailable ? { popupRedirectResolver: browserPopupRedirectResolver } : {})
  });
  db = getDatabase(firebaseApp);

  if (config.useEmulators) {
    const host = clean(env.VITE_EMULATOR_HOST) || '127.0.0.1';
    connectAuthEmulator(auth, `http://${host}:9099`, { disableWarnings: true });
    connectDatabaseEmulator(db, host, 9000);
  }
}
