// Roles, equipment sub-roles, travel modes, case types, and which roles respond
// to which case types. The same names are enforced by database.rules.json (role
// and gear names, case types, settings/caseUnits and required gear for
// self-accepting a case), so keep them in step when adding any of them.
//
// Permission level is separate (groups/{gid}/members/{uid}/role):
//   owner      — runs the group, full dispatch rights
//   dispatcher — review queue, unit tracking, bodycam feeds, global dispatching
//   member     — field responder
// A member's field role lives in members/{uid}/unit, their equipment in
// members/{uid}/gear/{gearId}: true, and how they move in members/{uid}/mode.

export const ROLES = {
  security: {
    label: 'Security',
    short: 'SEC',
    color: '#4aa3ff',
    description: 'Crowd control, disturbances, escorts. Security PTT channel, bodycam, incident logging, proximity alerts.'
  },
  medical: {
    label: 'Medical',
    short: 'MED',
    color: '#ff5d73',
    description: 'First aid to advanced life support. Medical PTT channel, ePCR, patient transport requests, bodycam, proximity alerts.'
  },
  fire: {
    label: 'Fire & Safety',
    short: 'FIRE',
    color: '#ff9f1a',
    description: 'Fire and hazard response. Fire PTT channel, hazard reporting, rapid alerts, bodycam.'
  },
  usher: {
    label: 'Usher / Marshal',
    short: 'USH',
    color: '#a78bfa',
    description: 'Course and crowd marshals. Usher PTT channel, report cases, bodycam, map, announcements.'
  }
};

export const FIELD_UNITS = Object.keys(ROLES);
/** Kept for modules written against 1.3 (same keys as ROLES). */
export const UNITS = ROLES;

/** Equipment sub-roles, shown as badges on map markers. */
export const GEAR = {
  aed: { role: 'medical', label: 'Medical - AED', short: 'AED' },
  aid_bag: { role: 'medical', label: 'Medical - Aid Bag', short: 'BAG' },
  trauma_kit: { role: 'medical', label: 'Medical - Trauma Kit', short: 'TRM' },
  als: { role: 'medical', label: 'Medical - ALS / Doctor', short: 'ALS' },
  extinguisher: { role: 'fire', label: 'Fire - Fire Extinguisher', short: 'EXT' },
  fr_kit: { role: 'fire', label: 'Fire - First Responder Kit', short: 'FRK' },
  crowd_control: { role: 'security', label: 'Security - Crowd Control', short: 'CRD' },
  escort: { role: 'security', label: 'Security - Mobile Escort', short: 'ESC' }
};
export const GEAR_IDS = Object.keys(GEAR);

export function gearFor(role) {
  return GEAR_IDS.filter((g) => GEAR[g].role === role);
}

/** How a responder moves: sets the routing profile and the fallback speed for ETAs. */
export const MODES = {
  foot: { label: 'On foot', short: '', profile: 'foot', speed: 1.4 },     // ~5 km/h
  bike: { label: 'Bicycle', short: 'BIKE', profile: 'bike', speed: 4.2 }, // ~15 km/h
  vehicle: { label: 'Vehicle / ambulance', short: 'VEH', profile: 'car', speed: 8.3 } // ~30 km/h urban
};

export const CASE_TYPES = {
  sos: { label: 'SOS', short: 'SOS', hint: 'A team member needs help now.' },
  medical_minor: { label: 'Minor medical', short: 'MED−', hint: 'Cuts, sprains, blisters, dehydration — walking wounded.' },
  medical_major: { label: 'Major medical / trauma', short: 'MED+', hint: 'Serious injury, chest pain, heat stroke, altered consciousness.' },
  cardiac: { label: 'Cardiac arrest / collapse', short: 'CPR', hint: 'Unresponsive, not breathing normally. Needs an AED now — and call 995.' },
  crowd: { label: 'Crowd control', short: 'CRWD', hint: 'Overcrowding, crush risk, barrier or queue problems.' },
  security: { label: 'Security incident / disturbance', short: 'SEC', hint: 'Fight, theft, aggressive or suspicious person or item.' },
  lost: { label: 'Lost person / welfare', short: 'LOST', hint: 'Lost child, separated or vulnerable person.' },
  fire: { label: 'Fire / hazard', short: 'FIRE', hint: 'Smoke, fire, fuel or chemical spill, electrical or structural hazard.' },
  transport: { label: 'Patient transport', short: 'TRAN', hint: 'Move a patient to the medical tent or hospital. Goes to vehicle crews.' },
  other: { label: 'Other', short: 'OTH', hint: 'Anything else that needs a response.' },
  // Types from earlier betas: still displayed, no longer offered.
  medical: { label: 'Medical', short: 'MED', legacy: 'medical_minor' },
  welfare: { label: 'Welfare check', short: 'WEL', legacy: 'lost' },
  traffic: { label: 'Traffic / road', short: 'TRF', legacy: 'crowd' }
};

/** Case types a member can report or a dispatcher can create (SOS has its own button). */
export const REPORTABLE_TYPES = ['medical_minor', 'medical_major', 'cardiac', 'crowd', 'security', 'lost', 'fire', 'transport', 'other'];

/**
 * Which field roles are alerted to, and may accept, each case type. Editable per
 * group. Ushers / Marshals report and receive announcements but don't respond by
 * default (dispatch can still assign them, or tick them here).
 */
export const DEFAULT_CASE_UNITS = {
  medical_minor: ['medical'],
  medical_major: ['medical'],
  cardiac: ['medical'],
  crowd: ['security'],
  security: ['security'],
  lost: ['security'],
  fire: ['fire'],
  transport: ['medical'],
  other: ['security', 'medical', 'fire']
};

/** Equipment pre-selected as "required" when a case of this type is created (editable per case). */
export const DEFAULT_CASE_GEAR = {
  cardiac: ['aed'],
  fire: ['extinguisher']
};

/**
 * Features each field role gets. Dispatchers (owner / dispatcher) get everything.
 * Every member has push-to-talk (on their role's own channel) and a bodycam that
 * dispatch can ask to see live (featuresFor adds both).
 */
export const ROLE_FEATURES = {
  security: ['proximity', 'report', 'map'],
  medical: ['epcr', 'transport', 'proximity', 'report', 'map'],
  fire: ['rapidAlert', 'proximity', 'report', 'fireDispatch', 'map'],
  usher: ['report', 'map']
};
export const DISPATCH_FEATURES = [
  'ptt', 'bodycam', 'epcr', 'transport', 'rapidAlert', 'report', 'map', 'fireDispatch',
  'review', 'assign', 'announce', 'settings', 'analytics', 'overlays', 'feeds'
];

export const DEFAULT_PROXIMITY_M = 600;
export const MIN_PROXIMITY_M = 100;
export const MAX_PROXIMITY_M = 2000;
export const DEFAULT_AUTO_TIMEOUT_S = 90;
export const SETTINGS_VERSION = 2;

/** Roles from the 1.3 beta and what they become. */
const LEGACY_UNITS = {
  bike_medic: { unit: 'medical', mode: 'bike', gear: ['aid_bag'] },
  medic: { unit: 'medical', mode: 'foot', gear: ['aid_bag'] },
  ambulance: { unit: 'medical', mode: 'vehicle', gear: ['trauma_kit'] }
};

export function isLegacyUnit(unit) {
  return !!LEGACY_UNITS[unit];
}

/** A member record with legacy roles mapped and gear/mode filled in. */
export function profileOf(member) {
  if (!member) return { unit: null, gear: [], mode: 'foot', legacy: false };
  const legacy = LEGACY_UNITS[member.unit];
  const unit = legacy ? legacy.unit : (ROLES[member.unit] ? member.unit : null);
  // Only equipment that belongs to the member's role counts (a stale AED tick
  // left over from a role change does not make a security unit an AED carrier).
  const gear = legacy && !member.gear
    ? legacy.gear.slice()
    : GEAR_IDS.filter((g) => member.gear && member.gear[g] === true && GEAR[g].role === unit);
  const mode = MODES[member.mode] ? member.mode : (legacy ? legacy.mode : 'foot');
  return { unit, gear, mode, legacy: !!legacy };
}

export function isDispatchRole(role) {
  return role === 'owner' || role === 'dispatcher';
}

/** Feature set for a member: union of their field role's features and, for dispatchers, all. */
export function featuresFor(member) {
  const set = new Set(['report', 'map', 'ptt', 'bodycam']);
  if (!member) return set;
  const { unit } = profileOf(member);
  for (const f of ROLE_FEATURES[unit] || []) set.add(f);
  if (isDispatchRole(member.role)) for (const f of DISPATCH_FEATURES) set.add(f);
  return set;
}

/** Default group settings, in the shape stored at groups/{gid}/settings. */
export function defaultSettings() {
  const caseUnits = {};
  for (const [type, units] of Object.entries(DEFAULT_CASE_UNITS)) {
    caseUnits[type] = Object.fromEntries(units.map((u) => [u, true]));
  }
  return {
    v: SETTINGS_VERSION,
    proximityM: DEFAULT_PROXIMITY_M,
    proximityOn: true,
    autoAssign: false,
    autoTimeoutS: DEFAULT_AUTO_TIMEOUT_S,
    caseUnits
  };
}

/** Settings as read from the database, with defaults filled in. 1.3 settings keep their radius only. */
export function normalizeSettings(raw) {
  const defaults = defaultSettings();
  if (!raw || typeof raw !== 'object') return defaults;
  const proximityM = Number(raw.proximityM);
  const timeout = Number(raw.autoTimeoutS);
  const current = raw.v === SETTINGS_VERSION;
  return {
    v: SETTINGS_VERSION,
    proximityM: Number.isFinite(proximityM) ? Math.min(MAX_PROXIMITY_M, Math.max(MIN_PROXIMITY_M, proximityM)) : defaults.proximityM,
    proximityOn: raw.proximityOn !== false,
    autoAssign: raw.autoAssign === true,
    autoTimeoutS: Number.isFinite(timeout) && timeout >= 30 && timeout <= 600 ? timeout : DEFAULT_AUTO_TIMEOUT_S,
    caseUnits: current && raw.caseUnits && typeof raw.caseUnits === 'object' ? raw.caseUnits : defaults.caseUnits
  };
}

export function caseTypeLabel(type) {
  return (CASE_TYPES[type] || CASE_TYPES.other).label;
}

export function caseTypeShort(type) {
  return (CASE_TYPES[type] || CASE_TYPES.other).short;
}

export function unitLabel(unit) {
  return ROLES[unit] ? ROLES[unit].label : 'No role';
}

export function gearLabels(gearIds) {
  return gearIds.filter((g) => GEAR[g]).map((g) => GEAR[g].label.replace(/^[A-Za-z&]+ - /, ''));
}

function resolveType(type) {
  return CASE_TYPES[type] && CASE_TYPES[type].legacy ? CASE_TYPES[type].legacy : type;
}

/** Field roles that respond to a case type under these settings. */
export function unitsFor(type, settings) {
  if (type === 'sos') return FIELD_UNITS.slice();
  const map = normalizeSettings(settings).caseUnits[resolveType(type)] || {};
  return FIELD_UNITS.filter((u) => map[u] === true);
}

/** Required equipment on a case, as a list. */
export function requiredGear(incident) {
  return incident && incident.requires ? GEAR_IDS.filter((g) => incident.requires[g] === true) : [];
}

/**
 * Can this member respond to this case? Only the primary role decides: the
 * member's role must respond to the case type (group settings). Equipment and
 * travel mode are informational — a case's required equipment (e.g. an AED) is
 * shown on alerts and markers, and auto-assign prefers units that carry it, but
 * every unit of the right role is alerted and may respond.
 * (Mirrors the self-accept rule in database.rules.json.)
 * Returns { ok, reason, missing: gear ids the member lacks, vehicle: has a vehicle }.
 */
export function responderFit(incident, member, settings) {
  const { unit, gear, mode, legacy } = profileOf(member);
  const missing = requiredGear(incident).filter((g) => !gear.includes(g));
  const vehicle = mode === 'vehicle';
  if (!unit) return { ok: false, reason: 'No role chosen', missing, vehicle };
  if (legacy) return { ok: false, reason: 'Choose your role again (1.4 roles)', missing, vehicle };
  if (incident.type !== 'sos' && !unitsFor(incident.type, settings).includes(unit)) return { ok: false, reason: 'Other role', missing, vehicle };
  return { ok: true, reason: '', missing, vehicle };
}

/** Does this member carry everything the case asks for (and a vehicle, for transport)? Used to rank, never to exclude. */
export function bestEquipped(incident, member) {
  const { gear, mode } = profileOf(member);
  if (requiredGear(incident).some((g) => !gear.includes(g))) return false;
  return resolveType(incident.type) !== 'transport' || mode === 'vehicle';
}

/** Kept for 1.3 callers: does a role (ignoring gear) respond to this type? */
export function unitMatches(type, unit, settings) {
  return !!unit && unitsFor(type, settings).includes(unit);
}

/** Human label for what a member does: "Dispatcher · Medical", "Medical · AED, ALS", … */
export function memberRoleLabel(member) {
  if (!member) return '';
  const { unit, gear, mode } = profileOf(member);
  const parts = [];
  if (member.role === 'dispatcher') parts.push('Dispatcher');
  if (member.role === 'owner') parts.push('Owner · Dispatch');
  if (unit) parts.push(ROLES[unit].label);
  else if (!isDispatchRole(member.role)) parts.push('No role chosen');
  const extras = [...gear.map((g) => GEAR[g].short), mode !== 'foot' ? MODES[mode].short : null].filter(Boolean);
  if (extras.length) parts.push(extras.join(' '));
  return parts.join(' · ');
}

/** Badge texts for a map marker: equipment, then travel mode. */
export function markerBadges(member) {
  const { gear, mode } = profileOf(member);
  return [...gear.map((g) => GEAR[g].short), mode !== 'foot' ? MODES[mode].short : null].filter(Boolean);
}
