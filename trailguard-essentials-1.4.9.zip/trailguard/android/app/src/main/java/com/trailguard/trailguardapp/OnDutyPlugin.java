package com.trailguard.trailguardapp;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Web app ↔ OnDutyService.
 *   start({title, body})  on entering an event group: keep running in the background
 *   stop()                on leaving it (back to the group list, leave, sign out)
 *   status() → {onDuty}
 * Event 'offDuty': the user tapped "Go off duty" on the notification.
 */
@CapacitorPlugin(name = "OnDuty")
public class OnDutyPlugin extends Plugin {

    private static OnDutyPlugin instance;

    @Override
    public void load() {
        instance = this;
    }

    @Override
    protected void handleOnDestroy() {
        if (instance == this) instance = null;
        super.handleOnDestroy();
    }

    @PluginMethod
    public void start(PluginCall call) {
        try {
            OnDutyService.start(getContext(), call.getString("title"), call.getString("body"));
            call.resolve();
        } catch (RuntimeException e) {
            call.reject("Could not keep Trailguard running in the background: " + e.getMessage(), "failed");
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        OnDutyService.stop(getContext());
        call.resolve();
    }

    @PluginMethod
    public void status(PluginCall call) {
        JSObject result = new JSObject();
        result.put("onDuty", OnDutyService.isOnDuty(getContext()));
        call.resolve(result);
    }

    static void emitOffDuty() {
        OnDutyPlugin plugin = instance;
        if (plugin != null) plugin.notifyListeners("offDuty", new JSObject());
    }
}
