package com.trailguard.trailguardapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

/**
 * "On duty": keeps Trailguard running in the background for as long as the user
 * is in an event group, whether or not GPS sharing is on.
 *
 *  - A foreground service (one quiet notification, "Trailguard — on duty") keeps
 *    the app process, and with it the web app, Firebase and incoming voice, alive
 *    with the screen off or another app open. A partial wake lock keeps the CPU
 *    running, so alerts and voice are not delayed by sleep.
 *  - If the user swipes Trailguard away from Recents, or Android stops it, the
 *    service brings the app back in the background (behind whatever is on
 *    screen). Android only allows that once "Display over other apps" is on;
 *    without it the user gets a notification to reopen the app.
 *  - After a reboot or an app update (BootReceiver) the service starts again and
 *    reopens the app, which goes straight back into the last group.
 *  - The notification's "Go off duty" action, leaving the group, signing out or
 *    going back to the group list stops all of this.
 *
 * The microphone is never used here: the web app closes it whenever Trailguard
 * leaves the screen.
 */
public class OnDutyService extends Service {

    public static final String ACTION_OFF_DUTY = "com.trailguard.trailguardapp.action.OFF_DUTY";
    public static final String EXTRA_REVIVE = "com.trailguard.trailguardapp.extra.REVIVE";

    private static final String PREFS = "trailguard.duty";
    private static final String KEY_ON = "on";
    private static final String KEY_TITLE = "title";
    private static final String KEY_BODY = "body";

    private static final String CHANNEL_DUTY = "tg_duty";
    private static final String CHANNEL_REOPEN = "tg_duty_reopen";
    private static final int NOTIFICATION_ID = 28400;
    private static final int NOTIFICATION_REOPEN_ID = 28401;
    private static final long WAKE_LOCK_MS = 12L * 60 * 60 * 1000;
    private static final long REVIVE_DELAY_MS = 1500;

    private PowerManager.WakeLock wakeLock;
    private final Handler handler = new Handler(Looper.getMainLooper());

    /* ---------------- Called by OnDutyPlugin and BootReceiver ---------------- */

    public static void start(Context context, String title, String body) {
        prefs(context).edit()
            .putBoolean(KEY_ON, true)
            .putString(KEY_TITLE, title)
            .putString(KEY_BODY, body)
            .apply();
        ContextCompat.startForegroundService(context, new Intent(context, OnDutyService.class));
    }

    public static void stop(Context context) {
        prefs(context).edit().putBoolean(KEY_ON, false).apply();
        context.stopService(new Intent(context, OnDutyService.class));
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIFICATION_REOPEN_ID);
    }

    /** After a reboot or update: start again, and reopen the app in the background. */
    public static void revive(Context context) {
        if (!isOnDuty(context)) return;
        Intent intent = new Intent(context, OnDutyService.class).putExtra(EXTRA_REVIVE, true);
        try {
            ContextCompat.startForegroundService(context, intent);
        } catch (RuntimeException e) {
            showReopenNotification(context);
        }
    }

    public static boolean isOnDuty(Context context) {
        return prefs(context).getBoolean(KEY_ON, false);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /* ---------------- Service ---------------- */

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_OFF_DUTY.equals(intent.getAction())) {
            prefs(this).edit().putBoolean(KEY_ON, false).apply();
            OnDutyPlugin.emitOffDuty();
            stopSelfNow();
            return START_NOT_STICKY;
        }
        if (!isOnDuty(this)) {
            stopSelfNow();
            return START_NOT_STICKY;
        }
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIFICATION_ID, buildNotification());
            }
        } catch (RuntimeException e) {
            // Android refused a background start (battery optimisation still on):
            // ask the user to reopen the app instead.
            showReopenNotification(this);
            stopSelf();
            return START_NOT_STICKY;
        }
        holdWakeLock();
        // intent == null: Android restarted this service after stopping the app.
        boolean revive = intent == null || intent.getBooleanExtra(EXTRA_REVIVE, false);
        if (revive && !MainActivity.isAlive()) handler.postDelayed(this::reviveApp, REVIVE_DELAY_MS);
        return START_STICKY;
    }

    /** Swiped away from Recents: the screen is gone but the user is still on duty. */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (isOnDuty(this)) reviveLater(4);
    }

    /** The closed screen can take a moment to go away: check a few times. */
    private void reviveLater(int attempts) {
        handler.postDelayed(() -> {
            if (!isOnDuty(this)) return;
            if (MainActivity.isAlive()) {
                if (attempts > 1) reviveLater(attempts - 1);
                return;
            }
            reviveApp();
        }, REVIVE_DELAY_MS);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        releaseWakeLock();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void stopSelfNow() {
        releaseWakeLock();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        stopSelf();
    }

    /** Open the app again behind whatever is on screen (MainActivity moves itself to the back). */
    private void reviveApp() {
        if (!isOnDuty(this) || MainActivity.isAlive()) return;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            showReopenNotification(this);
            return;
        }
        Intent launch = new Intent(this, MainActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(MainActivity.EXTRA_BACKGROUND, true);
        try {
            startActivity(launch);
        } catch (RuntimeException e) {
            showReopenNotification(this);
        }
    }

    private void holdWakeLock() {
        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "trailguard:on-duty");
            wakeLock.setReferenceCounted(false);
        }
        wakeLock.acquire(WAKE_LOCK_MS);
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
    }

    /* ---------------- Notifications ---------------- */

    private Notification buildNotification() {
        ensureChannels(this);
        SharedPreferences p = prefs(this);
        String title = p.getString(KEY_TITLE, null);
        String body = p.getString(KEY_BODY, null);
        PendingIntent offDuty = PendingIntent.getService(this, 1,
            new Intent(this, OnDutyService.class).setAction(ACTION_OFF_DUTY),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL_DUTY)
            .setSmallIcon(getApplicationInfo().icon)
            .setContentTitle(title != null ? title : "Trailguard — on duty")
            .setContentText(body != null ? body : "Alerts and voice stay on in the background.")
            .setContentIntent(openAppIntent(this))
            .addAction(0, "Go off duty", offDuty)
            .setOngoing(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build();
    }

    static void showReopenNotification(Context context) {
        ensureChannels(context);
        Notification n = new NotificationCompat.Builder(context, CHANNEL_REOPEN)
            .setSmallIcon(context.getApplicationInfo().icon)
            .setContentTitle("Trailguard was closed — you are still on duty")
            .setContentText("Tap to reopen it so alerts keep reaching you.")
            .setStyle(new NotificationCompat.BigTextStyle().bigText(
                "Tap to reopen it so alerts keep reaching you. To have it reopen by itself, allow "
                + "\"Display over other apps\" for Trailguard (Members → This device → Alarms)."))
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .build();
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            try {
                nm.notify(NOTIFICATION_REOPEN_ID, n);
            } catch (SecurityException ignored) {
                // Notifications turned off: nothing more we can do.
            }
        }
    }

    private static PendingIntent openAppIntent(Context context) {
        Intent open = new Intent(context, MainActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        return PendingIntent.getActivity(context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void ensureChannels(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (nm.getNotificationChannel(CHANNEL_DUTY) == null) {
            NotificationChannel duty = new NotificationChannel(CHANNEL_DUTY, "On duty", NotificationManager.IMPORTANCE_LOW);
            duty.setDescription("Shown while Trailguard keeps running in the background for your event group.");
            duty.setShowBadge(false);
            duty.setSound(null, null);
            duty.enableVibration(false);
            nm.createNotificationChannel(duty);
        }
        if (nm.getNotificationChannel(CHANNEL_REOPEN) == null) {
            NotificationChannel reopen = new NotificationChannel(CHANNEL_REOPEN, "App closed while on duty", NotificationManager.IMPORTANCE_HIGH);
            reopen.setDescription("Tells you when Trailguard was closed while you are on duty.");
            nm.createNotificationChannel(reopen);
        }
    }
}
