// Native (Capacitor Android) capabilities with web fallbacks:
//  * background location through a foreground service (keeps the app — GPS,
//    Firebase and WebRTC — alive with the screen off),
//  * native HTTP for database writes/reads while backgrounded (Android throttles
//    WebView network requests after ~5 minutes in the background),
//  * high-priority local notifications for dispatch alerts, and critical (red)
//    alerts through the native CriticalAlert plugin that sound through silent
//    mode and — once the user grants Do Not Disturb access — through DND,
//  * app foreground/background state,
//  * hardware PTT / SOS keys and Knox PTT intents (HardwareKey plugin).
import { Capacitor, CapacitorHttp, registerPlugin } from '@capacitor/core';
import { App } from '@capacitor/app';
import { LocalNotifications } from '@capacitor/local-notifications';
import { config } from './firebase.js';

export const isNative = Capacitor.isNativePlatform();
const BackgroundGeolocation = isNative ? registerPlugin('BackgroundGeolocation') : null;
const OnDuty = isNative ? registerPlugin('OnDuty') : null;

const ALERT_CHANNEL = 'dispatch-alerts';
let channelReady = null;
let foreground = typeof document === 'undefined' ? true : document.visibilityState === 'visible';
const appStateListeners = new Set();

function setForeground(value) {
  if (value === foreground) return;
  foreground = value;
  for (const cb of appStateListeners) {
    try { cb(foreground); } catch (err) { console.warn(err); }
  }
}

if (isNative) {
  App.addListener('appStateChange', ({ isActive }) => setForeground(isActive));
} else if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', () => setForeground(document.visibilityState === 'visible'));
}

export function isForeground() {
  return foreground;
}

/** cb(isForeground) on every change. Returns an unsubscribe function. */
export function onAppStateChange(cb) {
  appStateListeners.add(cb);
  return () => appStateListeners.delete(cb);
}

/* ---------------- Location source ---------------- */

/**
 * Start receiving positions. Native: foreground-service watcher that keeps
 * running with the screen off. Web: navigator.geolocation.watchPosition.
 * onFix({lat,lng,acc,heading,speed,gpsTs}); onError({code,message}).
 * Resolves to a stop() function.
 */
export async function watchLocation(onFix, onError) {
  if (isNative) {
    await ensureNotificationPermission(); // Android 13+: the service notification needs it
    const id = await BackgroundGeolocation.addWatcher({
      backgroundTitle: 'Trailguard — on duty',
      backgroundMessage: 'Sharing your location and listening for dispatch alerts.',
      requestPermissions: true,
      stale: false,
      distanceFilter: 3
    }, (location, error) => {
      if (error) {
        if (error.code === 'NOT_AUTHORIZED') {
          onError({ code: 1, message: 'Location permission is off. Open settings and allow location “While using the app”.', openSettings: true });
        } else {
          onError({ code: 2, message: error.message || 'Location unavailable.' });
        }
        return;
      }
      if (!location) return;
      onFix({
        lat: location.latitude,
        lng: location.longitude,
        acc: location.accuracy || 0,
        heading: Number.isFinite(location.bearing) ? location.bearing : null,
        speed: Number.isFinite(location.speed) ? location.speed : null,
        gpsTs: location.time || Date.now()
      });
    });
    return () => BackgroundGeolocation.removeWatcher({ id }).catch(() => {});
  }

  if (!('geolocation' in navigator)) {
    onError({ code: 'unsupported', message: 'This device has no location support.' });
    return () => {};
  }
  const watchId = navigator.geolocation.watchPosition(
    (pos) => {
      const c = pos.coords;
      onFix({
        lat: c.latitude,
        lng: c.longitude,
        acc: c.accuracy || 0,
        heading: Number.isFinite(c.heading) ? c.heading : null,
        speed: Number.isFinite(c.speed) ? c.speed : null,
        gpsTs: pos.timestamp || Date.now()
      });
    },
    (err) => {
      const messages = {
        1: 'Location permission denied. Enable it in your browser or app settings.',
        2: 'Location unavailable. Move to open sky or check that GPS is on.',
        3: 'Waiting for a GPS fix…'
      };
      onError({ code: err.code, message: messages[err.code] || err.message });
    },
    { enableHighAccuracy: true, maximumAge: 0, timeout: 20000 }
  );
  return () => navigator.geolocation.clearWatch(watchId);
}

export function openAppSettings() {
  if (isNative) BackgroundGeolocation.openSettings().catch(() => {});
}

/* ---------------- Native HTTP to the Realtime Database REST API ---------------- */

function restUrl(path, idToken) {
  const base = config.firebase.databaseURL.replace(/\/+$/, '');
  return `${base}/${path}.json?auth=${encodeURIComponent(idToken)}`;
}

/** True when database traffic should go through native HTTP instead of the WebView. */
export function useNativeHttp() {
  return isNative && !foreground;
}

export async function restPut(path, value, idToken) {
  const res = await CapacitorHttp.request({
    method: 'PUT',
    url: restUrl(path, idToken),
    headers: { 'Content-Type': 'application/json' },
    data: value
  });
  if (res.status < 200 || res.status >= 300) {
    const err = new Error(`HTTP ${res.status}`);
    err.code = res.status === 401 || res.status === 403 ? 'PERMISSION_DENIED' : 'http';
    throw err;
  }
  return res.data;
}

export async function restGet(path, idToken) {
  const res = await CapacitorHttp.request({ method: 'GET', url: restUrl(path, idToken) });
  if (res.status < 200 || res.status >= 300) throw new Error(`HTTP ${res.status}`);
  return typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
}

/* ---------------- Notifications ---------------- */

let webNotifyAsked = false;

/** Ask once, from a user gesture where possible. */
export async function ensureNotificationPermission() {
  try {
    if (isNative) {
      const status = await LocalNotifications.checkPermissions();
      if (status.display !== 'granted') await LocalNotifications.requestPermissions();
      if (!channelReady) {
        channelReady = LocalNotifications.createChannel({
          id: ALERT_CHANNEL,
          name: 'Dispatch alerts',
          description: 'SOS and dispatch assignments',
          importance: 5,
          visibility: 1,
          vibration: true,
          lights: true,
          lightColor: '#FF0000'
        }).catch(() => {});
      }
      await channelReady;
      return true;
    }
    if ('Notification' in window) {
      if (Notification.permission === 'default' && !webNotifyAsked) {
        webNotifyAsked = true;
        await Notification.requestPermission();
      }
      return Notification.permission === 'granted';
    }
  } catch (err) {
    console.warn('Notification permission', err);
  }
  return false;
}

function notificationId(key) {
  let h = 0;
  for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) | 0;
  return Math.abs(h) % 2147483000 + 1;
}

const CriticalAlert = isNative ? registerPlugin('CriticalAlert') : null;
const GoogleSignIn = isNative ? registerPlugin('GoogleSignIn') : null;

/**
 * Android app: Google account sheet → { idToken, email, name }. Rejects with
 * err.code 'cancelled' | 'no_account' | 'not_configured' | 'failed' and a readable message.
 */
export async function nativeGoogleSignIn(webClientId) {
  if (!GoogleSignIn) throw Object.assign(new Error('Google sign-in needs the Android app.'), { code: 'failed' });
  try {
    return await GoogleSignIn.signIn({ webClientId: webClientId || '' });
  } catch (err) {
    throw Object.assign(new Error((err && err.message) || 'Google sign-in failed.'), { code: (err && err.code) || 'failed' });
  }
}
export const hasCriticalAlerts = !!CriticalAlert;

/**
 * Show an alert notification. key dedupes (same key replaces). critical: SOS, P1
 * cases, fire and critical announcements — on Android these use the critical
 * channel (alarm sound, full-screen, DND bypass when allowed).
 */
export async function notify({ key, title, body, data, critical = false, loud = critical }) {
  try {
    // Android app: every alert that sounds is an alarm — full screen, the app's siren
    // looping (Alarm → startNativeAlarm). Critical ones use the DND-bypassing channel.
    if (isNative && (critical || loud) && CriticalAlert) {
      await ensureNotificationPermission();
      await CriticalAlert.show({
        id: notificationId(key),
        key,
        title,
        body,
        incidentId: data && data.incidentId ? String(data.incidentId) : '',
        fullScreen: true,
        critical: !!critical
      });
      return;
    }
    if (isNative) {
      await ensureNotificationPermission();
      await LocalNotifications.schedule({
        notifications: [{
          id: notificationId(key),
          title,
          body,
          channelId: ALERT_CHANNEL,
          autoCancel: true,
          extra: data || {}
        }]
      });
      return;
    }
    if ('Notification' in window && Notification.permission === 'granted') {
      const reg = 'serviceWorker' in navigator ? await navigator.serviceWorker.getRegistration() : null;
      // Browsers cannot override silent mode or Do Not Disturb; critical alerts
      // stay on screen until handled and vibrate longer.
      const options = {
        body,
        tag: key,
        renotify: true,
        requireInteraction: true,
        silent: false,
        data: data || {},
        icon: 'icons/icon-192.png',
        vibrate: critical ? [800, 300, 800, 300, 800, 300, 1200] : [400, 200, 400, 200, 400]
      };
      if (reg) await reg.showNotification(title, options);
      else new Notification(title, options);
    }
  } catch (err) {
    console.warn('Notification failed', err);
  }
}

export async function clearNotification(key) {
  try {
    if (isNative) {
      await LocalNotifications.cancel({ notifications: [{ id: notificationId(key) }] });
      if (CriticalAlert) await CriticalAlert.cancel({ id: notificationId(key) });
    }
    else if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg) for (const n of await reg.getNotifications({ tag: key })) n.close();
    }
  } catch { /* nothing to clear */ }
}

/** cb(data) when the user taps an alert notification. */
export function onNotificationTap(cb) {
  if (isNative) {
    const handle = LocalNotifications.addListener('localNotificationActionPerformed', (action) => cb(action.notification.extra || {}));
    const critical = CriticalAlert ? CriticalAlert.addListener('tap', (data) => cb(data || {})) : null;
    return () => {
      Promise.resolve(handle).then((h) => h.remove()).catch(() => {});
      if (critical) Promise.resolve(critical).then((h) => h.remove()).catch(() => {});
    };
  }
  if ('serviceWorker' in navigator) {
    const handler = (event) => { if (event.data && event.data.type === 'notification-click') cb(event.data.data || {}); };
    navigator.serviceWorker.addEventListener('message', handler);
    return () => navigator.serviceWorker.removeEventListener('message', handler);
  }
  return () => {};
}

/* ---------------- Rugged-device hardware keys ---------------- */

// Android key codes. Samsung reports its XCover (side) key as 1015 and its Top
// (emergency) key as 1079; many rugged devices and wearables use the stem keys.
export const XCOVER_KEY = 1015;
export const TOP_KEY = 1079;
export const KEYCODE_STEM_PRIMARY = 264;
export const KEYCODE_STEM_1 = 265;
export const DEFAULT_NATIVE_PTT_KEYS = [XCOVER_KEY, KEYCODE_STEM_PRIMARY, KEYCODE_STEM_1];
export const DEFAULT_NATIVE_SOS_KEYS = [TOP_KEY];
export const NATIVE_KEY_NAMES = {
  1015: 'XCover', 1079: 'Top', 264: 'STEM_PRIMARY', 265: 'STEM_1', 266: 'STEM_2', 267: 'STEM_3',
  79: 'HEADSETHOOK', 24: 'VOLUME_UP', 25: 'VOLUME_DOWN', 27: 'CAMERA', 80: 'FOCUS', 228: 'PTT (some radios)'
};

const HardwareKey = isNative ? registerPlugin('HardwareKey') : null;

export const hasNativeKeys = !!HardwareKey;

/**
 * cb({keyCode, down, source}) for the hardware keys the native HardwareKey plugin
 * is told to capture (setNativeKeys). Returns an unsubscribe function. No-op on the web.
 */
export function onHardwareKey(cb) {
  if (!HardwareKey) return () => {};
  const handle = HardwareKey.addListener('hardwareKey', (event) => cb(event));
  return () => { Promise.resolve(handle).then((h) => h.remove()).catch(() => {}); };
}

/** Tell the native layer which key codes to capture for push-to-talk and SOS. */
export async function setNativeKeys(ptt, sos) {
  if (!HardwareKey) return;
  await HardwareKey.setKeys({ ptt: ptt.map(Number), sos: sos.map(Number) });
}

/** Resolve with the key code of the next hardware button pressed (Back cancels). */
export async function learnNativeKey() {
  if (!HardwareKey) throw new Error('Hardware keys need the Android app.');
  const result = await HardwareKey.learn();
  if (!result || !Number.isFinite(result.keyCode)) throw new Error('cancelled');
  return result.keyCode;
}

export function cancelLearnNativeKey() {
  if (HardwareKey) HardwareKey.cancelLearn().catch(() => {});
}

/* ---------------- Critical alerts (Android) ---------------- */

/**
 * { available, notificationsEnabled, dndAccess, fullScreen, channelBypassesDnd }.
 * On the web only notification permission is known.
 */
export async function criticalAlertStatus() {
  if (!CriticalAlert) {
    const granted = typeof Notification !== 'undefined' && Notification.permission === 'granted';
    return { available: false, notificationsEnabled: granted, dndAccess: false, fullScreen: false, channelBypassesDnd: false };
  }
  try {
    return { available: true, ...(await CriticalAlert.status()) };
  } catch {
    return { available: true, notificationsEnabled: false, dndAccess: false, fullScreen: false, channelBypassesDnd: false };
  }
}

export function openDndAccessSettings() {
  return CriticalAlert ? CriticalAlert.openDndSettings() : Promise.reject(new Error('Needs the Android app.'));
}

/** Settings › Display over other apps: alarms then pop the app up while the phone is in use. */
export function openOverlaySettings() {
  return CriticalAlert ? CriticalAlert.openOverlaySettings() : Promise.reject(new Error('Needs the Android app.'));
}

/** Ask Android to leave Trailguard out of battery optimisation (keeps it running in the background). */
export function requestBatteryExemption() {
  return CriticalAlert ? CriticalAlert.requestBatteryExemption() : Promise.reject(new Error('Needs the Android app.'));
}

export function openFullScreenAlertSettings() {
  return CriticalAlert ? CriticalAlert.openFullScreenSettings() : Promise.reject(new Error('Needs the Android app.'));
}

/**
 * Loop the app's siren on the ALARM stream (not silenced by the ringer switch).
 * sound: 'urgent' (wail: SOS, P1, critical) | 'normal' (two-tone). Calling again with
 * the other sound swaps it without stopping the alarm.
 */
export async function startNativeAlarm({ forceVolume = true, sound = 'urgent' } = {}) {
  if (!CriticalAlert) return false;
  try {
    await CriticalAlert.startAlarm({ forceVolume, sound });
    return true;
  } catch (err) {
    console.warn('Native alarm', err);
    return false;
  }
}

export async function stopNativeAlarm() {
  if (CriticalAlert) await CriticalAlert.stopAlarm().catch(() => {});
}

/* ---------------- Knox PTT intents ---------------- */

export const DEFAULT_KNOX_PTT_PRESS = 'com.samsung.android.knox.intent.action.PTT_PRESS';
export const DEFAULT_KNOX_PTT_RELEASE = 'com.samsung.android.knox.intent.action.PTT_RELEASE';

/** Broadcast action names the Knox Service Plugin key mapping sends (press / release). */
export async function setKnoxPttActions(press, release) {
  if (!HardwareKey) return;
  await HardwareKey.setPttActions({ press, release });
}

/* ---------------- On duty (Android): always running in the background ---------------- */

/**
 * Keep the Android app running in the background for as long as the user is in
 * an event group (OnDutyService): a quiet "on duty" notification, the app reopens
 * itself if it is swiped away or the phone restarts. No-op on the web.
 */
export async function startDuty({ title, body } = {}) {
  if (!OnDuty) return;
  try {
    await ensureNotificationPermission(); // Android 13+: the notification needs it
    await OnDuty.start({ title: title || 'Trailguard — on duty', body: body || 'Alerts and voice stay on in the background.' });
  } catch (err) {
    console.warn('On-duty service', err);
  }
}

export function stopDuty() {
  if (OnDuty) OnDuty.stop().catch(() => {});
}

/** cb() when the user taps "Go off duty" on the notification. Returns an unsubscribe function. */
export function onOffDuty(cb) {
  if (!OnDuty) return () => {};
  const handle = OnDuty.addListener('offDuty', () => cb());
  return () => { Promise.resolve(handle).then((h) => h.remove()).catch(() => {}); };
}
